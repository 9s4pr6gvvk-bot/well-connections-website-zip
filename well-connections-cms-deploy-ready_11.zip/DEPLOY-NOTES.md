# Deploy notes — Well Connections consolidated amendments (Sept 2026)

## Files changed
- `public/index.html` — nav bar fixed (was missing entirely), hero copy/image/trust
  bar, new "What We Take Care Of" section, testimonials swapped to short versions,
  About/Governance rewritten (no more Sam/Andrea bios), Personal Support panel.
- `public/businesses/index.html` — new heading/copy, image swap, new MH First Aid
  & Workplace Wellbeing Training section (Gerry Spencer), new "What HR & Managers
  Need to Know" section, nav link added.
- `public/schools/index.html` — image swap, upgraded to full approved testimonials
  (Joanna Fox + Alison Knight), nav link added.
- `public/charities/index.html` — image swap, nav link added (copy already covered
  everything requested).
- `public/personal-support/index.html` — new page. Six routes, each linking to the
  matching `/team/<slug>` page, reviews, free-consultation CTA.
- `public/images/` — new folder, all 11 images from the pack, static (no R2).

## Database migrations to run (in this order)
```
npx wrangler d1 execute wellconnections-cms --remote --file=./migrate-testimonials-v2.sql
npx wrangler d1 execute wellconnections-cms --remote --file=./migrate-faqs-v2.sql
npx wrangler d1 execute wellconnections-cms --remote --file=./migrate-team-name.sql
npx wrangler d1 execute wellconnections-cms --remote --file=./migrate-rate-limits.sql
npx wrangler d1 execute wellconnections-cms --remote --file=./migrate-booking-durations.sql
```

`migrate-booking-durations.sql` sets general enquiries / discovery calls to a
15-minute free consultation and organisation partner pages (Arthritis UK,
Harrogate Skills for Living, and any future `kind='organisation'` page) to 30
minutes. It updates the live rows the seed file's `WHERE NOT EXISTS` inserts
leave untouched, and sets the global `booking_duration` (the homepage "Book a
Free Discovery Call" flow) to 15.

Logo: the nav and footer on `public/index.html` now use the full horizontal
lockup (`public/images/wc-logo-lockup.png`) as a CSS mask, coloured sage
(`#608c8a`) in the nav and white in the footer. Colour is controlled in CSS via
`background-color`, so the logo can be recoloured without editing the image.
Notification recipient (`BOOKING_TO` in `wrangler.toml`) is now
`info@wellconnections.co.uk`.

`migrate-rate-limits.sql` adds the per-IP rate limiting for the public
booking / enquiry / chat forms. Until it runs, the limiter fails open (forms
work as before, no cap), so it is safe to deploy first and migrate right after.
These replace the old testimonial/FAQ seed content and rename the Child & Teens
team to "Children and Young People's Therapy Team" per Sam's naming request.

## Flagged before going live
- **Images 09, 10, 11** (NEOSS/Gerry Spencer training photo, workshop materials,
  and the real workshop photo on the Schools page) are genuine event photography.
  Left in place as requested, but Sam's email says to reconfirm permission before
  publishing these — check with her before this goes live.
- **Personal Support page is new** — not yet linked from anywhere except the nav,
  hero button, and the homepage panel. Worth a quick proofread before launch.

## Bug fix — photos cropping out Sam/Andrea
`.about-image-wrap img` was forcing a portrait 4:5 crop on desktop, a leftover
from the old template which was designed for portrait headshot-style photos.
Every new landscape pack photo dropped into that container (02, 04, 05, 06, 07,
08, 09) was losing roughly half its width, which is what was cropping people
out. Changed to `aspect-ratio: 3/2` across all five pages (index, businesses,
schools, charities, personal-support) to match the mobile breakpoint that was
already set correctly.

Also fixed the homepage hero: it was anchored to `background-position: right
center`, which crops relative to the image's absolute right edge. On narrower
windows that cut off most of both women. Repositioned to `63% center`, which
is roughly where the pair actually sit in the frame, so the crop stays
centered on them at any width instead of being anchored to an edge they aren't
against. Also fixed the hero's leftover alt text (still said "Bluebell
woodland path" from the old image).

## Also completed this round
- **"How We Work"** homepage section rewritten to Sam's exact 5-step structure
  (We listen / We design / We coordinate / We deliver / We review), replacing the
  old 7-step version.
- **FAQs split across audience pages** — Businesses, Schools, Charities and
  Personal Support each now have a short accordion of the most relevant questions
  from Sam's approved copy, sitting above the contact CTA, with a "See all FAQs"
  link through to the full `/faqs` page (which carries everything via the DB
  migration).

## Gap-check against Sam's original email (final pass)
Went through her email line by line against the built site and fixed five
remaining gaps:
- **New standalone `/services` page** — she asked for a dedicated Services
  page giving an overview of all 7 services, each explaining the organisational
  problem it addresses. This didn't exist before (nav just anchored to the
  homepage services section). Built it, and repointed the "Services" nav link
  across all pages to `/services`.
- **Nick Bousfield's full NEOSS testimonial** added as a pull quote on the
  Businesses page (previously only the short version was live, in the homepage
  carousel).
- **"What We Take Care Of"** now has all 7 bullets as listed items — "adapt or
  scale support when needs change" was previously folded into the caption text
  only.
- **Emergency disclaimer added to the main homepage enquiry form** — "not
  monitored for emergencies, replies within one working day." This existed on
  the new Personal Support page but not on the actual contact form
  organisations will use.
- **Arthritis UK Wellbeing Coaching link confirmed working**, unaffected by
  this round's changes. It's a direct/unlisted link at `/book/arthritis-uk`
  (not surfaced in navigation) — that's by design for per-organisation booking
  pages, but worth confirming with Sam that's what she wants.

## Hero refinements (per Frankie's request)
- Reduced hero text sizes for a more restrained, professional feel: h1 max
  down from 4.6rem to 3.3rem, eyebrow/paragraph sizes and margins tightened
  to match, button gap reduced.
- Fixed heads getting cropped by the nav bar: the nav is fixed and opaque
  (76px tall) and sits on top of the hero image at every screen size. The
  original photo only had about 12% headroom above their heads, which the
  nav was eating into on most real screen heights. Re-cropped
  01-homepage-hero-sam-andrea.jpg to trim excess floor/carpet space off the
  bottom (there was a lot, the original was a mostly-empty-floor shot),
  which increases the headroom-to-height ratio to ~18% without losing any
  of the two women. Comfortably clears the nav on any realistic viewport
  height now.

## Hero — second pass (photo still cropping heads, heading wrap)
Screenshot showed heads still clipped by the nav bar even after the bottom-crop
fix. Turned out my headroom estimate was wrong — measured it properly this
time with pixel analysis and found there was only ~58px of real headroom in
the source photo (not ~110px as I'd eyeballed), which the bottom-only trim
couldn't fix without cropping the photo down to almost nothing.

Fixed properly this time: extended the canvas upward using a stretched,
blurred copy of a safe ceiling strip (well above the heads), crossfaded into
the original so the seam is invisible, then trimmed the excess floor at the
bottom for a natural hero-banner ratio (1672x891). Headroom is now ~29% of
the image height, comfortably clearing the nav at any realistic browser
height.

Also added a manual line break in the H1 ("Mental health and / wellbeing
support," instead of wrapping mid-phrase) so the first two lines read more
evenly and match the natural wrap already happening on the line below.

## Photo placement re-check against 00-IMAGE-USAGE-GUIDE.txt
Went through every placement against the actual guide file (not just the main
amendments email). One real mismatch found and fixed:
- **Image 04** is guided for "How We Work, partnership approach or
  organisational insights section" but was sitting in the homepage's "One
  Trusted Partner" intro instead. Swapped it with image 02 (guided for
  general About-page use), which was in the "Why Well Connections Exists"
  section, a better fit for 04's "partnership/insights" framing. No layout
  change, just swapped which photo sits where.
- Confirmed all other placements match the guide (05/06/07/08 on their
  respective audience pages, 09/10 on the MHFA section, 11 on Schools).
- Confirmed alt text on the brand-imagery photos (01, 02, 04) doesn't imply
  a specific documented event, per the guide's caution — they're captioned
  generically.
- Note: image 04 still has the AI-artifact issue (malformed hand) flagged
  earlier — this placement fix doesn't resolve that, still needs a
  replacement photo from Sam regardless of which section it sits in.

## Fixed: Google reviews were still on the homepage
Sam's email: "Individual testimonials and Google reviews should sit within
this personal-support journey rather than the organisational homepage." This
had been missed — a full 3-review Google Reviews block (Natalie Waring,
Naomi Antcliff, Rebecca Bussy) was still live on the homepage. Removed it
from index.html entirely and added the two missing reviews (Naomi, Rebecca)
to the Personal Support page, which previously only had Natalie's. That page
now shows all three, in a 3-column grid.

## Section order changed (Frankie's UX call, diverges from Sam's stated order)
Sam's email lists "Organisation-led introduction" before "Clear routes for
businesses, schools and charities" (points 1 and 2). Frankie asked for this
reversed for UX reasons — "Who We Work With" (pathways/routes) now comes
before "One Trusted Partner" (org intro) on the homepage. Flagged to Frankie
that this contradicts her stated order before making the change; he
confirmed he wants it regardless. Worth mentioning to Sam when this goes
back to her, since it's a deliberate deviation from her brief, not an
oversight.
