-- Booking durations: general enquiries / discovery calls are 15 minutes;
-- organisation partner clients (Arthritis UK etc.) are 30 minutes.
--
-- Fixes rows that were already seeded on the live database (the seed file's
-- INSERTs use WHERE NOT EXISTS, so they never touch existing rows).
--
-- Run once (safe to re-run):
--   npx wrangler d1 execute wellconnections-cms --remote --file=./migrate-booking-durations.sql

-- Global flow (the homepage "Book a Free Discovery Call" modal): 15 minutes.
INSERT INTO app_settings (key, value) VALUES ('booking_duration', '15')
  ON CONFLICT(key) DO UPDATE SET value = '15', updated_at = datetime('now');

-- Every general-facing booking page: 15 minutes.
UPDATE booking_pages SET duration_min = 15, updated_at = datetime('now')
  WHERE kind = 'general';

-- Every organisation partner page: 30 minutes.
UPDATE booking_pages SET duration_min = 30, updated_at = datetime('now')
  WHERE kind = 'organisation';
