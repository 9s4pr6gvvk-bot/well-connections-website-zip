-- Native booking pages: a self-hosted replacement for per-organisation Calendly links.
-- Each row is one bookable call type with its own availability rules, duration and
-- custom questions. Public page lives at /book/<slug>.
--
-- Run once (safe to re-run):
--   npx wrangler d1 execute wellconnections-cms --remote --file=./migrate-booking-pages.sql

CREATE TABLE IF NOT EXISTS booking_pages (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  name          TEXT    NOT NULL,               -- "Arthritis UK Wellbeing Coaching"
  slug          TEXT    NOT NULL UNIQUE,        -- "arthritis-uk" -> /book/arthritis-uk
  kind          TEXT    DEFAULT 'organisation', -- 'general' | 'organisation'
  organisation  TEXT    DEFAULT '',
  intro         TEXT    DEFAULT '',             -- shown above the calendar
  confirm_note  TEXT    DEFAULT '',             -- shown on the confirmation screen

  -- Availability rules. Blank/NULL means "use the global Availability settings".
  duration_min  INTEGER,                        -- slot length in minutes
  buffer_min    INTEGER,                        -- gap between slots
  days          TEXT,                           -- "1,2,3,4,5" (0=Sun)
  time_start    TEXT,                           -- "09:00"
  time_end      TEXT,                           -- "17:00"
  lead_hours    INTEGER,                        -- min notice before first slot
  horizon_days  INTEGER,                        -- how far ahead to open
  timezone      TEXT,                           -- IANA tz

  -- Custom booking questions as a JSON array:
  -- [{"label":"Your role","type":"text","required":1},
  --  {"label":"Preferred format","type":"select","options":["Online","In person"],"required":0}]
  questions     TEXT    DEFAULT '[]',

  notes         TEXT    DEFAULT '',             -- internal only, never shown publicly
  notify_email  TEXT    DEFAULT '',             -- who gets told about a booking
  listed        INTEGER DEFAULT 0,              -- 1 = show on the public /book directory
  status        TEXT    DEFAULT 'published',
  sort_order    INTEGER DEFAULT 0,
  created_at    TEXT    DEFAULT (datetime('now')),
  updated_at    TEXT    DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_bookpage_status ON booking_pages(status);
CREATE INDEX IF NOT EXISTS idx_bookpage_slug   ON booking_pages(slug);

-- Tie each booking to the page it came through, and keep the answers given.
--
-- NOTE: SQLite has no "ADD COLUMN IF NOT EXISTS". If you run this file a second
-- time these two lines will report "duplicate column name" and stop. That is
-- harmless: everything above has already been applied. Either run the file once,
-- or delete these two lines before re-running.
ALTER TABLE bookings ADD COLUMN page_id INTEGER;
ALTER TABLE bookings ADD COLUMN answers TEXT DEFAULT '';

-- Seed the four call types from the brief. Availability columns are left NULL so
-- each one inherits the global Availability settings until it is tuned.
INSERT INTO booking_pages (name, slug, kind, intro, duration_min, listed, sort_order)
SELECT 'Free Personal Support Call', 'personal-support', 'general',
       'A free, no-obligation call to talk through the support you are looking for. We will listen, answer your questions and explain what happens next.',
       15, 1, 1
WHERE NOT EXISTS (SELECT 1 FROM booking_pages WHERE slug='personal-support');

INSERT INTO booking_pages (name, slug, kind, intro, duration_min, listed, sort_order, questions)
SELECT 'Organisation Discovery Call', 'discovery', 'general',
       'A free 15-minute call to understand your organisation, your existing provision, and where support would make the most difference.',
       15, 1, 2,
       '[{"label":"Organisation name","type":"text","required":1},{"label":"Your role","type":"text","required":0},{"label":"Roughly how many people would this cover?","type":"select","options":["Under 50","50-250","250-1000","Over 1000","Not sure yet"],"required":0},{"label":"What prompted you to get in touch?","type":"textarea","required":0}]'
WHERE NOT EXISTS (SELECT 1 FROM booking_pages WHERE slug='discovery');

INSERT INTO booking_pages (name, slug, kind, organisation, intro, duration_min, listed, sort_order, notes, questions)
SELECT 'Arthritis UK Wellbeing Coaching', 'arthritis-uk', 'organisation', 'Arthritis UK',
       'Book your wellbeing coaching session with Well Connections.',
       30, 0, 10,
       'Replaces the old Arthritis UK Calendly link. Booking questions below mirror the ones that were set up in Calendly.',
       '[{"label":"Employee or reference number","type":"text","required":0},{"label":"Is this your first session?","type":"select","options":["Yes, first session","No, a follow-up"],"required":1},{"label":"Anything you would like the coach to know beforehand?","type":"textarea","required":0}]'
WHERE NOT EXISTS (SELECT 1 FROM booking_pages WHERE slug='arthritis-uk');

INSERT INTO booking_pages (name, slug, kind, organisation, intro, duration_min, listed, sort_order, notes, questions)
SELECT 'Harrogate Skills for Living', 'harrogate-skills-for-living', 'organisation', 'Harrogate Skills for Living',
       'Book your session with Well Connections.',
       30, 0, 11,
       'Replaces the old Harrogate Skills for Living Calendly link. Booking questions below mirror the ones that were set up in Calendly.',
       '[{"label":"How were you referred?","type":"select","options":["Self-referral","Through Harrogate Skills for Living","Another organisation"],"required":1},{"label":"Anything you would like us to know beforehand?","type":"textarea","required":0}]'
WHERE NOT EXISTS (SELECT 1 FROM booking_pages WHERE slug='harrogate-skills-for-living');
