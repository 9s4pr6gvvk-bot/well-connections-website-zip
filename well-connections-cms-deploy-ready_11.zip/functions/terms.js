import { layout } from "../shared/layout.js";
import { escapeHtml, markdownToHtml } from "../shared/markdown.js";
import { LEGAL_CSS } from "./privacy.js";

// /terms -> Terms of Use. Body text is stored in app_settings under 'terms'
// so it can be pasted in without a redeploy.
export async function onRequestGet(context) {
  const { env } = context;

  let content = "";
  let updated = "";
  try {
    const row = await env.DB.prepare(
      "SELECT value, updated_at FROM app_settings WHERE key='terms'"
    ).first();
    content = (row && row.value) || "";
    updated = (row && row.updated_at) || "";
  } catch {
    content = "";
  }

  const hasContent = content.trim().length > 0;

  const body = `
  <header class="page-head">
    <span class="label">Legal</span>
    <h1>Terms of<br /><em>use.</em></h1>
    ${updated && hasContent ? `<p>Last updated ${escapeHtml(String(updated).slice(0, 10))}.</p>` : ""}
  </header>

  <main class="wrap legal-wrap">
    ${hasContent
      ? `<div class="legal-body">${markdownToHtml(content)}</div>`
      : `<div class="legal-pending" role="status">
           <h2>These terms are being prepared</h2>
           <p>Our terms of use are being finalised and will appear here shortly. If you have a question about how we work or what to expect from a service, please get in touch and we will explain it directly.</p>
           <a href="/#contact" class="legal-btn">Get in touch</a>
         </div>`}
  </main>
  ${LEGAL_CSS}`;

  return new Response(
    layout({
      title: "Terms of Use | Well Connections",
      description: "The terms that apply when using the Well Connections website and services.",
      canonical: "/terms",
      body
    }),
    { headers: { "content-type": "text/html;charset=UTF-8" } }
  );
}
