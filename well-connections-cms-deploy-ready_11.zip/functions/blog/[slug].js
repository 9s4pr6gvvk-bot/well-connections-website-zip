import { layout } from "../../shared/layout.js";
import { markdownToHtml, escapeHtml } from "../../shared/markdown.js";

function fmtDate(iso) {
  if (!iso) return "";
  return new Date(iso).toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" });
}

export async function onRequestGet(context) {
  const { env, params } = context;
  const post = await env.DB.prepare(
    "SELECT * FROM posts WHERE slug=? AND status='published'"
  ).bind(params.slug).first();

  if (!post) {
    return new Response(layout({
      title: "Article not found | Well Connections",
      description: "The article you were looking for could not be found.",
      noindex: true,
      body: `<main class="wrap" style="text-align:center"><h1 style="font-family:'League Spartan',sans-serif;font-weight:600">Article not found</h1><p style="margin-top:1rem"><a href="/blog">Back to the blog</a></p></main>`,
    }), { status: 404, headers: { "Content-Type": "text/html; charset=utf-8" } });
  }

  const SITE = "https://wellconnections.co.uk";
  const canonical = `${SITE}/blog/${post.slug}`;
  const coverAbs = post.cover_url
    ? (post.cover_url.startsWith("http") ? post.cover_url : SITE + post.cover_url)
    : SITE + "/images/01-homepage-hero-sam-andrea.jpg";
  const isoDate = (d) => { const m = String(d || "").match(/^\d{4}-\d{2}-\d{2}/); return m ? m[0] : undefined; };
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "BlogPosting",
    "@id": canonical + "#article",
    "headline": post.title,
    "description": post.excerpt || "",
    "image": coverAbs,
    "url": canonical,
    "mainEntityOfPage": { "@type": "WebPage", "@id": canonical },
    "datePublished": isoDate(post.published_at),
    "dateModified": isoDate(post.updated_at || post.published_at),
    "author": { "@type": post.author ? "Person" : "Organization", "name": post.author || "Well Connections" },
    "publisher": {
      "@type": "Organization",
      "name": "Well Connections",
      "logo": { "@type": "ImageObject", "url": SITE + "/apple-touch-icon.png" },
    },
  };

  const body = `
  <main>
  <article>
    <header class="page-head">
      <span class="label">${escapeHtml(fmtDate(post.published_at))}${post.author ? " &middot; " + escapeHtml(post.author) : ""}</span>
      <h1>${escapeHtml(post.title)}</h1>
    </header>
    <div class="wrap article-body">
      ${post.cover_url ? `<img class="cover" src="${escapeHtml(post.cover_url)}" alt="${escapeHtml(post.title)}" />` : ""}
      ${markdownToHtml(post.body)}
      <p class="back"><a href="/blog">&larr; All articles</a></p>
    </div>
  </article>
  </main>
  <style>
    .article-body{max-width:720px}
    .article-body .cover{width:100%;border-radius:6px;margin-bottom:2.5rem}
    .article-body h2{font-family:'League Spartan',sans-serif;font-weight:500;font-size:1.8rem;margin:2rem 0 .8rem;color:var(--text)}
    .article-body h3{font-family:'League Spartan',sans-serif;font-weight:500;font-size:1.4rem;margin:1.6rem 0 .6rem}
    .article-body p{margin:0 0 1.2rem;font-size:1.02rem;color:#2a3a32}
    .article-body ul,.article-body ol{margin:0 0 1.2rem 1.4rem}
    .article-body li{margin-bottom:.4rem}
    .article-body a{color:var(--teal)}
    .article-body img{max-width:100%;border-radius:6px;margin:1rem 0}
    .article-body blockquote{border-left:3px solid var(--sage);padding-left:1.2rem;margin:1.5rem 0;font-style:italic;color:var(--text-muted)}
    .article-body code{background:var(--sage-pale);padding:.15rem .4rem;border-radius:3px;font-size:.9em}
    .article-body hr{border:none;border-top:1px solid var(--stone);margin:2rem 0}
    .back{margin-top:2.5rem}
  </style>`;

  return new Response(layout({
    title: `${post.title} | Well Connections`,
    description: post.excerpt || "",
    body,
    canonical,
    image: coverAbs,
    ogType: "article",
    jsonLd,
  }), { headers: { "Content-Type": "text/html; charset=utf-8" } });
}
