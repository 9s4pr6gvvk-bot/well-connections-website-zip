import { json } from "../../shared/layout.js";
import { sendEmail, emailShell, esc, detailsTable, emailHeading } from "../../shared/email.js";
import { verifyTurnstile } from "../../shared/turnstile.js";
import { getContent, fill } from "../../shared/content.js";

// GET  /api/enquiries  -> admin: all enquiries (newest first, unread first)
// POST /api/enquiries  -> public: contact-form submission
export async function onRequestGet(context) {
  const { env, data } = context;
  if (!data.session) return json({ error: "Not authenticated" }, 401);
  const { results } = await env.DB.prepare(
    "SELECT * FROM enquiries ORDER BY (status='new') DESC, created_at DESC"
  ).all();
  return json(results || []);
}

export async function onRequestPost(context) {
  const { request, env } = context;
  let b;
  try { b = await request.json(); } catch { return json({ error: "Bad request" }, 400); }

  const ts = await verifyTurnstile(env, b.turnstile_token, request.headers.get("CF-Connecting-IP"));
  if (!ts.ok) return json({ error: "Please complete the verification and try again." }, 400);

  const name = (b.name || "").toString().trim().slice(0, 120);
  const email = (b.email || "").toString().trim().slice(0, 200);
  if (!name) return json({ error: "Please enter your name." }, 400);
  if (!/^[^\s@"'<>&]+@[^\s@"'<>&]+\.[^\s@"'<>&]+$/.test(email)) return json({ error: "Please enter a valid email address." }, 400);

  const phone = (b.phone || "").toString().trim().slice(0, 60);
  const organisation = (b.organisation || "").toString().trim().slice(0, 160);
  const service = (b.service || "").toString().trim().slice(0, 160);
  const message = (b.message || "").toString().trim().slice(0, 4000);

  let row;
  try {
    const res = await env.DB.prepare(
      `INSERT INTO enquiries (name, email, phone, organisation, service, message)
       VALUES (?, ?, ?, ?, ?, ?) RETURNING *`
    ).bind(name, email, phone, organisation, service, message).all();
    row = res.results[0];
  } catch (e) {
    return json({ error: "Could not send your enquiry. Please try again." }, 500);
  }

  const to = env.BOOKING_TO || env.ADMIN_EMAIL;
  if (to) {
    const C = await getContent(env);
    const vars = { name };
    const pairs = [
      ["Name", name], ["Email", email], ["Phone", phone || "\u2014"],
      ["Organisation", organisation || "\u2014"], ["Interested in", service || "\u2014"],
      ["Message", message || "\u2014"],
    ];
    await sendEmail(env, {
      to,
      replyTo: email,
      subject: fill(C.email_enq_subject, vars),
      html: emailShell(
        emailHeading(fill(C.email_enq_heading, vars), fill(C.email_enq_intro, vars))
        + detailsTable(pairs)
        + `<p style="margin:18px 0 0;font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;font-size:13px;color:#5a6b63;">${esc(fill(C.email_enq_footnote, vars))}</p>`
      , env.SITE_URL),
    });
  }

  return json({ ok: true });
}
