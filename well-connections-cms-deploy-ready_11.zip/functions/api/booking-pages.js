import { json } from "../../shared/layout.js";

function slugify(s) {
  return (s || "")
    .toLowerCase()
    .replace(/&/g, " and ")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60);
}

// Normalise the questions payload before storing it as JSON.
function cleanQuestions(input) {
  if (!Array.isArray(input)) return "[]";
  const out = input
    .filter((q) => q && typeof q.label === "string" && q.label.trim())
    .slice(0, 20)
    .map((q) => ({
      label: String(q.label).trim().slice(0, 160),
      type: ["text", "textarea", "select", "email", "tel"].includes(q.type) ? q.type : "text",
      required: q.required ? 1 : 0,
      options: Array.isArray(q.options)
        ? q.options.map((o) => String(o).trim()).filter(Boolean).slice(0, 20)
        : [],
    }));
  return JSON.stringify(out);
}

// Blank string -> null, so the column falls back to the global settings.
function orNull(v) {
  if (v === undefined || v === null) return null;
  const s = String(v).trim();
  if (!s) return null;
  const n = parseInt(s, 10);
  return Number.isFinite(n) ? n : null;
}
function strOrNull(v) {
  if (v === undefined || v === null) return null;
  const s = String(v).trim();
  return s || null;
}

export async function onRequestGet(context) {
  const { env, data } = context;
  const isAdmin = !!data.session;
  const sql = isAdmin
    ? "SELECT * FROM booking_pages ORDER BY kind DESC, sort_order ASC, id ASC"
    : "SELECT * FROM booking_pages WHERE status='published' ORDER BY kind DESC, sort_order ASC, id ASC";
  const { results } = await env.DB.prepare(sql).all();
  return json(results || []);
}

export async function onRequestPost(context) {
  const { request, env } = context;
  let b;
  try { b = await request.json(); } catch { return json({ error: "Bad request" }, 400); }

  const name = (b.name || "").trim();
  if (!name) return json({ error: "Name is required" }, 400);

  let slug = slugify(b.slug || name);
  if (!slug) return json({ error: "Could not build a page address from that name" }, 400);

  const base = slug;
  for (let i = 2; i < 50; i++) {
    const clash = await env.DB.prepare("SELECT id FROM booking_pages WHERE slug=?").bind(slug).first();
    if (!clash) break;
    slug = `${base}-${i}`;
  }

  const kind = b.kind === "general" ? "general" : "organisation";
  const status = b.status === "draft" ? "draft" : "published";

  const { results } = await env.DB.prepare(
    `INSERT INTO booking_pages
       (name, slug, kind, organisation, intro, confirm_note,
        duration_min, buffer_min, days, time_start, time_end,
        lead_hours, horizon_days, timezone, questions,
        notes, notify_email, listed, status, sort_order)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) RETURNING *`
  ).bind(
    name, slug, kind,
    (b.organisation || "").trim(),
    (b.intro || "").trim(),
    (b.confirm_note || "").trim(),
    orNull(b.duration_min), orNull(b.buffer_min),
    strOrNull(b.days), strOrNull(b.time_start), strOrNull(b.time_end),
    orNull(b.lead_hours), orNull(b.horizon_days), strOrNull(b.timezone),
    cleanQuestions(b.questions),
    (b.notes || "").trim(),
    (b.notify_email || "").trim(),
    b.listed ? 1 : 0, status,
    Number.isFinite(+b.sort_order) ? +b.sort_order : 0
  ).all();

  return json(results[0], 201);
}
