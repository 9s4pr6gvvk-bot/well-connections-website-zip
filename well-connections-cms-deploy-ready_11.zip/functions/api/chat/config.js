import { json } from "../../../shared/layout.js";
import { getContent } from "../../../shared/content.js";

// Live-chat on/off switch, stored in app_settings under key "chat_enabled".
//
// GET  /api/chat/config -> public: { enabled }. The chat widget reads this on
//                          every page load and only shows itself when enabled.
// PUT  /api/chat/config -> admin: { enabled: true|false } toggles the widget.
//
// Default is ON when the setting has never been saved, so the widget is live
// as soon as this build deploys; the admin can switch it off at any time.

async function readEnabled(env) {
  try {
    const row = await env.DB.prepare(
      "SELECT value FROM app_settings WHERE key='chat_enabled'"
    ).first();
    if (!row) return true; // unset -> default on
    return row.value === "1";
  } catch {
    return true; // table missing -> behave as default on
  }
}

export async function onRequestGet(context) {
  const { env } = context;
  const enabled = await readEnabled(env);
  // Expose only the chat_* copy to the public widget (never email copy).
  const all = await getContent(env);
  const copy = {};
  for (const k of Object.keys(all)) if (k.startsWith("chat_")) copy[k] = all[k];
  return json({ enabled, copy });
}

export async function onRequestPut(context) {
  const { request, env, data } = context;
  // Middleware already gates admin writes, but check here too (defence in depth).
  if (!data.session) return json({ error: "Not authenticated" }, 401);

  let b;
  try { b = await request.json(); } catch { return json({ error: "Bad request" }, 400); }
  const value = b.enabled ? "1" : "0";

  try {
    await env.DB.prepare(
      `INSERT INTO app_settings (key, value, updated_at) VALUES ('chat_enabled', ?, datetime('now'))
       ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=datetime('now')`
    ).bind(value).run();
  } catch {
    return json({ error: "Could not save. Is the settings table set up? Run the bookings migration." }, 500);
  }

  return json({ enabled: value === "1" });
}
