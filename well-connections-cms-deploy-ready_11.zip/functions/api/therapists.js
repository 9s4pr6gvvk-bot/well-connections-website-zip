import { json } from "../../shared/layout.js";

const FIELDS = ["name", "role", "credentials", "photo_url", "profile_url", "teams", "bio", "accepting", "status", "sort_order"];

// Normalise teams to a pipe-delimited string: ['a','b'] -> '|a|b|'
function packTeams(v) {
  let arr = [];
  if (Array.isArray(v)) arr = v;
  else if (typeof v === "string") arr = v.split(/[|,]/);
  arr = arr.map((s) => String(s).trim()).filter(Boolean);
  return arr.length ? "|" + arr.join("|") + "|" : "";
}

function clean(input, base = {}) {
  const t = { ...base };
  for (const f of FIELDS) if (f in input) t[f] = input[f];
  t.name = (t.name || "").trim();
  t.teams = packTeams(t.teams);
  t.accepting = t.accepting ? 1 : 0;
  t.status = t.status === "draft" ? "draft" : "published";
  t.sort_order = Number.isFinite(+t.sort_order) ? +t.sort_order : 0;
  return t;
}

// GET /api/therapists[?team=slug]  -> admin: all; public: published only
export async function onRequestGet(context) {
  const { env, data, request } = context;
  const url = new URL(request.url);
  const team = url.searchParams.get("team");
  const isAdmin = !!data.session;

  let sql = "SELECT * FROM therapists";
  const binds = [];
  const where = [];
  if (!isAdmin) where.push("status='published'");
  if (team) { where.push("teams LIKE ?"); binds.push("%|" + team + "|%"); }
  if (where.length) sql += " WHERE " + where.join(" AND ");
  sql += " ORDER BY sort_order ASC, name ASC";

  const stmt = env.DB.prepare(sql);
  const { results } = await (binds.length ? stmt.bind(...binds) : stmt).all();
  return json(results || []);
}

export async function onRequestPost(context) {
  const { request, env } = context;
  let body;
  try { body = await request.json(); } catch { return json({ error: "Bad request" }, 400); }
  const t = clean(body);
  if (!t.name) return json({ error: "Name is required" }, 400);

  const { results } = await env.DB.prepare(
    `INSERT INTO therapists (name, role, credentials, photo_url, profile_url, teams, bio, accepting, status, sort_order)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?) RETURNING *`
  ).bind(t.name, t.role || "", t.credentials || "", t.photo_url || "", t.profile_url || "",
         t.teams || "", t.bio || "", t.accepting, t.status, t.sort_order).all();

  return json(results[0], 201);
}
