// Shared page shell for the public /team and /blog pages so they match the
// existing Well Connections home page (nav, logo, dropdown, CTA, footer).

// Booking is now handled by the on-site request flow. Linking to the home
// page with #book auto-opens the booking modal.
const BOOK_URL = "/#book";

const SITE = "https://wellconnections.co.uk";
const DEFAULT_OG_IMAGE = SITE + "/images/01-homepage-hero-sam-andrea.jpg";

function seoEscape(str) {
  return String(str || "")
    .replace(/&/g, "&amp;").replace(/"/g, "&quot;")
    .replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

export function layout({ title, description, body, canonical, image, ogType = "website", jsonLd, noindex = false }) {
  const desc = description || "";
  const img = image || DEFAULT_OG_IMAGE;
  const canon = canonical ? (canonical.startsWith("http") ? canonical : SITE + canonical) : "";
  const robots = noindex
    ? "noindex, nofollow"
    : "index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1";
  const jsonLdBlock = jsonLd
    ? `\n<script type="application/ld+json">\n${JSON.stringify(jsonLd, null, 2)}\n</script>`
    : "";
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>${seoEscape(title)}</title>
<meta name="description" content="${seoEscape(desc)}" />
<meta name="robots" content="${robots}" />
<meta name="theme-color" content="#1e3028" />${canon ? `\n<link rel="canonical" href="${seoEscape(canon)}" />` : ""}
<meta property="og:type" content="${ogType}" />
<meta property="og:site_name" content="Well Connections" />
<meta property="og:locale" content="en_GB" />${canon ? `\n<meta property="og:url" content="${seoEscape(canon)}" />` : ""}
<meta property="og:title" content="${seoEscape(title)}" />
<meta property="og:description" content="${seoEscape(desc)}" />
<meta property="og:image" content="${seoEscape(img)}" />
<meta property="og:image:alt" content="Well Connections — mental health and wellbeing support" />
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="${seoEscape(title)}" />
<meta name="twitter:description" content="${seoEscape(desc)}" />
<meta name="twitter:image" content="${seoEscape(img)}" />${jsonLdBlock}
<link rel="icon" href="/favicon.ico" sizes="any" />
<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png" />
<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png" />
<link rel="apple-touch-icon" href="/apple-touch-icon.png" />
<link rel="manifest" href="/site.webmanifest" />
<link rel="stylesheet" href="/fonts.css" />
<style>
  *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
  :root{
    --sage:#43744f;--sage-dark:#3d6b52;--sage-light:#b8d4c4;--sage-pale:#e8f2ec;
    --cream:#f4f7f5;--stone:#e4eae7;--bark-dark:#1e3028;--text:#1a2820;
    --text-muted:#5a6b63;--teal:#2d6e5e;--warm-white:#fbfcfb;
  }
  html{scroll-behavior:smooth}
  body{font-family:'Quicksand',sans-serif;background:#fff;color:var(--text);font-weight:400;line-height:1.7}
  a{color:var(--teal)}

  /* NAV (matches home page) */
  body>nav{position:sticky;top:0;z-index:100;padding:0 clamp(1.25rem,5%,4rem);display:grid;grid-template-columns:1fr auto 1fr;align-items:center;height:76px;background:#ffffff;backdrop-filter:blur(16px) saturate(140%);-webkit-backdrop-filter:blur(16px) saturate(140%);border-bottom:1px solid rgba(30,48,40,0.06);transition:height .4s cubic-bezier(.4,0,.2,1),background .4s ease,box-shadow .4s ease,border-color .4s ease}
  body>nav.scrolled{background:#ffffff;box-shadow:0 6px 30px rgba(30,48,40,0.09);border-bottom-color:transparent}
  .nav-logo{grid-column:1;justify-self:start}
  .nav-links{grid-column:2;justify-self:center}
  .nav-right{grid-column:3;justify-self:end;display:flex;align-items:center;gap:1rem}
  .nav-links>li>a{position:relative;padding:0.5rem 0}
  .nav-links>li>a::after{content:'';position:absolute;left:0;right:0;bottom:0;height:2px;background:var(--sage);transform:scaleX(0);transform-origin:left;transition:transform .22s ease}
  .nav-links>li>a:hover::after{transform:scaleX(1)}
  .nav-logo img{height:62px;width:auto;display:block}
  .nav-logo-mark{display:block;width:233px;height:65px;background-color:#608c8a;-webkit-mask:url('/images/wc-logo-lockup.png') no-repeat left center / contain;mask:url('/images/wc-logo-lockup.png') no-repeat left center / contain;transition:transform .4s cubic-bezier(.4,0,.2,1);transform-origin:left center}
  .nav-links{display:flex;gap:1.6rem;list-style:none;align-items:center}
  .nav-links a{text-decoration:none;color:var(--text);font-size:0.76rem;letter-spacing:0.09em;text-transform:uppercase;font-weight:500;transition:color .2s;white-space:nowrap}
  .nav-links a:hover{color:var(--sage-dark)}
  .nav-links>li>a.active{color:var(--sage-dark)}
  .nav-links>li>a.active::after{transform:scaleX(1)}
  .nav-dropdown{position:relative}
  .nav-dropdown>a{display:flex;align-items:center;gap:0.3rem}
  .nav-dropdown>a svg{transition:transform .2s}
  .nav-dropdown-menu{position:absolute;top:calc(100% + 0.75rem);left:50%;transform:translateX(-50%) translateY(-6px);background:rgba(255,255,255,0.98);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);border:1px solid rgba(30,48,40,0.07);border-top:2px solid var(--sage);border-radius:0 0 10px 10px;box-shadow:0 18px 44px rgba(30,48,40,0.14);min-width:232px;padding:0.4rem;opacity:0;pointer-events:none;transition:opacity .2s ease,transform .2s cubic-bezier(.4,0,.2,1);z-index:200}
  .nav-dropdown.open .nav-dropdown-menu{opacity:1;pointer-events:auto;transform:translateX(-50%) translateY(0)}
  .nav-dropdown.open>a svg{transform:rotate(180deg)}
  .nav-dropdown-menu a{display:block;padding:0.7rem 0.9rem;font-size:0.74rem;letter-spacing:0.07em;text-transform:uppercase;font-weight:500;color:var(--text-muted)!important;text-decoration:none;border-radius:6px;transition:background .15s,color .15s,padding-left .15s;white-space:nowrap}
  .nav-dropdown-menu a:hover{background:var(--sage-pale);color:var(--sage-dark)!important;padding-left:1.2rem}
  .nav-cta{display:inline-flex;align-items:center;gap:0.5rem;background:linear-gradient(135deg,var(--sage) 0%,var(--sage-dark) 100%);color:#fff!important;padding:0.72rem 1.35rem;border-radius:4px;font-weight:600!important;white-space:nowrap;transition:box-shadow .25s,transform .25s!important}
  .nav-cta:hover{color:#fff!important}
  .nav-cta .cta-arrow{transition:transform .25s ease}
  .nav-cta:hover .cta-arrow{transform:translateX(3px)}
  .nav-right .nav-cta{text-decoration:none;text-transform:uppercase;letter-spacing:0.05em;font-size:0.78rem;box-shadow:0 2px 10px rgba(90,138,106,0.28);transition:box-shadow .25s,transform .25s!important}
  .nav-right .nav-cta:hover{transform:translateY(-1px);box-shadow:0 4px 16px rgba(90,138,106,0.34)}

  /* HAMBURGER + MOBILE MENU (drill-down, matches home page) */
  body.menu-open{overflow:hidden}
  .nav-hamburger{display:none;background:none;border:none;cursor:pointer;flex-direction:column;gap:5px;padding:10px;min-width:44px;min-height:44px;justify-content:center;align-items:center}
  .nav-hamburger span{display:block;width:24px;height:2px;background:var(--text);border-radius:2px;transform-origin:center;transition:transform .3s cubic-bezier(.4,0,.2,1),opacity .2s ease}
  .nav-hamburger.is-active span:nth-child(1){transform:translateY(7px) rotate(45deg)}
  .nav-hamburger.is-active span:nth-child(2){opacity:0;transform:scaleX(.2)}
  .nav-hamburger.is-active span:nth-child(3){transform:translateY(-7px) rotate(-45deg)}
  .mobile-menu{position:fixed;top:76px;left:0;right:0;height:calc(100dvh - 76px);height:calc(100vh - 76px);background:var(--warm-white);border-top:1px solid var(--stone);z-index:99;overflow:hidden;visibility:hidden;opacity:0;transform:translateY(-6px);transition:opacity .28s ease,transform .28s ease,visibility 0s linear .28s}
  .mobile-menu.open{visibility:visible;opacity:1;transform:translateY(0);transition:opacity .28s ease,transform .28s ease}
  .mm-track{display:flex;width:200%;height:100%;transform:translateX(0);transition:transform .34s cubic-bezier(.4,0,.2,1)}
  .mobile-menu.submenu-open .mm-track{transform:translateX(-50%)}
  .mm-panel{width:50%;height:100%;overflow-y:auto;-webkit-overflow-scrolling:touch;padding:1.25rem 5% 2rem;box-sizing:border-box;display:flex;flex-direction:column;position:static;top:auto;align-items:stretch;grid-template-columns:none;background:none;backdrop-filter:none;-webkit-backdrop-filter:none;border:none;z-index:auto;transition:none}
  .mm-sub{visibility:hidden;transition:visibility 0s linear .34s}
  .mobile-menu.submenu-open .mm-sub{visibility:visible;transition:visibility 0s}
  .mobile-menu a,.mm-parent{text-decoration:none;color:var(--text);padding:1.05rem 0;border-bottom:1px solid var(--stone);font-size:1rem;font-weight:300;min-height:44px;display:flex;align-items:center}
  .mm-parent{justify-content:space-between;width:100%;background:none;border-top:none;border-left:none;border-right:none;cursor:pointer;font-family:inherit;text-align:left;color:var(--bark-dark)}
  .mm-parent .mm-chev{color:var(--text-muted);flex:none}
  .mm-sub a:last-child{border-bottom:none}
  .mobile-menu .mobile-cta{margin-top:1.25rem;background:var(--sage);color:#fff!important;justify-content:center;text-align:center;padding:1rem;border-radius:2px;font-weight:500;border:none}
  .mm-back{display:inline-flex;align-items:center;gap:.4rem;background:none;border:none;cursor:pointer;color:var(--teal);font-family:inherit;font-size:.82rem;font-weight:500;letter-spacing:.06em;text-transform:uppercase;padding:.35rem 0;margin-bottom:.75rem;min-height:44px;align-self:flex-start}
  .mm-sub-title{font-family:'League Spartan',sans-serif;font-size:1.5rem;font-weight:600;color:var(--bark-dark);padding-bottom:.75rem;margin-bottom:.25rem;border-bottom:1px solid var(--stone)}

  /* PAGE HEADER */
  .page-head{background:var(--bark-dark);color:#fff;padding:4rem 5%;text-align:center}
  .page-head .label{display:inline-block;font-size:0.7rem;letter-spacing:0.2em;text-transform:uppercase;color:var(--sage-light);font-weight:500;margin-bottom:0.9rem}
  .page-head h1{font-family:'League Spartan',sans-serif;font-weight:600;font-size:clamp(2rem,4vw,3rem);line-height:1.15}
  .page-head h1 em{font-style:normal;color:var(--sage-light)}
  .page-head p{max-width:600px;margin:1.1rem auto 0;color:rgba(255,255,255,0.72);font-size:0.98rem}
  .wrap{max-width:1160px;margin:0 auto;padding:4rem 5%}

  /* FOOTER (matches home page) */
  body > footer {
    background: #111816;
    border-top: 1px solid rgba(255,255,255,0.06);
  }
  .footer-main {
    max-width: 1200px;
    margin: 0 auto;
    padding: 4rem 5% 3rem;
    display: grid;
    grid-template-columns: 1.8fr 1fr 1fr 1.3fr;
    gap: 3rem;
  }
  .footer-brand img { height: 60px; width: auto; margin-bottom: 1.25rem; display: block; }
  .footer-logo-mark {
    display: block;
    width: 200px;
    height: 56px;
    background-color: #fff;
    -webkit-mask: url('/images/wc-logo-lockup.png') no-repeat left center / contain;
    mask: url('/images/wc-logo-lockup.png') no-repeat left center / contain;
    margin-bottom: 1.25rem;
  }
  .footer-brand p { font-size: 0.85rem; color: rgba(255,255,255,0.45); line-height: 1.8; max-width: 260px; margin-bottom: 1.5rem; }
  .footer-social { display: flex; gap: 0.75rem; }
  .footer-social a {
    width: 34px; height: 34px; border-radius: 50%;
    border: 1px solid rgba(255,255,255,0.15);
    display: flex; align-items: center; justify-content: center;
    color: rgba(255,255,255,0.45); text-decoration: none;
    transition: border-color 0.2s, color 0.2s;
  }
  .footer-social a:hover { border-color: var(--sage-light); color: var(--sage-light); }
  .footer-col h2 { font-size: 0.7rem; letter-spacing: 0.18em; text-transform: uppercase; color: var(--sage-light); font-weight: 500; margin-bottom: 1.25rem; }
  .footer-col ul { list-style: none; display: flex; flex-direction: column; gap: 0.65rem; }
  .footer-col ul a { font-size: 0.86rem; color: rgba(255,255,255,0.5); text-decoration: none; transition: color 0.2s; }
  .footer-col ul a:hover { color: rgba(255,255,255,0.9); }
  .footer-contact-item { display: flex; align-items: flex-start; gap: 0.65rem; margin-bottom: 0.9rem; }
  .footer-contact-item svg { color: var(--sage-light); flex-shrink: 0; margin-top: 1px; }
  .footer-contact-item a,
  .footer-contact-item span { font-size: 0.86rem; color: rgba(255,255,255,0.5); text-decoration: none; transition: color 0.2s; line-height: 1.5; }
  .footer-contact-item a:hover { color: rgba(255,255,255,0.9); }
  .footer-bottom {
    border-top: 1px solid rgba(255,255,255,0.07);
    padding: 1.25rem 5%;
    max-width: 1200px;
    margin: 0 auto;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 0.75rem;
  }
  .footer-bottom p { font-size: 0.75rem; color: rgba(255,255,255,0.6); }
  .footer-bottom a { color: rgba(255,255,255,0.72); text-decoration: none; transition: color 0.2s; }
  .footer-bottom a:hover { color: var(--sage-light); }

  @media(max-width:1100px){
    .nav-links{display:none}
    .nav-cta{display:none}
    .nav-hamburger{display:flex;min-width:44px;min-height:44px;justify-content:center;align-items:center}
  }
  @media(max-width:900px){
    .footer-main{grid-template-columns:1fr 1fr;gap:2.5rem}
  }
  @media(max-width:768px){
    body>nav{height:74px}
    .nav-logo-mark{width:187px;height:52px}
    .mobile-menu{top:74px;height:calc(100dvh - 74px);height:calc(100vh - 74px)}
  }
  @media(max-width:560px){
    .footer-main{grid-template-columns:1fr;gap:2rem;padding:3rem 5% 2rem}
    .footer-bottom{flex-direction:column;align-items:flex-start}
  }
</style>
</head>
<body>
<nav id="navbar">
  <a class="nav-logo" href="/" aria-label="Well Connections Home"><span class="nav-logo-mark" role="img" aria-label="Well Connections"></span></a>
  <ul class="nav-links" aria-label="Main navigation">
    <li class="nav-dropdown">
      <a href="/#pathways">Who We Support <svg width="10" height="10" viewBox="0 0 10 10" fill="currentColor"><path d="M1 3l4 4 4-4"/></svg></a>
      <div class="nav-dropdown-menu">
        <a href="/businesses">Businesses &amp; Employers</a>
        <a href="/schools">Schools &amp; Colleges</a>
        <a href="/charities">Charities &amp; Community</a>
        <a href="/personal-support">Individuals &amp; Families</a>
      </div>
    </li>
    <li><a href="/services">Services</a></li>
    <li><a href="/impact">Impact</a></li>
    <li><a href="/about">About</a></li>
    <li><a href="/blog">Insights</a></li>
    <li><a href="/contact">Contact</a></li>
  </ul>
  <div class="nav-right">
    <a href="${BOOK_URL}" class="nav-cta">Book a Discovery Call <span class="cta-arrow" aria-hidden="true">&rarr;</span></a>
    <button class="nav-hamburger" id="hamburger" aria-label="Toggle navigation" aria-expanded="false">
      <span></span><span></span><span></span>
    </button>
  </div>
</nav>

<div class="mobile-menu" id="mobileMenu" role="navigation" aria-label="Mobile navigation">
  <div class="mm-track" id="mmTrack">
    <nav class="mm-panel mm-main" aria-label="Main menu">
      <button type="button" class="mm-parent" id="mmOpenSupport" aria-haspopup="true" aria-expanded="false" aria-controls="mmSub">
        <span>Who We Support</span>
        <svg class="mm-chev" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="9 6 15 12 9 18"/></svg>
      </button>
      <a href="/services">Services</a>
      <a href="/impact">Impact</a>
      <a href="/about">About</a>
      <a href="/blog">Insights</a>
      <a href="/contact">Contact</a>
      <a href="${BOOK_URL}" class="mobile-cta">Book a Discovery Call →</a>
    </nav>
    <nav class="mm-panel mm-sub" id="mmSub" aria-label="Who We Support" aria-hidden="true">
      <button type="button" class="mm-back" id="mmBack">
        <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="15 18 9 12 15 6"/></svg>
        <span>Back</span>
      </button>
      <span class="mm-sub-title">Who We Support</span>
      <a href="/businesses">Businesses &amp; Employers</a>
      <a href="/schools">Schools &amp; Colleges</a>
      <a href="/charities">Charities &amp; Community</a>
      <a href="/personal-support">Individuals &amp; Families</a>
    </nav>
  </div>
</div>
${body}
<footer role="contentinfo">
  <div class="footer-main">

    <!-- Brand -->
    <div class="footer-brand">
      <span class="footer-logo-mark" role="img" aria-label="Well Connections"></span>
      <p>Workplace wellbeing, mental health training, coaching and counselling for businesses, schools, charities and organisations across Yorkshire and the UK.</p>
      <!-- TODO: Replace href="#" with real social profile URLs (Sam to supply) -->
      <div class="footer-social">
        <a href="https://www.facebook.com/WellConnectionsUK" aria-label="Facebook" target="_blank" rel="noopener">
          <svg width="14" height="14" fill="currentColor" viewBox="0 0 24 24"><path d="M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3z"/></svg>
        </a>
        <a href="https://www.instagram.com/wellconnections/" aria-label="Instagram" target="_blank" rel="noopener">
          <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1112.63 8 4 4 0 0116 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg>
        </a>
        <a href="https://www.linkedin.com/company/well-connections/" aria-label="LinkedIn" target="_blank" rel="noopener">
          <svg width="14" height="14" fill="currentColor" viewBox="0 0 24 24"><path d="M16 8a6 6 0 016 6v7h-4v-7a2 2 0 00-2-2 2 2 0 00-2 2v7h-4v-7a6 6 0 016-6zM2 9h4v12H2z"/><circle cx="4" cy="4" r="2"/></svg>
        </a>
      </div>
    </div>

    <!-- Services -->
    <div class="footer-col">
      <h2>Services</h2>
      <ul>
        <li><a href="/#services">Adult Therapy</a></li>
        <li><a href="/#services">Wellbeing</a></li>
        <li><a href="/team/child-teens">Children &amp; Young People's Therapy</a></li>
        <li><a href="/#services">Couples Counselling</a></li>
        <li><a href="/#services">Parenting Support</a></li>
        <li><a href="/#services">Coaching</a></li>
        <li><a href="/#pathways">Organisations</a></li>
      </ul>
    </div>

    <!-- Company -->
    <div class="footer-col">
      <h2>Company</h2>
      <ul>
        <li><a href="/about">About Us</a></li>
        <li><a href="/team">Meet the Team</a></li>
        <li><a href="/faqs">FAQs</a></li>
        <li><a href="/blog">Insights</a></li>
        <li><a href="${BOOK_URL}">Free Discovery Call</a></li>
        <li><a href="/book">Book Online</a></li>
      </ul>
    </div>

    <!-- Contact -->
    <div class="footer-col">
      <h2>Contact</h2>
      <div class="footer-contact-item">
        <svg width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 01-2.25 2.25h-15a2.25 2.25 0 01-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25m19.5 0v.243a2.25 2.25 0 01-1.07 1.916l-7.5 4.615a2.25 2.25 0 01-2.36 0L3.32 8.91a2.25 2.25 0 01-1.07-1.916V6.75"/></svg>
        <a href="mailto:info@wellconnections.co.uk">info@wellconnections.co.uk</a>
      </div>
      <div class="footer-contact-item">
        <svg width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 002.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 01-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 00-1.091-.852H4.5A2.25 2.25 0 002.25 4.5v2.25z"/></svg>
        <div>
          <a href="tel:07725035029" style="display:block;">Andrea: 07725 035029</a>
          <a href="tel:07736317617" style="display:block;">Sam: 07736 317617</a>
        </div>
      </div>
      <div class="footer-contact-item">
        <svg width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z"/></svg>
        <span><a href="/therapy-harrogate">Harrogate</a> · <a href="/therapy-leeds">Leeds</a> · <a href="/therapy-ripon">Ripon</a> · <a href="/therapy-york">York</a><br />Yorkshire &amp; the North East</span>
      </div>
    </div>

  </div>
  <div class="footer-bottom">
    <p>&copy; ${new Date().getFullYear()} Well Connections. All rights reserved.</p>
    <p>Designed by <a href="https://www.franks-media.co.uk" target="_blank" rel="noopener">Franks Media</a> &nbsp;&middot;&nbsp; <a href="/privacy">Privacy Policy</a> &nbsp;&middot;&nbsp; <a href="/terms">Terms</a></p>
  </div>
</footer>
<script>
  (function(){
    var h=document.getElementById('hamburger'),m=document.getElementById('mobileMenu');
    if(h&&m){
      var mmOpenSupport=document.getElementById('mmOpenSupport'),mmBack=document.getElementById('mmBack'),mmSub=document.getElementById('mmSub');
      function closeMenu(){m.classList.remove('open');m.classList.remove('submenu-open');h.classList.remove('is-active');h.setAttribute('aria-expanded','false');if(mmOpenSupport)mmOpenSupport.setAttribute('aria-expanded','false');if(mmSub)mmSub.setAttribute('aria-hidden','true');document.body.classList.remove('menu-open');}
      h.addEventListener('click',function(){
        var open=m.classList.toggle('open');
        h.classList.toggle('is-active',open);
        h.setAttribute('aria-expanded',open?'true':'false');
        document.body.classList.toggle('menu-open',open);
        if(!open)m.classList.remove('submenu-open');
      });
      if(mmOpenSupport)mmOpenSupport.addEventListener('click',function(){m.classList.add('submenu-open');mmOpenSupport.setAttribute('aria-expanded','true');if(mmSub)mmSub.setAttribute('aria-hidden','false');});
      if(mmBack)mmBack.addEventListener('click',function(){m.classList.remove('submenu-open');if(mmOpenSupport)mmOpenSupport.setAttribute('aria-expanded','false');if(mmSub)mmSub.setAttribute('aria-hidden','true');});
      m.querySelectorAll('a').forEach(function(a){a.addEventListener('click',closeMenu);});
    }
    // nav dropdown (hover, with close delay) (matches home page)
    document.querySelectorAll('.nav-dropdown').forEach(function(dd){
      var t=null;
      var open=function(){clearTimeout(t);dd.classList.add('open');};
      var close=function(){t=setTimeout(function(){dd.classList.remove('open');},200);};
      dd.addEventListener('mouseenter',open);
      dd.addEventListener('mouseleave',close);
      var menu=dd.querySelector('.nav-dropdown-menu');
      if(menu){menu.addEventListener('mouseenter',open);menu.addEventListener('mouseleave',close);}
    });
    document.addEventListener('click',function(e){
      if(!e.target.closest('.nav-dropdown')){
        document.querySelectorAll('.nav-dropdown').forEach(function(d){d.classList.remove('open');});
      }
    });
    // nav shadow on scroll (matches home page)
    var nv=document.getElementById('navbar');
    if(nv){
      var onScroll=function(){nv.classList.toggle('scrolled',window.scrollY>10);};
      onScroll();
      window.addEventListener('scroll',onScroll,{passive:true});
    }
  })();
</script>
<script src="/nav-active.js" defer></script>
<script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>
<script src="/turnstile.js" defer></script>
<script src="/book-modal.js" defer></script>
<script src="/enquiry-modal.js" defer></script>
<script src="/chat-widget.js" defer></script>
</body>
</html>`;
}

export function json(data, status = 200, extraHeaders = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json", ...extraHeaders },
  });
}
