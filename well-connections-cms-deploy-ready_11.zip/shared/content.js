// Editable site copy: every chat-widget string and every outgoing-email string,
// with its default. Admins override any of these from the Content tab; overrides
// live in app_settings under keys prefixed "txt_". Anything not overridden falls
// back to the default here, so the site always has sensible copy.
//
// Placeholders in curly braces are filled in at send time, e.g. {name}, {when}.
// They are shown to admins as hints so they don't delete them by accident.

// Groups drive both the admin UI (order, labels, help) and the schema of valid
// keys. `type` is "text" (single line) or "area" (multi-line).
export const CONTENT_GROUPS = [
  {
    title: "Live chat widget",
    note: "The text shown in the chat bubble on the website.",
    fields: [
      { key: "chat_launcher", label: "Bubble button label", type: "text", def: "Message us" },
      { key: "chat_title", label: "Panel title", type: "text", def: "Message us" },
      { key: "chat_subtitle", label: "Panel subtitle", type: "text", def: "Not monitored continuously. Not for emergencies." },
      { key: "chat_intro", label: "Opening message (shown before the first reply)", type: "area", def: "Leave us a message and we will get back to you within one working day. This is not monitored continuously and is not for emergencies. If you need urgent help please contact your GP or call 999." },
      { key: "chat_name_ph", label: "Name field placeholder", type: "text", def: "Your name" },
      { key: "chat_email_ph", label: "Email field placeholder", type: "text", def: "Email (optional)" },
      { key: "chat_first_ph", label: "First-message box placeholder", type: "text", def: "How can we help?" },
      { key: "chat_reply_ph", label: "Reply box placeholder", type: "text", def: "Type a message..." },
      { key: "chat_note", label: "Small print under the box", type: "area", def: "We aim to reply within one working day. Not an emergency service." },
    ],
  },
  {
    title: "Email: new enquiry (sent to you)",
    note: "When a visitor submits the contact form. {name} = their name.",
    fields: [
      { key: "email_enq_subject", label: "Subject", type: "text", def: "New enquiry: {name}" },
      { key: "email_enq_heading", label: "Heading", type: "text", def: "New website enquiry" },
      { key: "email_enq_intro", label: "Intro line", type: "text", def: "Someone has got in touch through the website." },
      { key: "email_enq_footnote", label: "Footnote", type: "text", def: "View it in the dashboard under Enquiries." },
    ],
  },
  {
    title: "Email: new booking (sent to you)",
    note: "When a visitor requests a consultation. {name} = their name, {when} = the slot.",
    fields: [
      { key: "email_bk_admin_subject", label: "Subject", type: "text", def: "New booking request: {name}, {when}" },
      { key: "email_bk_admin_heading", label: "Heading", type: "text", def: "New consultation request" },
      { key: "email_bk_admin_intro", label: "Intro line", type: "text", def: "A discovery call has been requested through the website." },
      { key: "email_bk_admin_footnote", label: "Footnote", type: "text", def: "Open the dashboard to accept or decline." },
    ],
  },
  {
    title: "Email: booking received (sent to the visitor)",
    note: "The automatic acknowledgement. {name} = their name. The requested time is shown in a box between the intro and body.",
    fields: [
      { key: "email_bk_ack_subject", label: "Subject", type: "text", def: "We've received your consultation request" },
      { key: "email_bk_ack_greeting", label: "Greeting", type: "text", def: "Hi {name}," },
      { key: "email_bk_ack_intro", label: "Intro line (before the time box)", type: "text", def: "Thanks for requesting a discovery call. Here's what you asked for:" },
      { key: "email_bk_ack_body", label: "Body line (after the time box)", type: "area", def: "We'll confirm by email shortly. If that time turns out not to work, we'll be in touch to find another that does." },
    ],
  },
  {
    title: "Email: booking confirmed (sent to the visitor)",
    note: "When you accept a booking. {name} = their name, {when} = the confirmed time.",
    fields: [
      { key: "email_bk_accept_subject", label: "Subject", type: "text", def: "Your consultation is confirmed" },
      { key: "email_bk_accept_greeting", label: "Greeting", type: "text", def: "Hi {name}," },
      { key: "email_bk_accept_line1", label: "Line before the time", type: "text", def: "Good news, your consultation is confirmed for:" },
      { key: "email_bk_accept_line2", label: "Line after the time", type: "area", def: "We look forward to speaking with you. If you need to rearrange, just reply to this email." },
    ],
  },
  {
    title: "Email: booking declined (sent to the visitor)",
    note: "When you decline a booking. {name} = their name, {when} = the requested time.",
    fields: [
      { key: "email_bk_decline_subject", label: "Subject", type: "text", def: "About your consultation request" },
      { key: "email_bk_decline_greeting", label: "Greeting", type: "text", def: "Hi {name}," },
      { key: "email_bk_decline_line1", label: "First line", type: "area", def: "Thank you for your request for {when}. Unfortunately we're not able to confirm that time." },
      { key: "email_bk_decline_line2", label: "Second line", type: "area", def: "Please reply to this email or book another slot on our website and we'll be glad to help." },
    ],
  },
  {
    title: "Shared email sign-off",
    note: "Used at the end of visitor emails. Use a new line for the name.",
    fields: [
      { key: "email_signoff", label: "Sign-off", type: "area", def: "Warm regards,\nThe Well Connections team" },
    ],
  },
];

// Flat { key: default } map built from the groups.
export const CONTENT_DEFAULTS = (() => {
  const out = {};
  for (const g of CONTENT_GROUPS) for (const f of g.fields) out[f.key] = f.def;
  return out;
})();

export const CONTENT_KEYS = Object.keys(CONTENT_DEFAULTS);

// Merge defaults with any admin overrides stored in app_settings (txt_*).
export async function getContent(env) {
  const out = { ...CONTENT_DEFAULTS };
  try {
    const { results } = await env.DB.prepare(
      "SELECT key, value FROM app_settings WHERE key LIKE 'txt_%'"
    ).all();
    for (const r of results || []) {
      const k = r.key.slice(4); // strip "txt_"
      if (k in out && r.value != null) out[k] = r.value;
    }
  } catch {
    // Table missing -> defaults are fine.
  }
  return out;
}

// Replace {placeholder} tokens with values. Unknown tokens are left as-is.
export function fill(str, vars) {
  return String(str == null ? "" : str).replace(/\{(\w+)\}/g, (m, k) =>
    (vars && k in vars && vars[k] != null) ? String(vars[k]) : m
  );
}

// HTML-escape (kept local to avoid a circular import with email.js).
function esc(s) {
  return String(s == null ? "" : s)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

// Fill placeholders, escape, and turn newlines into <br> for safe HTML output.
export function htmlText(str, vars) {
  return esc(fill(str, vars)).replace(/\n/g, "<br>");
}
