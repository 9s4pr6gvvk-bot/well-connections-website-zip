# Deploy notes: terms, schools wording, logos, footer details (19 Oct 2026)

One migration (see 3). Deploy with `npx wrangler pages deploy`.

1. **/terms** now shows Sam's Website and Booking Terms (with a link to the
   Privacy Notice). The text is the default in `functions/terms.js`; a `terms`
   row in `app_settings` still overrides it, same as /privacy.
2. **Schools page**: new "Working alongside your school team" section after
   "Examples of how we work". The intro is unchanged.
3. **Organisation logos, managed in the dashboard (new Logos tab)**.
   **Run the migration once before deploying:**
   ```
   npx wrangler d1 execute wellconnections-cms --remote --file=./migrate-logos.sql
   ```
   This creates the `logos` table and adds the four carousel labels
   (Families, Schools, Organisations, Individuals) in Sam's order.
   In the Logos tab Sam can upload a logo (PNG/JPG/WebP; SVG is blocked by the
   upload endpoint for security), tick where it shows (Home page strip,
   Schools, Businesses, Charities), publish or keep as draft, and reorder with
   the arrows. Public pages read `/api/logos` via `public/logo-wall.js`.
   Each page's logo section stays hidden until it has a published logo; the
   homepage "Proud to work with" strip (under the pathway cards, where Sam
   marked it) needs at least 3. `?logos=preview` on the homepage shows the strip
   with fewer than 3.
4. **Footer** (all pages): Well Connections Ltd, registered in England and
   Wales, company number 15991251, ICO registration ZB782600. Registered office
   address still to add once Sam supplies it.

---

# Deploy notes: newest first in the dashboard (19 Oct 2026)

Code only, no migration. Bookings and Enquiries now list newest first (by when
they came in). Previously Bookings showed pending first, then by appointment
date, and Enquiries showed unread first. Status badges and the unread count are
unchanged. Chat (latest message first) and Blogs (newest first) already worked
this way; Testimonials keep their manual order because it sets the order on the
website.

---

# Deploy notes: calendar invites on accepted bookings (19 Oct 2026)

Code only. No database migration. Deploy with `npx wrangler pages deploy`.

When a booking is accepted in the dashboard:
- **Well Connections** (`BOOKING_TO`, currently info@) gets a new "Accepted:
  <name>, <time>" email with an invite attached. Opening it adds the booking to
  Outlook, with the client's name, phone (as the location), email and every
  booking answer in the event notes, plus a 15-minute reminder.
- **The client** gets their usual acceptance email with their own invite
  attached (service, time, how to change or cancel; no internal details).

The invites are METHOD:PUBLISH, so Outlook offers "Add to calendar" and never
sends a reply to anyone. Each booking has a fixed UID, so opening an invite again
updates the same event rather than duplicating it.

The booking view in the dashboard now:
- shows every answer the client gave (it only showed the standard fields before)
- has an "Add to calendar (.ics)" link on accepted bookings, to download the
  invite again (`GET /api/bookings/:id/ics`, admin only)

Declines are unchanged (no invite). Nothing is written to Outlook directly; the
calendar sync stays read-only.

New file: `shared/ics.js`. `sendEmail` in `shared/email.js` now accepts
`attachments` (passed to Resend).

---

# Deploy notes: Outlook calendar sync and partner booking pages (19 Oct 2026)

## 1. Outlook calendar sync (free/busy)
Busy times in Sam's published Outlook calendar are now removed from every
booking page and from the homepage booking form. Read-only: nothing is ever
written to Outlook.

Set it up in the dashboard, Blanket Availability tab, "Outlook calendar" card:
paste the ICS link, tick "Block out busy times", Save. The card then shows when it
last synced, how many busy blocks are in the booking window, and the next few
busy times so they can be checked against Outlook. "Sync now" forces a refresh.

How it behaves:
- Busy, tentative and away (out of office) all block time. Free and
  "working elsewhere" do not. Cancelled meetings are ignored.
- Repeating meetings are expanded properly, including single occurrences that
  were moved or deleted in Outlook, all-day events, and the GMT/BST change.
- Outlook is fetched at most every 5 minutes and the result is cached in
  `app_settings`, so page views don't wait on Outlook.
- If Outlook can't be reached, the last good copy is used for up to 48 hours,
  and the dashboard shows the error. After that, times come from working hours
  alone. That is a deliberate fail-open: every booking is still a request Sam
  accepts or declines, so an outage can't confirm a clash by itself.
- The link is private. It is stored in `app_settings` and only returned by the
  admin-only `/api/calendar` endpoint, never by the public site. It is not in
  any file in this repo, so paste it in the dashboard rather than committing it.

New files: `shared/calendar.js` (fetch, ICS parsing, recurrence expansion),
`shared/tz.js` (timezone helpers, now shared with the availability engine),
`functions/api/calendar.js` (GET status, PUT save, POST sync now).

## 2. Bookings now block by time range, not just start time
Previously a slot was only taken if another booking started at exactly the same
minute. With pages on 15, 20 and 30 minutes that let a 20-minute booking at
10:15 land inside a 30-minute session at 10:00. Pending and accepted bookings now
block their full length (`bookings.duration_min`). No migration needed.

## 3. Partner booking pages, matched to the old Calendly forms
Run these two, in this order:
```
npx wrangler d1 execute wellconnections-cms --remote --file=./migrate-booking-form-options.sql
npx wrangler d1 execute wellconnections-cms --remote --file=./migrate-booking-pages-oct.sql
```
The first adds three columns to `booking_pages` (`phone_required`, `note_label`,
`note_hidden`). Deploy the code and run it together: the dashboard's booking-page
save needs the columns.

Each page now carries the Calendly event's full description and its questions,
word for word and in the same order (obvious typos fixed, en/em dashes removed).
- Arthritis UK, 30 min, `/book/arthritis-uk`: 10 questions including the
  1 to 10 scale (dropdown), availability (tick boxes), the "not a crisis service"
  acknowledgement and the employee check.
- HS4L Staff Consultation Call, 20 min, `/book/harrogate-skills-for-living`:
  what prompted the call, and who the sessions are for. (Calendly's event was set
  to 30 minutes though its own text said 20; Sam's email says 20.)
- Intro Call: Wellbeing Support for Workplaces & Schools, 20 min,
  `/book/intro-call`: unlisted, built so it is ready if Sam wants it. 20 minutes
  per Sam's email (Calendly was 15). Calendly's "Add guests" is not replicated.
- HLC staff: set to draft.

Form changes on every booking page:
- First name and last name (was one "Your name" field), as Calendly had.
- Phone can be made required per page; it is on for the three pages above.
- New question types: "Choose one" (radio buttons) and "Tick boxes". Choices for
  dropdowns, radios and tick boxes are now entered one per line in the dashboard.
- The standard "Anything else we should know?" box can be hidden or reworded per
  page. It is hidden on these three because their questions already include it.
- Server checks a radio/dropdown answer is one of the listed choices and keeps
  only real choices for tick boxes. Long questions render in normal case instead
  of the small uppercase label style.
- Intros now keep paragraphs: the first sits under the heading, the rest in an
  "about this call" panel; email addresses become links.

## 4. Blanket Availability safeguard
"Apply to every booking page" now leaves Session length unticked by default, so
one click can't reset the partner pages to the standard 15 minutes.

## Performance
Timezone formatters and daily UTC offsets are now cached, which also speeds up
ordinary slot generation.

---

# Deploy notes — blanket availability, Blogs, chat hours (Oct 2026)

No database migration for any of these three. Everything is stored in
`app_settings` (key/value) or by clearing columns that already exist, so this is
a plain deploy.

## 1. Blanket availability
The Availability tab is now **Blanket Availability**. The settings at the top are
unchanged, but underneath there is an "Apply to every booking page" panel that:
- lists every booking page and says which settings it currently sets for itself
  (e.g. Arthritis UK on a 30-minute session while discovery calls are 15)
- lets you tick which of the eight scheduling settings to push
- clears those settings on every page, so they all follow the blanket hours from
  then on, including the next time you change them

Clearing is deliberate: a booking page only uses its own value where one is set,
so clearing makes it inherit permanently rather than copying the numbers across
and leaving two sets to drift apart. Names, intros, questions and notify
addresses are untouched. The confirmation names the pages that will change.

New endpoint: `POST /api/booking-pages/apply-all`, admin-only (Access-gated like
every other write), accepting `{ fields: [...], slugs: [...] }`. It only ever
accepts the eight scheduling columns, so no other column can be nulled through
it.

### No days ticked
On both tabs an empty day list is a valid "closed", not an error:
- **Blanket Availability** with no days ticked offers no booking times at all;
  visitors get the "no times available" message and the enquiry form. Booking
  pages that set their own days keep them until you apply the blanket settings.
- **Chat opening hours** with no days ticked keeps chat closed all week, and the
  bubble comes off the site regardless of the away-message setting, since there
  are no hours to tell people about.

Both ask for confirmation before saving, and both show a line under the day
buttons saying what an empty list will do.

## 2. Insights renamed to Blogs
`/blog` URLs are unchanged, so no redirects and no SEO loss. Renamed:
- nav, mobile menu and footer on every page (`shared/layout.js` and the static
  HTML pages), 33 labels in total
- the page title, meta description and the Blog JSON-LD name in `functions/blog.js`
- the eyebrow label on `/blog` and on the homepage blog section, which both said
  "Journal", so the page now calls itself what the nav calls it
- the dashboard tab, "Blog Posts" to "Blogs"

The editorial headline "Insight & wellbeing." is kept on both, since it reads as
a headline rather than a label. Say if you want that changed too.

## 3. Live chat opening hours
The Messages tab keeps the master on/off switch and gains an opening-hours panel:
days, opening and closing time, timezone, and what happens outside those hours.
- **Show an away message** (default) keeps the bubble, and opening it gives the
  away message plus a button through to the enquiry form.
- **Hide chat completely** removes the bubble outside hours, same as the switch.

A closing time earlier than the opening time is treated as running past midnight
(18:00 to 02:00 works). Times are evaluated in the configured timezone, so BST
and GMT are handled without you touching anything twice a year.

`POST /api/chat/message` refuses messages whenever chat is closed, master switch
or hours, and returns the away copy. That matters because a page left open past
closing time still has a working send button: the widget swaps itself to the away
message when that happens, so nothing lands in an inbox nobody is watching.

Defaults keep today's behaviour: master switch on, hours off. Nothing changes on
the site until you turn hours on.

New copy in the Content tab under "Live chat: outside opening hours" (panel
title, away message, button label, and the message shown if someone sends
anyway). `{hours}` in that copy is filled with your opening hours.

---

# Deploy notes — practitioner enquiries (Oct 2026)

## What was wrong
The "Send an enquiry" button on a practitioner's profile page (`/therapist/<slug>`)
linked to `/#contact`, which opened the shared enquiry lightbox. That form had no
idea which profile it was opened from, so the enquiry was saved and emailed as a
plain website enquiry. Nobody could tell it was meant for a particular
practitioner, and the practitioner was never notified.

## What changed
- `functions/therapist/[slug].js` — the enquiry button now reads "Send an enquiry
  to <first name>" and carries the profile slug and name on the link.
- `public/enquiry-modal.js` — when opened from a profile the lightbox is titled
  "Enquire about <name>", shows a line confirming who the enquiry is for, and
  sends `therapist_slug` with the submission. Opening it from anywhere else
  resets back to the general enquiry wording, so a practitioner never carries
  over to the next enquiry.
- `functions/api/enquiries.js` — resolves that slug against published
  practitioners in the database (the browser only ever sends a slug, so a name or
  inbox cannot be forged in the payload), saves the practitioner on the enquiry,
  puts "Enquiry for <name>" at the top of the notification email, uses the new
  subject line, and copies the practitioner in when they have an enquiry email
  set. An unknown, unpublished or tampered slug is ignored and the enquiry is
  treated as a general one.
- `public/admin/index.html` — practitioner shown on the enquiry list and on the
  enquiry detail; new optional "Enquiry email" field on the therapist editor.
- `shared/content.js` — new editable copy group "Email: enquiry for a
  practitioner", with `{therapist}` available alongside `{name}`.
- `functions/api/therapists.js`, `functions/api/therapists/[id].js` — read and
  write `enquiry_email`, and strip it from public API responses so practitioner
  addresses are never served to the website.

## Database migration to run
```
npx wrangler d1 execute wellconnections-cms --remote --file=./migrate-enquiry-therapist.sql
```
Adds `enquiries.therapist` and `therapists.enquiry_email`. If the code goes live
before the migration runs, enquiries are still saved (without the practitioner
column) and the email still names the practitioner, so nothing is lost.

## Practitioner notifications
The main inbox (`BOOKING_TO`) receives every enquiry as before. A practitioner is
only copied in once an address is set against their profile in the dashboard
under Therapists, so this is off by default and opt-in per person. Those
enquiries contain client contact details, so set an address only where the
practitioner is expecting them.

---

# Deploy notes — Well Connections consolidated amendments (Sept 2026)

## Files changed
- `public/index.html` — nav bar fixed (was missing entirely), hero copy/image/trust
  bar, new "What We Take Care Of" section, testimonials swapped to short versions,
  About/Governance rewritten (no more Sam/Andrea bios), Personal Support panel.
- `public/businesses/index.html` — new heading/copy, image swap, new MH First Aid
  & Workplace Wellbeing Training section (Gerry Spencer), new "What HR & Managers
  Need to Know" section, nav link added.
- `public/schools/index.html` — image swap, upgraded to full approved testimonials
  (Joanna Fox + Alison Knight), nav link added.
- `public/charities/index.html` — image swap, nav link added (copy already covered
  everything requested).
- `public/personal-support/index.html` — new page. Six routes, each linking to the
  matching `/team/<slug>` page, reviews, free-consultation CTA.
- `public/images/` — new folder, all 11 images from the pack, static (no R2).

## Database migrations to run (in this order)
```
npx wrangler d1 execute wellconnections-cms --remote --file=./migrate-testimonials-v2.sql
npx wrangler d1 execute wellconnections-cms --remote --file=./migrate-faqs-v2.sql
npx wrangler d1 execute wellconnections-cms --remote --file=./migrate-team-name.sql
npx wrangler d1 execute wellconnections-cms --remote --file=./migrate-rate-limits.sql
npx wrangler d1 execute wellconnections-cms --remote --file=./migrate-booking-durations.sql
```

`migrate-booking-durations.sql` sets general enquiries / discovery calls to a
15-minute free consultation and organisation partner pages (Arthritis UK,
Harrogate Skills for Living, and any future `kind='organisation'` page) to 30
minutes. It updates the live rows the seed file's `WHERE NOT EXISTS` inserts
leave untouched, and sets the global `booking_duration` (the homepage "Book a
Free Discovery Call" flow) to 15.

Logo: the nav and footer on `public/index.html` now use the full horizontal
lockup (`public/images/wc-logo-lockup.png`) as a CSS mask, coloured sage
(`#608c8a`) in the nav and white in the footer. Colour is controlled in CSS via
`background-color`, so the logo can be recoloured without editing the image.
Notification recipient (`BOOKING_TO` in `wrangler.toml`) is now
`info@wellconnections.co.uk`.

`migrate-rate-limits.sql` adds the per-IP rate limiting for the public
booking / enquiry / chat forms. Until it runs, the limiter fails open (forms
work as before, no cap), so it is safe to deploy first and migrate right after.
These replace the old testimonial/FAQ seed content and rename the Child & Teens
team to "Children and Young People's Therapy Team" per Sam's naming request.

## Flagged before going live
- **Images 09, 10, 11** (NEOSS/Gerry Spencer training photo, workshop materials,
  and the real workshop photo on the Schools page) are genuine event photography.
  Left in place as requested, but Sam's email says to reconfirm permission before
  publishing these — check with her before this goes live.
- **Personal Support page is new** — not yet linked from anywhere except the nav,
  hero button, and the homepage panel. Worth a quick proofread before launch.

## Bug fix — photos cropping out Sam/Andrea
`.about-image-wrap img` was forcing a portrait 4:5 crop on desktop, a leftover
from the old template which was designed for portrait headshot-style photos.
Every new landscape pack photo dropped into that container (02, 04, 05, 06, 07,
08, 09) was losing roughly half its width, which is what was cropping people
out. Changed to `aspect-ratio: 3/2` across all five pages (index, businesses,
schools, charities, personal-support) to match the mobile breakpoint that was
already set correctly.

Also fixed the homepage hero: it was anchored to `background-position: right
center`, which crops relative to the image's absolute right edge. On narrower
windows that cut off most of both women. Repositioned to `63% center`, which
is roughly where the pair actually sit in the frame, so the crop stays
centered on them at any width instead of being anchored to an edge they aren't
against. Also fixed the hero's leftover alt text (still said "Bluebell
woodland path" from the old image).

## Also completed this round
- **"How We Work"** homepage section rewritten to Sam's exact 5-step structure
  (We listen / We design / We coordinate / We deliver / We review), replacing the
  old 7-step version.
- **FAQs split across audience pages** — Businesses, Schools, Charities and
  Personal Support each now have a short accordion of the most relevant questions
  from Sam's approved copy, sitting above the contact CTA, with a "See all FAQs"
  link through to the full `/faqs` page (which carries everything via the DB
  migration).

## Gap-check against Sam's original email (final pass)
Went through her email line by line against the built site and fixed five
remaining gaps:
- **New standalone `/services` page** — she asked for a dedicated Services
  page giving an overview of all 7 services, each explaining the organisational
  problem it addresses. This didn't exist before (nav just anchored to the
  homepage services section). Built it, and repointed the "Services" nav link
  across all pages to `/services`.
- **Nick Bousfield's full NEOSS testimonial** added as a pull quote on the
  Businesses page (previously only the short version was live, in the homepage
  carousel).
- **"What We Take Care Of"** now has all 7 bullets as listed items — "adapt or
  scale support when needs change" was previously folded into the caption text
  only.
- **Emergency disclaimer added to the main homepage enquiry form** — "not
  monitored for emergencies, replies within one working day." This existed on
  the new Personal Support page but not on the actual contact form
  organisations will use.
- **Arthritis UK Wellbeing Coaching link confirmed working**, unaffected by
  this round's changes. It's a direct/unlisted link at `/book/arthritis-uk`
  (not surfaced in navigation) — that's by design for per-organisation booking
  pages, but worth confirming with Sam that's what she wants.

## Hero refinements (per Frankie's request)
- Reduced hero text sizes for a more restrained, professional feel: h1 max
  down from 4.6rem to 3.3rem, eyebrow/paragraph sizes and margins tightened
  to match, button gap reduced.
- Fixed heads getting cropped by the nav bar: the nav is fixed and opaque
  (76px tall) and sits on top of the hero image at every screen size. The
  original photo only had about 12% headroom above their heads, which the
  nav was eating into on most real screen heights. Re-cropped
  01-homepage-hero-sam-andrea.jpg to trim excess floor/carpet space off the
  bottom (there was a lot, the original was a mostly-empty-floor shot),
  which increases the headroom-to-height ratio to ~18% without losing any
  of the two women. Comfortably clears the nav on any realistic viewport
  height now.

## Hero — second pass (photo still cropping heads, heading wrap)
Screenshot showed heads still clipped by the nav bar even after the bottom-crop
fix. Turned out my headroom estimate was wrong — measured it properly this
time with pixel analysis and found there was only ~58px of real headroom in
the source photo (not ~110px as I'd eyeballed), which the bottom-only trim
couldn't fix without cropping the photo down to almost nothing.

Fixed properly this time: extended the canvas upward using a stretched,
blurred copy of a safe ceiling strip (well above the heads), crossfaded into
the original so the seam is invisible, then trimmed the excess floor at the
bottom for a natural hero-banner ratio (1672x891). Headroom is now ~29% of
the image height, comfortably clearing the nav at any realistic browser
height.

Also added a manual line break in the H1 ("Mental health and / wellbeing
support," instead of wrapping mid-phrase) so the first two lines read more
evenly and match the natural wrap already happening on the line below.

## Photo placement re-check against 00-IMAGE-USAGE-GUIDE.txt
Went through every placement against the actual guide file (not just the main
amendments email). One real mismatch found and fixed:
- **Image 04** is guided for "How We Work, partnership approach or
  organisational insights section" but was sitting in the homepage's "One
  Trusted Partner" intro instead. Swapped it with image 02 (guided for
  general About-page use), which was in the "Why Well Connections Exists"
  section, a better fit for 04's "partnership/insights" framing. No layout
  change, just swapped which photo sits where.
- Confirmed all other placements match the guide (05/06/07/08 on their
  respective audience pages, 09/10 on the MHFA section, 11 on Schools).
- Confirmed alt text on the brand-imagery photos (01, 02, 04) doesn't imply
  a specific documented event, per the guide's caution — they're captioned
  generically.
- Note: image 04 still has the AI-artifact issue (malformed hand) flagged
  earlier — this placement fix doesn't resolve that, still needs a
  replacement photo from Sam regardless of which section it sits in.

## Fixed: Google reviews were still on the homepage
Sam's email: "Individual testimonials and Google reviews should sit within
this personal-support journey rather than the organisational homepage." This
had been missed — a full 3-review Google Reviews block (Natalie Waring,
Naomi Antcliff, Rebecca Bussy) was still live on the homepage. Removed it
from index.html entirely and added the two missing reviews (Naomi, Rebecca)
to the Personal Support page, which previously only had Natalie's. That page
now shows all three, in a 3-column grid.

## Section order changed (Frankie's UX call, diverges from Sam's stated order)
Sam's email lists "Organisation-led introduction" before "Clear routes for
businesses, schools and charities" (points 1 and 2). Frankie asked for this
reversed for UX reasons — "Who We Work With" (pathways/routes) now comes
before "One Trusted Partner" (org intro) on the homepage. Flagged to Frankie
that this contradicts her stated order before making the change; he
confirmed he wants it regardless. Worth mentioning to Sam when this goes
back to her, since it's a deliberate deviation from her brief, not an
oversight.
