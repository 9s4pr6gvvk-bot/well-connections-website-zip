UPDATE therapists SET bio='I am a Chartered and Registered Forensic Psychologist with over 10 years of post-qualification experience. I have extensive experience of conducting assessments, delivering psychological therapy and providing training and supervision.

I offer evidence-based psychological therapy and coaching tailored to client need. My overarching aim is to help people work through periods of challenge and change. I understand that in times of difficulty, the mental health system can be tough to navigate.

I believe passionately that people can recover from the most hard-going of circumstances. I take the view that people are much more than a collection of symptoms or diagnoses. My aim is to help people find hope and optimism during periods of struggle.

My practice is particularly informed by the principles of Acceptance and Commitment Therapy (ACT). Through ACT I believe people can learn to take value led action; ''to do what matters'', to find meaning and fulfilment even in the most difficult of times.

The majority of my career has been in the public sector, typically working with people with extensive and complex needs who have reached points of crisis. In the last two years my move into private practice has enabled me to explore my passion for more preventative work; helping people to develop the skills and resilience to manage life''s challenges.' WHERE name='Aiveen Smith';
