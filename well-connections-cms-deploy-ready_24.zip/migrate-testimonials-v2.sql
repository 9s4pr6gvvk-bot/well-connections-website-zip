-- Replace rotating homepage carousel with Sam's approved short, decision-maker-
-- focused versions (email: "consolidated amendments", Sept 2026).
-- Run once:
--   npx wrangler d1 execute wellconnections-cms --remote --file=./migrate-testimonials-v2.sql
--
-- Clears out the old full-length Emma Richards / Cathryn Sutherland rows from
-- migrate-testimonials-seed.sql and replaces the whole carousel with the five
-- approved short quotes. Full versions of these testimonials belong on the
-- relevant audience pages (Schools, Businesses) as case-study pull quotes,
-- not in this rotating carousel.

DELETE FROM testimonials WHERE author IN ('Emma Richards', 'Cathryn Sutherland', 'Joanna Fox', 'Alison Knight', 'Mrs Alison Knight', 'Nick Bousfield');

INSERT INTO testimonials (quote, author, detail, status, sort_order) VALUES
('The training has had a positive impact on how we talk about mental health and workplace wellbeing, and has helped to open up useful conversations around support across the organisation.',
 'Nick Bousfield', 'Managing Director, NEOSS International', 'published', 10),

('Working with Well Connections has provided us with a responsive and collaborative service that works closely with our pastoral and safeguarding teams.',
 'Mrs Alison Knight', 'Assistant Headteacher – Senior SENCo and DSL, King James''s School, Knaresborough', 'published', 20),

('The clarity of reporting and the quality of the figures shared have been invaluable in helping us evidence our provision to governors and key stakeholders.',
 'Emma Richards', 'Finance Director, Duchy College', 'published', 30),

('Well Connections gives us access to a trusted and experienced team of practitioners, enabling us to bring in specialist support that responds to the needs of our pupils, families and staff.',
 'Cathryn Sutherland', 'Attendance Champion, King James''s School', 'published', 40),

('The support from Well Connections has made a tangible difference to our pupils, with clear communication, strong oversight and a partner who understands schools.',
 'Joanna Fox', 'Principal, Duchy College', 'published', 50);

SELECT id, author, detail FROM testimonials ORDER BY sort_order;
