-- Rename "Child & Teens Therapy Team" to the client-approved
-- "Children and Young People's Therapy Team" (consolidated amendments email).
-- Run once:
--   npx wrangler d1 execute wellconnections-cms --remote --file=./migrate-team-name.sql

UPDATE teams
SET name = 'Children and Young People''s Therapy Team'
WHERE slug = 'child-teens';

SELECT id, name, slug FROM teams ORDER BY sort_order;
