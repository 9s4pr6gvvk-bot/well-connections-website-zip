-- Reverts migrate-name-corrections.sql. Run ONLY if that file was already
-- applied to the live database and the original spellings were correct:
--   npx wrangler d1 execute wellconnections-cms --remote --file=./revert-name-corrections.sql

UPDATE therapists
SET name = 'Claire Sullivan',
    updated_at = datetime('now')
WHERE name = 'Clare Sullivan';

UPDATE therapists
SET name = 'Leah Prysce',
    updated_at = datetime('now')
WHERE name = 'Leah Pryce';

-- The team rename (Child & Teens -> Children and Young People's Therapy Team)
-- is left in place; it did not change a slug. Remove the block below only if
-- that rename was also unwanted.
-- UPDATE teams SET name = 'Child & Teens', updated_at = datetime('now') WHERE slug = 'child-teens';

-- Verify:
SELECT name FROM therapists WHERE name IN ('Claire Sullivan','Leah Prysce','Clare Sullivan','Leah Pryce');
