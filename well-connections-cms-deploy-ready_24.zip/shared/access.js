// Verifies a Cloudflare Access (Zero Trust) identity at the origin.
//
// Setup: put a Cloudflare Access self-hosted application in front of /admin
// (the UI). Access issues a signed JWT (the CF_Authorization cookie, also sent
// as the Cf-Access-Jwt-Assertion header on covered paths) that rides to /api on
// the same hostname. This module verifies that JWT so admin API calls are
// protected by your Zero Trust policy WITHOUT gating the public /api endpoints
// (booking, enquiry, chat), which must stay open to visitors.
//
// Two environment variables are required (find them on the Access application):
//   CF_ACCESS_TEAM_DOMAIN  e.g. "yourteam.cloudflareaccess.com"
//   CF_ACCESS_AUD          the Application Audience (AUD) tag
// If they are not set, admin writes fail closed (blocked) — secure by default.

let CERTS_CACHE = { keys: null, exp: 0 };

function b64urlToBytes(str) {
  str = str.replace(/-/g, "+").replace(/_/g, "/");
  while (str.length % 4) str += "=";
  const bin = atob(str);
  const arr = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
  return arr;
}

async function getKeys(teamDomain) {
  const now = Date.now();
  if (CERTS_CACHE.keys && CERTS_CACHE.exp > now) return CERTS_CACHE.keys;
  const url = `https://${teamDomain}/cdn-cgi/access/certs`;
  const res = await fetch(url, { cf: { cacheTtl: 3600 } });
  if (!res.ok) return null;
  const data = await res.json();
  CERTS_CACHE = { keys: data.keys || [], exp: now + 60 * 60 * 1000 };
  return CERTS_CACHE.keys;
}

// Returns the identity payload if the request carries a valid Access JWT, else null.
export async function verifyAccess(context) {
  const { request, env } = context;
  const teamDomain = env.CF_ACCESS_TEAM_DOMAIN;
  const aud = env.CF_ACCESS_AUD;
  if (!teamDomain || !aud) return null; // fail closed until configured

  // Token comes as the Cf-Access-Jwt-Assertion header (covered paths) or the
  // CF_Authorization cookie (rides to same-host paths like /api).
  let token = request.headers.get("Cf-Access-Jwt-Assertion");
  if (!token) {
    const cookie = request.headers.get("Cookie") || "";
    const m = cookie.match(/(?:^|;\s*)CF_Authorization=([^;]+)/);
    if (m) token = m[1];
  }
  if (!token || token.split(".").length !== 3) return null;

  const [h, p, s] = token.split(".");
  let header, payload;
  try {
    header = JSON.parse(new TextDecoder().decode(b64urlToBytes(h)));
    payload = JSON.parse(new TextDecoder().decode(b64urlToBytes(p)));
  } catch { return null; }

  // Issuer + audience + expiry
  // Cloudflare Access signs tokens with issuer https://<team>.cloudflareaccess.com,
  // which is exactly the team domain we fetch keys from. Rejecting any other
  // issuer stops a validly signed token from a different Access team being reused.
  if (payload.iss !== `https://${teamDomain}`) return null;
  const auds = Array.isArray(payload.aud) ? payload.aud : [payload.aud];
  if (!auds.includes(aud)) return null;
  if (!payload.exp || payload.exp < Math.floor(Date.now() / 1000)) return null;

  const keys = await getKeys(teamDomain);
  if (!keys) return null;
  const jwk = keys.find((k) => k.kid === header.kid);
  if (!jwk) return null;

  let key;
  try {
    key = await crypto.subtle.importKey(
      "jwk", jwk,
      { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
      false, ["verify"]
    );
  } catch { return null; }

  const signed = new TextEncoder().encode(`${h}.${p}`);
  let ok = false;
  try {
    ok = await crypto.subtle.verify("RSASSA-PKCS1-v1_5", key, b64urlToBytes(s), signed);
  } catch { return null; }
  if (!ok) return null;

  return { sub: payload.sub || "admin", email: payload.email || null };
}
