// Outlook calendar sync (free/busy).
//
// Sam publishes her Outlook calendar as an ICS link. We read it, work out every
// busy block over the booking horizon (including repeating meetings, moved or
// cancelled occurrences and all-day events), and the availability engine drops
// any slot that overlaps one. Nothing is ever written back to Outlook.
//
// Settings live in app_settings:
//   calendar_ics_url        the published ICS link (admin only, never served publicly)
//   calendar_sync_enabled   "1" to use it, "0" to ignore it
//   calendar_busy_cache     last good result: {"fetched_at": ms, "intervals": [[start,end],...]}
//   calendar_last_error     last failure message, blank when the last sync worked
//   calendar_last_attempt   ms timestamp of the last fetch attempt
//
// Failure policy: if Outlook can't be reached, the last good copy is used for up
// to 48 hours. After that the site carries on offering times from the working
// hours alone, because every booking is a request Sam accepts or declines, so a
// stale calendar can never confirm a clash on its own. The dashboard shows the
// error so it gets noticed.

import { tzParts, wallToUTC, isValidTimeZone } from "./tz.js";

const FRESH_MS = 5 * 60 * 1000;          // refetch at most every 5 minutes
const STALE_LIMIT_MS = 48 * 3600 * 1000; // how long a last good copy stays usable
const FETCH_TIMEOUT_MS = 8000;
const WINDOW_BACK_MS = 2 * 86400000;
const WINDOW_AHEAD_MS = 125 * 86400000;  // horizon is capped at 120 days
const MAX_INTERVALS = 5000;

let memo = null; // per-isolate cache: { at, url, result }

// ─────────────────────────────────────────────────────────────────────────────
// Settings
// ─────────────────────────────────────────────────────────────────────────────

async function readKeys(env, keys) {
  const out = {};
  try {
    const marks = keys.map(() => "?").join(",");
    const { results } = await env.DB.prepare(
      `SELECT key, value FROM app_settings WHERE key IN (${marks})`
    ).bind(...keys).all();
    for (const r of results || []) out[r.key] = r.value;
  } catch { /* table missing: treat as not configured */ }
  return out;
}

async function writeKey(env, key, value) {
  try {
    await env.DB.prepare(
      `INSERT INTO app_settings (key, value, updated_at) VALUES (?, ?, datetime('now'))
       ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=datetime('now')`
    ).bind(key, value).run();
  } catch { /* best effort */ }
}

export async function getCalendarConfig(env) {
  const s = await readKeys(env, ["calendar_ics_url", "calendar_sync_enabled"]);
  const url = (s.calendar_ics_url || "").trim();
  return { url, enabled: s.calendar_sync_enabled === "1" && !!url };
}

export async function saveCalendarConfig(env, { url, enabled }) {
  if (url !== undefined) {
    await writeKey(env, "calendar_ics_url", url);
    // A new link means the old cache describes a different calendar.
    await writeKey(env, "calendar_busy_cache", "");
    await writeKey(env, "calendar_last_error", "");
    memo = null;
  }
  if (enabled !== undefined) await writeKey(env, "calendar_sync_enabled", enabled ? "1" : "0");
}

// Accepts the link exactly as Outlook gives it. webcal:// is the same feed over https.
export function normaliseIcsUrl(raw) {
  let s = String(raw || "").trim();
  if (!s) return "";
  s = s.replace(/^webcals?:\/\//i, "https://");
  let u;
  try { u = new URL(s); } catch { return null; }
  if (u.protocol !== "https:") return null;
  return u.toString();
}

// ─────────────────────────────────────────────────────────────────────────────
// Busy intervals for the availability engine
// ─────────────────────────────────────────────────────────────────────────────

// Returns { enabled, intervals: [[startMs, endMs], ...], fetchedAt, error, stale }
export async function getBusy(env, { force = false, fallbackTz = "Europe/London" } = {}) {
  const cfg = await getCalendarConfig(env);
  if (!cfg.enabled) return { enabled: false, intervals: [], fetchedAt: 0, error: "", stale: false };

  const now = Date.now();
  if (!force && memo && memo.url === cfg.url && now - memo.at < FRESH_MS) return memo.result;

  const saved = await readKeys(env, ["calendar_busy_cache", "calendar_last_error", "calendar_last_attempt"]);
  let cache = null;
  try { cache = saved.calendar_busy_cache ? JSON.parse(saved.calendar_busy_cache) : null; } catch { cache = null; }
  const lastAttempt = parseInt(saved.calendar_last_attempt, 10) || 0;

  // Another request refreshed it recently: use the shared copy.
  if (!force && cache && now - (cache.fetched_at || 0) < FRESH_MS) {
    const result = { enabled: true, intervals: cache.intervals || [], fetchedAt: cache.fetched_at, error: "", stale: false };
    memo = { at: now, url: cfg.url, result };
    return result;
  }
  // A recent attempt failed: don't hammer Outlook on every page view.
  if (!force && saved.calendar_last_error && now - lastAttempt < FRESH_MS) {
    const result = fromCache(cache, now, saved.calendar_last_error);
    memo = { at: now, url: cfg.url, result };
    return result;
  }

  await writeKey(env, "calendar_last_attempt", String(now));
  let result;
  try {
    const text = await fetchIcs(cfg.url);
    const intervals = busyFromIcs(text, {
      fallbackTz,
      from: now - WINDOW_BACK_MS,
      to: now + WINDOW_AHEAD_MS,
    });
    await writeKey(env, "calendar_busy_cache", JSON.stringify({ fetched_at: now, intervals }));
    await writeKey(env, "calendar_last_error", "");
    result = { enabled: true, intervals, fetchedAt: now, error: "", stale: false };
  } catch (e) {
    const msg = String((e && e.message) || e).slice(0, 300);
    await writeKey(env, "calendar_last_error", msg);
    result = fromCache(cache, now, msg);
  }
  memo = { at: now, url: cfg.url, result };
  return result;
}

function fromCache(cache, now, error) {
  if (cache && now - (cache.fetched_at || 0) < STALE_LIMIT_MS) {
    return { enabled: true, intervals: cache.intervals || [], fetchedAt: cache.fetched_at, error, stale: true };
  }
  return { enabled: true, intervals: [], fetchedAt: cache ? cache.fetched_at : 0, error, stale: true };
}

async function fetchIcs(url) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), FETCH_TIMEOUT_MS);
  let res;
  try {
    res = await fetch(url, {
      signal: ctrl.signal,
      headers: { accept: "text/calendar, text/plain;q=0.8, */*;q=0.5", "user-agent": "WellConnections-Booking/1.0" },
      redirect: "follow",
    });
  } catch (e) {
    throw new Error(e && e.name === "AbortError" ? "Outlook did not respond in time." : "Could not reach the calendar link.");
  } finally {
    clearTimeout(timer);
  }
  if (res.status === 404 || res.status === 410) throw new Error("The calendar link no longer works. It may have been unpublished or reset in Outlook.");
  if (!res.ok) throw new Error(`The calendar link returned an error (HTTP ${res.status}).`);
  const text = await res.text();
  if (!/BEGIN:VCALENDAR/i.test(text)) throw new Error("That link did not return a calendar. Use the ICS link from Outlook's Publish calendar settings, not the HTML one.");
  return text;
}

// True if [start, end) overlaps any busy interval. `intervals` must be sorted.
export function overlapsBusy(intervals, start, end) {
  let lo = 0, hi = intervals.length - 1;
  // Find the first interval whose end is after `start`.
  while (lo <= hi) {
    const mid = (lo + hi) >> 1;
    if (intervals[mid][1] <= start) lo = mid + 1; else hi = mid - 1;
  }
  return lo < intervals.length && intervals[lo][0] < end;
}

// ─────────────────────────────────────────────────────────────────────────────
// ICS parsing
// ─────────────────────────────────────────────────────────────────────────────

// Outlook writes Windows timezone names. These cover every zone Well Connections
// is likely to see; anything unknown falls back to the booking timezone.
const WINDOWS_TZ = {
  "gmt standard time": "Europe/London",
  "greenwich standard time": "Atlantic/Reykjavik",
  "utc": "UTC",
  "coordinated universal time": "UTC",
  "w. europe standard time": "Europe/Berlin",
  "romance standard time": "Europe/Paris",
  "central europe standard time": "Europe/Budapest",
  "central european standard time": "Europe/Warsaw",
  "e. europe standard time": "Europe/Bucharest",
  "fle standard time": "Europe/Helsinki",
  "gtb standard time": "Europe/Athens",
  "irish standard time": "Europe/Dublin",
  "eastern standard time": "America/New_York",
  "central standard time": "America/Chicago",
  "mountain standard time": "America/Denver",
  "pacific standard time": "America/Los_Angeles",
  "india standard time": "Asia/Kolkata",
  "aus eastern standard time": "Australia/Sydney",
  "tokyo standard time": "Asia/Tokyo",
  "china standard time": "Asia/Shanghai",
  "singapore standard time": "Asia/Singapore",
  "arabian standard time": "Asia/Dubai",
};

function resolveTz(tzid, fallback) {
  if (!tzid) return fallback;
  const t = tzid.replace(/^"|"$/g, "").trim();
  if (/^(utc|gmt|z)$/i.test(t)) return "UTC";
  if (t.includes("/") && isValidTimeZone(t)) return t;
  const win = WINDOWS_TZ[t.toLowerCase()];
  if (win) return win;
  if (/london|edinburgh|dublin|lisbon/i.test(t)) return "Europe/London";
  return fallback;
}

function unfold(text) {
  return text.replace(/\r\n?/g, "\n").replace(/\n[ \t]/g, "").split("\n");
}

function parseLine(line) {
  // NAME;PARAM=VALUE;PARAM="quoted:value":VALUE
  let inQ = false, colon = -1;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (c === '"') inQ = !inQ;
    else if (c === ":" && !inQ) { colon = i; break; }
  }
  if (colon < 0) return null;
  const head = line.slice(0, colon);
  const value = line.slice(colon + 1);
  const parts = head.split(";");
  const name = parts.shift().toUpperCase();
  const params = {};
  for (const p of parts) {
    const eq = p.indexOf("=");
    if (eq > 0) params[p.slice(0, eq).toUpperCase()] = p.slice(eq + 1).replace(/^"|"$/g, "");
  }
  return { name, params, value };
}

const DAY_MS = 86400000;
const dayNum = (y, m, d) => Math.floor(Date.UTC(y, m - 1, d) / DAY_MS);
const fromDayNum = (n) => { const dt = new Date(n * DAY_MS); return [dt.getUTCFullYear(), dt.getUTCMonth() + 1, dt.getUTCDate()]; };
const weekday = (n) => ((n % 7) + 11) % 7; // 0=Sun … 6=Sat (1970-01-01 was a Thursday)
const daysInMonth = (y, m) => new Date(Date.UTC(y, m, 0)).getUTCDate();
const WD = { SU: 0, MO: 1, TU: 2, WE: 3, TH: 4, FR: 5, SA: 6 };

// A DTSTART/DTEND/EXDATE value -> { isDate, y, m, d, hh, mm, ss, tz, ms }
function parseDate(value, params, fallbackTz) {
  const v = (value || "").trim();
  let m = v.match(/^(\d{4})(\d{2})(\d{2})$/);
  if (m || (params && params.VALUE === "DATE" && (m = v.match(/^(\d{4})(\d{2})(\d{2})/)))) {
    const y = +m[1], mo = +m[2], d = +m[3];
    return { isDate: true, y, m: mo, d, hh: 0, mm: 0, ss: 0, tz: fallbackTz, ms: wallToUTC(y, mo, d, 0, 0, fallbackTz).getTime() };
  }
  m = v.match(/^(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})(\d{2})?(Z)?$/);
  if (!m) return null;
  const y = +m[1], mo = +m[2], d = +m[3], hh = +m[4], mi = +m[5], ss = +(m[6] || 0);
  if (m[7]) {
    return { isDate: false, y, m: mo, d, hh, mm: mi, ss, tz: "UTC", ms: Date.UTC(y, mo - 1, d, hh, mi, ss) };
  }
  const tz = resolveTz(params && params.TZID, fallbackTz);
  return { isDate: false, y, m: mo, d, hh, mm: mi, ss, tz, ms: wallToUTC(y, mo, d, hh, mi, tz, ss).getTime() };
}

function parseDuration(v) {
  const m = String(v || "").trim().match(/^([+-])?P(?:(\d+)W)?(?:(\d+)D)?(?:T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?)?$/);
  if (!m) return null;
  const ms = ((+(m[2] || 0)) * 7 * DAY_MS) + ((+(m[3] || 0)) * DAY_MS) +
    ((+(m[4] || 0)) * 3600000) + ((+(m[5] || 0)) * 60000) + ((+(m[6] || 0)) * 1000);
  return m[1] === "-" ? -ms : ms;
}

function parseRule(v) {
  const r = {};
  for (const part of String(v || "").split(";")) {
    const [k, val] = part.split("=");
    if (k && val !== undefined) r[k.toUpperCase()] = val;
  }
  if (!["DAILY", "WEEKLY", "MONTHLY", "YEARLY"].includes(r.FREQ)) return null;
  const ints = (s) => (s || "").split(",").map((x) => parseInt(x, 10)).filter((n) => Number.isFinite(n) && n !== 0);
  return {
    freq: r.FREQ,
    interval: Math.max(1, parseInt(r.INTERVAL, 10) || 1),
    count: r.COUNT ? Math.max(1, parseInt(r.COUNT, 10) || 1) : 0,
    until: r.UNTIL || "",
    byday: (r.BYDAY || "").split(",").map((s) => {
      const mm = s.trim().toUpperCase().match(/^([+-]?\d{1,2})?(SU|MO|TU|WE|TH|FR|SA)$/);
      return mm ? { n: mm[1] ? parseInt(mm[1], 10) : 0, wd: WD[mm[2]] } : null;
    }).filter(Boolean),
    bymonthday: ints(r.BYMONTHDAY),
    bymonth: ints(r.BYMONTH),
    bysetpos: ints(r.BYSETPOS),
    wkst: WD[(r.WKST || "MO").toUpperCase()] ?? 1,
  };
}

// Days of one month (as day numbers) that a MONTHLY/YEARLY rule selects.
function monthDays(rule, y, m, startDay) {
  const dim = daysInMonth(y, m);
  let days;
  if (rule.byday.length || rule.bymonthday.length) {
    const fromMonthDay = rule.bymonthday.length
      ? new Set(rule.bymonthday.map((n) => (n > 0 ? n : dim + n + 1)).filter((n) => n >= 1 && n <= dim))
      : null;
    days = [];
    for (let d = 1; d <= dim; d++) {
      if (fromMonthDay && !fromMonthDay.has(d)) continue;
      if (rule.byday.length) {
        const wd = weekday(dayNum(y, m, d));
        const hit = rule.byday.some((b) => {
          if (b.wd !== wd) return false;
          if (!b.n) return true;
          return b.n > 0 ? Math.ceil(d / 7) === b.n : Math.ceil((dim - d + 1) / 7) === -b.n;
        });
        if (!hit) continue;
      }
      days.push(d);
    }
  } else {
    const [, , d0] = fromDayNum(startDay);
    days = d0 <= dim ? [d0] : [];
  }
  if (rule.bysetpos.length && days.length) {
    const picked = new Set();
    for (const p of rule.bysetpos) {
      const idx = p > 0 ? p - 1 : days.length + p;
      if (idx >= 0 && idx < days.length) picked.add(days[idx]);
    }
    days = days.filter((d) => picked.has(d));
  }
  return days.map((d) => dayNum(y, m, d));
}

// Yields day numbers (in the event's own timezone) on which the rule fires, in order.
function* ruleDays(rule, startDay, fromDay, toDay) {
  const LIMIT = 60000;
  let guard = 0;
  // Without COUNT we can jump straight to the window; COUNT has to be counted from the start.
  const begin = rule.count ? startDay : Math.max(startDay, fromDay - 1);
  const [y0, m0] = fromDayNum(startDay);

  if (rule.freq === "DAILY" || rule.freq === "WEEKLY") {
    const wdays = rule.byday.length ? new Set(rule.byday.map((b) => b.wd)) : null;
    const months = rule.bymonth.length ? new Set(rule.bymonth) : null;
    const mdays = rule.bymonthday.length ? rule.bymonthday : null;
    const weekStart = (n) => n - ((weekday(n) - rule.wkst + 7) % 7);
    const w0 = weekStart(startDay);
    const defaultWd = weekday(startDay);
    for (let n = begin; n <= toDay && guard < LIMIT; n++, guard++) {
      if (rule.freq === "DAILY") {
        if ((n - startDay) % rule.interval) continue;
        if (wdays && !wdays.has(weekday(n))) continue;
      } else {
        if (((weekStart(n) - w0) / 7) % rule.interval) continue;
        if (!(wdays ? wdays.has(weekday(n)) : weekday(n) === defaultWd)) continue;
      }
      if (months || mdays) {
        const [yy, mm, dd] = fromDayNum(n);
        if (months && !months.has(mm)) continue;
        if (mdays) {
          const dim = daysInMonth(yy, mm);
          if (!mdays.some((x) => (x > 0 ? x : dim + x + 1) === dd)) continue;
        }
      }
      yield n;
    }
    return;
  }

  // MONTHLY / YEARLY: step month by month.
  const [by, bm] = fromDayNum(begin);
  let idx = by * 12 + (bm - 1);
  const idx0 = y0 * 12 + (m0 - 1);
  const [ty, tm] = fromDayNum(toDay);
  const lastIdx = ty * 12 + (tm - 1);
  for (; idx <= lastIdx && guard < 4000; idx++, guard++) {
    const y = Math.floor(idx / 12), m = (idx % 12) + 1;
    if (rule.freq === "MONTHLY") {
      if ((idx - idx0) % rule.interval) continue;
      if (rule.bymonth.length && !rule.bymonth.includes(m)) continue;
    } else {
      if ((y - y0) % rule.interval) continue;
      const months = rule.bymonth.length ? rule.bymonth : [m0];
      if (!months.includes(m)) continue;
    }
    for (const n of monthDays(rule, y, m, startDay)) {
      if (n < startDay) continue;
      if (n > toDay) return;
      yield n;
    }
  }
}

function isFreeEvent(ev) {
  if ((ev.STATUS || "").toUpperCase() === "CANCELLED") return true;
  if ((ev.TRANSP || "").toUpperCase() === "TRANSPARENT") return true;
  const bs = (ev["X-MICROSOFT-CDO-BUSYSTATUS"] || "").toUpperCase();
  if (bs === "FREE" || bs === "WORKINGELSEWHERE") return true;
  if ((ev.SUMMARY || "").trim().toLowerCase() === "free") return true;
  return false;
}

// Main entry point: ICS text -> merged, sorted busy intervals inside [from, to].
export function busyFromIcs(text, { fallbackTz = "Europe/London", from, to }) {
  const events = [];
  let cur = null, depth = 0;
  for (const raw of unfold(text)) {
    const line = raw.trim() ? raw : "";
    if (!line) continue;
    const up = line.toUpperCase();
    if (up === "BEGIN:VEVENT") { cur = { EXDATE: [] }; depth = 0; continue; }
    if (!cur) continue;
    if (up === "END:VEVENT") { events.push(cur); cur = null; continue; }
    if (up.startsWith("BEGIN:")) { depth++; continue; } // VALARM etc.
    if (up.startsWith("END:")) { depth = Math.max(0, depth - 1); continue; }
    if (depth) continue;
    const p = parseLine(line);
    if (!p) continue;
    if (p.name === "EXDATE") cur.EXDATE.push(p);
    else if (["DTSTART", "DTEND", "RECURRENCE-ID"].includes(p.name)) cur[p.name] = p;
    else cur[p.name] = p.value;
  }

  // Occurrences moved or cancelled individually, keyed by series UID.
  const overridden = new Map();
  for (const ev of events) {
    if (!ev["RECURRENCE-ID"] || !ev.UID) continue;
    const rid = parseDate(ev["RECURRENCE-ID"].value, ev["RECURRENCE-ID"].params, fallbackTz);
    if (!rid) continue;
    if (!overridden.has(ev.UID)) overridden.set(ev.UID, new Set());
    overridden.get(ev.UID).add(rid.isDate ? `d${dayNum(rid.y, rid.m, rid.d)}` : rid.ms);
  }

  const out = [];
  const push = (s, e) => { if (e > s && e > from && s < to && out.length < MAX_INTERVALS) out.push([s, e]); };

  for (const ev of events) {
    if (!ev.DTSTART || isFreeEvent(ev)) continue;
    const start = parseDate(ev.DTSTART.value, ev.DTSTART.params, fallbackTz);
    if (!start) continue;

    // Length of each occurrence.
    let durMs = null, durDays = null;
    if (start.isDate) {
      if (ev.DTEND) {
        const end = parseDate(ev.DTEND.value, ev.DTEND.params, fallbackTz);
        if (end) durDays = Math.max(1, dayNum(end.y, end.m, end.d) - dayNum(start.y, start.m, start.d));
      } else if (ev.DURATION) {
        const dm = parseDuration(ev.DURATION);
        durDays = dm ? Math.max(1, Math.round(dm / DAY_MS)) : 1;
      }
      if (!durDays) durDays = 1;
    } else {
      if (ev.DTEND) {
        const end = parseDate(ev.DTEND.value, ev.DTEND.params, fallbackTz);
        if (end) durMs = end.ms - start.ms;
      } else if (ev.DURATION) {
        durMs = parseDuration(ev.DURATION);
      }
      if (!durMs || durMs <= 0) continue; // zero-length: nothing to block
    }

    const occ = (y, m, d) => {
      if (start.isDate) {
        const n = dayNum(y, m, d);
        const [ey, em, ed] = fromDayNum(n + durDays);
        return [wallToUTC(y, m, d, 0, 0, fallbackTz).getTime(), wallToUTC(ey, em, ed, 0, 0, fallbackTz).getTime()];
      }
      const s = wallToUTC(y, m, d, start.hh, start.mm, start.tz, start.ss).getTime();
      return [s, s + durMs];
    };

    const rule = !ev["RECURRENCE-ID"] && ev.RRULE ? parseRule(ev.RRULE) : null;
    if (!rule) {
      const [s, e] = start.isDate ? occ(start.y, start.m, start.d) : [start.ms, start.ms + durMs];
      push(s, e);
      continue;
    }

    // Exclusions: EXDATEs plus any occurrence that has its own override entry.
    const excluded = new Set(overridden.get(ev.UID) || []);
    for (const ex of ev.EXDATE) {
      for (const val of ex.value.split(",")) {
        const dt = parseDate(val, ex.params, start.tz);
        if (!dt) continue;
        excluded.add(dt.isDate ? `d${dayNum(dt.y, dt.m, dt.d)}` : dt.ms);
      }
    }

    // UNTIL, converted to a day number in the event's own timezone.
    let untilMs = Infinity, untilDay = Infinity;
    if (rule.until) {
      const u = parseDate(rule.until, rule.until.endsWith("Z") ? {} : { TZID: start.tz }, start.tz);
      if (u) {
        if (u.isDate) {
          untilDay = dayNum(u.y, u.m, u.d);
        } else {
          untilMs = u.ms;
          const p = tzParts(new Date(u.ms), start.tz);
          untilDay = dayNum(+p.year, +p.month, +p.day);
        }
      }
    }

    const tzForDays = start.isDate ? fallbackTz : start.tz;
    const fp = tzParts(new Date(from), tzForDays);
    const tp = tzParts(new Date(to), tzForDays);
    const fromDay = dayNum(+fp.year, +fp.month, +fp.day);
    const toDay = Math.min(dayNum(+tp.year, +tp.month, +tp.day), untilDay);
    const startDay = dayNum(start.y, start.m, start.d);

    let count = 0;
    let sawStart = false;
    const windowDay = fromDay - (start.isDate ? durDays : 1) - Math.ceil((durMs || 0) / DAY_MS);
    for (const n of ruleDays(rule, startDay, windowDay, toDay)) {
      if (n === startDay) sawStart = true;
      count++;
      if (rule.count && count > rule.count) break;
      if (n < windowDay) continue; // counted towards COUNT, but ends before the window
      const [y, m, d] = fromDayNum(n);
      const [s, e] = occ(y, m, d);
      if (s > untilMs) break;
      if (excluded.has(s) || excluded.has(`d${n}`)) continue;
      push(s, e);
    }
    // RFC 5545: DTSTART is always the first occurrence even if the rule skips it.
    // (push() ignores it when it falls outside the window.)
    if (!sawStart && !excluded.has(start.ms) && !excluded.has(`d${startDay}`)) {
      const [s, e] = start.isDate ? occ(start.y, start.m, start.d) : [start.ms, start.ms + durMs];
      push(s, e);
    }
  }

  // Sort and merge so lookups are a binary search.
  out.sort((a, b) => a[0] - b[0]);
  const merged = [];
  for (const iv of out) {
    const last = merged[merged.length - 1];
    if (last && iv[0] <= last[1]) last[1] = Math.max(last[1], iv[1]);
    else merged.push([iv[0], iv[1]]);
  }
  return merged;
}
