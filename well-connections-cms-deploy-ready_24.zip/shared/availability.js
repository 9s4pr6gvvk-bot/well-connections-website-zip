// Availability engine for the booking system.
//
// Slots are never pre-stored. We read the admin's availability settings and
// generate candidate slots on the fly, then subtract any that are already
// held by a pending/accepted booking. Everything is computed in the configured
// timezone but slot_start is stored/compared as a UTC ISO string.

import { tzParts, wallToUTC } from "./tz.js";
import { getBusy, overlapsBusy } from "./calendar.js";

const DEFAULTS = {
  booking_days: "1,2,3,4,5",
  booking_start: "09:00",
  booking_end: "17:00",
  booking_duration: "15",
  booking_buffer: "0",
  booking_lead_hours: "24",
  booking_horizon: "21",
  booking_timezone: "Europe/London",
};

export async function getSettings(env) {
  const out = { ...DEFAULTS };
  try {
    const { results } = await env.DB.prepare(
      "SELECT key, value FROM app_settings WHERE key LIKE 'booking_%'"
    ).all();
    for (const r of results || []) out[r.key] = r.value;
  } catch {
    // Table may not exist yet; defaults are fine.
  }
  return {
    days: (out.booking_days || "").split(",").map((s) => parseInt(s, 10)).filter((n) => !isNaN(n)),
    start: out.booking_start || "09:00",
    end: out.booking_end || "17:00",
    duration: Math.max(5, parseInt(out.booking_duration, 10) || 15),
    buffer: Math.max(0, parseInt(out.booking_buffer, 10) || 0),
    leadHours: Math.max(0, parseInt(out.booking_lead_hours, 10) || 0),
    horizon: Math.min(120, Math.max(1, parseInt(out.booking_horizon, 10) || 21)),
    timezone: out.booking_timezone || "Europe/London",
  };
}

function hm(str) {
  const [h, m] = (str || "0:0").split(":").map((n) => parseInt(n, 10) || 0);
  return h * 60 + m;
}

// Returns grouped availability:
// [{ date: 'YYYY-MM-DD', label: 'Tue 26 Aug', slots: [{ start: ISO_UTC, label: '1:00 pm' }] }]
export async function computeAvailability(env, settings) {
  const s = settings || (await getSettings(env));
  const now = new Date();
  const earliest = new Date(now.getTime() + s.leadHours * 3600 * 1000);

  // Time already held by a pending or accepted booking. Held as intervals, not
  // exact start times, because pages run different lengths: a 30-minute
  // Arthritis UK session at 10:00 must also block a 20-minute slot at 10:15.
  const held = [];
  try {
    const { results } = await env.DB.prepare(
      "SELECT slot_start, duration_min FROM bookings WHERE status IN ('pending','accepted')"
    ).all();
    for (const r of results || []) {
      const st = Date.parse(r.slot_start + (String(r.slot_start).endsWith("Z") ? "" : "Z"));
      if (!Number.isFinite(st)) continue;
      const len = Math.max(5, parseInt(r.duration_min, 10) || s.duration);
      held.push([st, st + len * 60000]);
    }
  } catch { /* table may not exist yet */ }
  held.sort((a, b) => a[0] - b[0]);
  for (let i = held.length - 1; i > 0; i--) {
    // Merge overlaps so the binary search in overlapsBusy stays valid.
    if (held[i][0] <= held[i - 1][1]) { held[i - 1][1] = Math.max(held[i - 1][1], held[i][1]); held.splice(i, 1); }
  }

  // Busy blocks from the published Outlook calendar (empty when sync is off).
  let busy = [];
  try {
    busy = (await getBusy(env, { fallbackTz: s.timezone })).intervals || [];
  } catch { busy = []; }

  const startMin = hm(s.start);
  const endMin = hm(s.end);
  const step = s.duration + s.buffer;

  const days = [];
  // Iterate calendar days in the target timezone starting today.
  for (let i = 0; i <= s.horizon; i++) {
    const dayAnchor = new Date(now.getTime() + i * 86400000);
    const p = tzParts(dayAnchor, s.timezone);
    const y = +p.year, mo = +p.month, d = +p.day;
    const dow = new Date(Date.UTC(y, mo - 1, d)).getUTCDay(); // day of week for that calendar date
    if (!s.days.includes(dow)) continue;

    const slots = [];
    for (let t = startMin; t + s.duration <= endMin; t += step) {
      const hh = Math.floor(t / 60), mm = t % 60;
      const utc = wallToUTC(y, mo, d, hh, mm, s.timezone);
      if (utc < earliest) continue;
      const iso = utcIso(utc);
      const st = utc.getTime(), en = st + s.duration * 60000;
      if (overlapsBusy(held, st, en)) continue;
      if (overlapsBusy(busy, st, en)) continue;
      slots.push({ start: iso, label: timeLabel(utc, s.timezone) });
    }
    if (slots.length) {
      days.push({ date: `${y}-${pad(mo)}-${pad(d)}`, label: dayLabel(dayAnchor, s.timezone), slots });
    }
  }
  return days;
}

// Validate that a requested ISO slot is genuinely on offer right now.
export async function isSlotBookable(env, isoStart, settings) {
  const days = await computeAvailability(env, settings);
  for (const day of days) {
    for (const slot of day.slots) {
      if (slot.start === isoStart) return true;
    }
  }
  return false;
}

function pad(n) { return String(n).padStart(2, "0"); }

// Store slot_start as minute-precision UTC ISO (no seconds) so equality is stable.
function utcIso(date) {
  return `${date.getUTCFullYear()}-${pad(date.getUTCMonth() + 1)}-${pad(date.getUTCDate())}T${pad(date.getUTCHours())}:${pad(date.getUTCMinutes())}`;
}

function timeLabel(date, timeZone) {
  return new Intl.DateTimeFormat("en-GB", {
    timeZone, hour: "numeric", minute: "2-digit", hour12: true,
  }).format(date).replace(/\s?([ap])m/i, (m, g) => " " + g.toLowerCase() + "m");
}

function dayLabel(date, timeZone) {
  return new Intl.DateTimeFormat("en-GB", {
    timeZone, weekday: "short", day: "numeric", month: "short",
  }).format(date);
}

// Nice human label for a stored slot, e.g. "Tue 26 Aug 2026, 1:00 pm".
export function formatSlot(isoStart, timeZone = "Europe/London") {
  const d = new Date(isoStart + (isoStart.endsWith("Z") ? "" : "Z"));
  const date = new Intl.DateTimeFormat("en-GB", {
    timeZone, weekday: "short", day: "numeric", month: "short", year: "numeric",
  }).format(d);
  const time = timeLabel(d, timeZone);
  return `${date}, ${time}`;
}

// ─────────────────────────────────────────────────────────────────────────────
// Per-page availability.
//
// A booking page may override any of the global rules. Anything it leaves blank
// falls back to the global Availability settings, so Sam can tune one
// organisation without touching the others.
// ─────────────────────────────────────────────────────────────────────────────

export async function getPageSettings(env, page) {
  const base = await getSettings(env);
  if (!page) return base;

  const num = (v, fallback) => {
    const n = parseInt(v, 10);
    return Number.isFinite(n) ? n : fallback;
  };

  const daysRaw = (page.days || "").trim();
  const days = daysRaw
    ? daysRaw.split(",").map((s) => parseInt(s, 10)).filter((n) => !isNaN(n))
    : base.days;

  return {
    days: days.length ? days : base.days,
    start: (page.time_start || "").trim() || base.start,
    end: (page.time_end || "").trim() || base.end,
    duration: Math.max(5, num(page.duration_min, base.duration)),
    buffer: Math.max(0, num(page.buffer_min, base.buffer)),
    leadHours: Math.max(0, num(page.lead_hours, base.leadHours)),
    horizon: Math.min(120, Math.max(1, num(page.horizon_days, base.horizon))),
    timezone: (page.timezone || "").trim() || base.timezone,
  };
}

// Parse the stored questions JSON safely. Bad data must never break the page.
export function parseQuestions(raw) {
  if (!raw) return [];
  let arr;
  try { arr = JSON.parse(raw); } catch { return []; }
  if (!Array.isArray(arr)) return [];
  return arr
    .filter((q) => q && typeof q.label === "string" && q.label.trim())
    .slice(0, 20)
    .map((q) => ({
      label: String(q.label).slice(0, 400),
      type: ["text", "textarea", "select", "radio", "checkbox", "email", "tel"].includes(q.type) ? q.type : "text",
      required: q.required ? 1 : 0,
      options: Array.isArray(q.options)
        ? q.options.filter((o) => typeof o === "string" && o.trim()).slice(0, 30).map((o) => String(o).slice(0, 200))
        : [],
    }));
}
