// Minimal, dependency-free markdown -> HTML.
// HTML is escaped first, so raw tags in content cannot inject markup.

export function escapeHtml(s) {
  return String(s == null ? "" : s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

// Only permit safe URL schemes. The source has already been HTML-escaped, so a
// scheme like javascript: is compared here in its escaped form too. Anything
// that is not http(s), mailto or a relative/anchor path is neutralised.
function safeUrl(u) {
  const v = String(u || "").trim();
  // Strip HTML entities and control chars before testing the scheme so tricks
  // like "java&#09;script:" or leading whitespace cannot smuggle a scheme past.
  const probe = v.replace(/&[#a-z0-9]+;?/gi, "").replace(/[\u0000- ]/g, "").toLowerCase();
  if (/^(https?:|mailto:)/.test(probe)) return v;
  if (/^[/#.]/.test(probe) || !/^[a-z][a-z0-9+.-]*:/.test(probe)) return v; // relative path / anchor
  return "#"; // unsafe scheme (javascript:, data:, vbscript:, ...)
}

function inline(text) {
  // Order matters. Links/images first (they contain other chars), then emphasis.
  return text
    .replace(/!\[([^\]]*)\]\(([^)\s]+)\)/g, (_, alt, src) => `<img src="${safeUrl(src)}" alt="${alt}" loading="lazy" />`)
    .replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (_, t, href) => `<a href="${safeUrl(href)}" rel="noopener">${t}</a>`)
    .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
    .replace(/(^|[^*])\*([^*]+)\*/g, "$1<em>$2</em>")
    .replace(/`([^`]+)`/g, "<code>$1</code>");
}

export function markdownToHtml(md) {
  // Normalise: some DB content stores literal \n (two chars) instead of real
  // newlines. Convert those first so paragraphs and headings render correctly.
  const raw = (md == null ? "" : String(md))
    .replace(/\\n/g, "\n")
    .replace(/\\t/g, "\t");
  const src = escapeHtml(raw).replace(/\r\n/g, "\n");
  const lines = src.split("\n");
  const out = [];
  let i = 0;
  let listType = null; // 'ul' | 'ol'

  const closeList = () => {
    if (listType) { out.push(`</${listType}>`); listType = null; }
  };

  while (i < lines.length) {
    let line = lines[i];

    // blank line
    if (/^\s*$/.test(line)) { closeList(); i++; continue; }

    // horizontal rule
    if (/^\s*---\s*$/.test(line)) { closeList(); out.push("<hr />"); i++; continue; }

    // headings
    const h = line.match(/^(#{1,4})\s+(.*)$/);
    if (h) { closeList(); const lvl = h[1].length; out.push(`<h${lvl}>${inline(h[2])}</h${lvl}>`); i++; continue; }

    // blockquote (note: > is already escaped to &gt; at this point)
    if (/^\s*&gt;\s?/.test(line)) {
      closeList();
      const buf = [];
      while (i < lines.length && /^\s*&gt;\s?/.test(lines[i])) { buf.push(lines[i].replace(/^\s*&gt;\s?/, "")); i++; }
      out.push(`<blockquote>${inline(buf.join(" "))}</blockquote>`);
      continue;
    }

    // unordered list
    if (/^\s*[-*]\s+/.test(line)) {
      if (listType !== "ul") { closeList(); out.push("<ul>"); listType = "ul"; }
      out.push(`<li>${inline(line.replace(/^\s*[-*]\s+/, ""))}</li>`);
      i++; continue;
    }
    // ordered list
    if (/^\s*\d+\.\s+/.test(line)) {
      if (listType !== "ol") { closeList(); out.push("<ol>"); listType = "ol"; }
      out.push(`<li>${inline(line.replace(/^\s*\d+\.\s+/, ""))}</li>`);
      i++; continue;
    }

    // paragraph (gather until blank)
    closeList();
    const buf = [line];
    i++;
    while (i < lines.length && !/^\s*$/.test(lines[i]) && !/^(#{1,4}\s|\s*&gt;|\s*[-*]\s|\s*\d+\.\s|\s*---\s*$)/.test(lines[i])) {
      buf.push(lines[i]); i++;
    }
    out.push(`<p>${inline(buf.join(" "))}</p>`);
  }
  closeList();
  return out.join("\n");
}

export function slugify(s) {
  return String(s || "")
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "");
}
