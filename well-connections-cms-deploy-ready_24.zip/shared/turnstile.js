// Cloudflare Turnstile server-side verification.
// Inert until TURNSTILE_SECRET_KEY is set, so forms keep working before setup.
export async function verifyTurnstile(env, token, ip) {
  const secret = env.TURNSTILE_SECRET_KEY;
  if (!secret) return { ok: true, skipped: true }; // not configured yet
  if (!token) return { ok: false };
  try {
    const form = new URLSearchParams();
    form.append("secret", secret);
    form.append("response", String(token));
    if (ip) form.append("remoteip", ip);
    const res = await fetch("https://challenges.cloudflare.com/turnstile/v0/siteverify", {
      method: "POST",
      body: form,
    });
    const data = await res.json();
    return { ok: !!data.success, data };
  } catch (e) {
    // On a verification outage, fail closed to avoid opening the form to bots.
    return { ok: false, error: String(e) };
  }
}
