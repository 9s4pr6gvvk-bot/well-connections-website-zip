// Thin wrapper around the Resend API. No-ops safely if RESEND_API_KEY is not
// set yet, so the booking flow keeps working before email is wired up.
//
// Required secrets (set later with `npx wrangler pages secret put ...`):
//   RESEND_API_KEY    your Resend API key
// Optional vars (can live in wrangler.toml [vars] or as secrets):
//   BOOKING_FROM      verified sender, e.g. "Well Connections <bookings@wellconnections.co.uk>"
//   BOOKING_TO        where admin notifications go, e.g. "info@wellconnections.co.uk"
//   SITE_URL          public origin, e.g. "https://wellconnections.co.uk" (for status links)

// attachments: [{ filename, content (base64), content_type? }]
export async function sendEmail(env, { to, subject, html, replyTo, from, attachments }) {
  const key = env.RESEND_API_KEY;
  if (!key) {
    // Email not configured yet — don't block the booking. Log and move on.
    console.log("[email] RESEND_API_KEY not set; skipping send to", to, "-", subject);
    return { skipped: true };
  }
  from = from || env.BOOKING_FROM || "Well Connections <onboarding@resend.dev>";
  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${key}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from,
        to: Array.isArray(to) ? to : [to],
        subject,
        html,
        ...(replyTo ? { reply_to: replyTo } : {}),
        ...(attachments && attachments.length ? { attachments } : {}),
      }),
    });
    if (!res.ok) {
      const txt = await res.text();
      console.log("[email] Resend error", res.status, txt);
      return { ok: false, status: res.status };
    }
    return { ok: true };
  } catch (e) {
    console.log("[email] send failed", e && e.message);
    return { ok: false, error: String(e) };
  }
}

// Build a "From" header that keeps the verified sender address but changes the
// display name the inbox shows (e.g. "New Enquiry" instead of "Well Connections").
// Resend only cares about the address being on a verified domain; the name is free.
// base: either "Name <addr@domain>" or a bare "addr@domain".
export function fromWithName(base, displayName) {
  const src = base || "";
  const m = src.match(/<([^>]+)>/);
  const addr = (m ? m[1] : src).trim();
  if (!addr) return src;
  return `${displayName} <${addr}>`;
}

export function esc(s) {
  return String(s == null ? "" : s)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

const FONT = "'Helvetica Neue',Helvetica,Arial,sans-serif";

// Branded, table-based wrapper so all outgoing mail matches the website and
// renders reliably across email clients (Gmail, Outlook, Apple Mail).
// siteUrl: base the logo/links load from. Before DNS cutover the custom domain
// still points at the old host, so pass the live Pages URL (env.SITE_URL) so
// the logo loads; after cutover it can be the custom domain.
export function emailShell(inner, siteUrl) {
  const SITE_URL = siteUrl || "https://wellconnections.co.uk";
  const LOGO_URL = SITE_URL + "/images/wc-logo.png";
  return `<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/><meta name="color-scheme" content="light only"/></head>
<body style="margin:0;padding:0;background:#eef3f0;">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#eef3f0;margin:0;padding:0;">
    <tr><td align="center" style="padding:28px 14px;">
      <table role="presentation" width="560" cellpadding="0" cellspacing="0" style="width:560px;max-width:100%;background:#ffffff;border-radius:14px;overflow:hidden;box-shadow:0 10px 30px rgba(30,48,40,0.10);">

        <tr><td style="background:#1e3028;padding:32px 32px 30px;text-align:center;">
          <img src="${LOGO_URL}" alt="Well Connections — Through connection, people thrive" width="210" style="display:inline-block;width:210px;max-width:70%;height:auto;border:0;" />
        </td></tr>

        <tr><td style="height:4px;line-height:4px;font-size:0;background:#5a8a6a;">&nbsp;</td></tr>

        <tr><td style="padding:32px 32px 28px;font-family:${FONT};color:#1a2820;line-height:1.65;font-size:15px;">
          ${inner}
        </td></tr>

        <tr><td style="background:#f4f7f5;border-top:1px solid #e4eae7;padding:22px 32px;font-family:${FONT};">
          <p style="margin:0;font-size:12px;color:#5a6b63;line-height:1.7;">
            <a href="mailto:info@wellconnections.co.uk" style="color:#2d6e5e;text-decoration:none;">info@wellconnections.co.uk</a>
            &nbsp;&middot;&nbsp;
            <a href="${SITE_URL}" style="color:#2d6e5e;text-decoration:none;">wellconnections.co.uk</a>
          </p>
        </td></tr>

      </table>
    </td></tr>
  </table>
</body></html>`;
}

// Consistent detail table for admin notification emails. Pass raw [label,value]
// pairs; both are escaped here.
export function detailsTable(pairs) {
  const rows = pairs.map(([k, v]) => `
    <tr>
      <td style="padding:11px 14px;background:#f4f7f5;border-bottom:1px solid #e4eae7;font-family:${FONT};font-size:11px;letter-spacing:0.05em;text-transform:uppercase;color:#3d6b52;font-weight:bold;vertical-align:top;white-space:nowrap;">${esc(k)}</td>
      <td style="padding:11px 14px;border-bottom:1px solid #e4eae7;font-family:${FONT};font-size:14px;color:#1a2820;vertical-align:top;">${esc(v)}</td>
    </tr>`).join("");
  return `<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border-collapse:separate;border:1px solid #e4eae7;border-radius:10px;overflow:hidden;margin:18px 0;">${rows}</table>`;
}

// Section heading + intro line used at the top of notification emails.
export function emailHeading(title, intro) {
  return `<h1 style="margin:0 0 ${intro ? "6px" : "16px"};font-family:${FONT};font-size:21px;font-weight:bold;color:#1e3028;line-height:1.25;">${esc(title)}</h1>`
    + (intro ? `<p style="margin:0 0 4px;font-family:${FONT};font-size:14px;color:#5a6b63;line-height:1.6;">${esc(intro)}</p>` : "");
}
