// Timezone helpers shared by the availability engine and the calendar sync.
// Everything works off Intl, so BST/GMT changes are handled automatically.

// Building an Intl formatter is the expensive part, so keep one per timezone.
const FMT = new Map();
function formatter(timeZone) {
  let f = FMT.get(timeZone);
  if (!f) {
    f = new Intl.DateTimeFormat("en-GB", {
      timeZone, year: "numeric", month: "2-digit", day: "2-digit",
      hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false, weekday: "short",
    });
    FMT.set(timeZone, f);
  }
  return f;
}

export function tzParts(date, timeZone) {
  if (timeZone === "UTC") {
    return {
      year: String(date.getUTCFullYear()), month: String(date.getUTCMonth() + 1).padStart(2, "0"),
      day: String(date.getUTCDate()).padStart(2, "0"), hour: String(date.getUTCHours()).padStart(2, "0"),
      minute: String(date.getUTCMinutes()).padStart(2, "0"), second: String(date.getUTCSeconds()).padStart(2, "0"),
      weekday: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][date.getUTCDay()],
    };
  }
  const fmt = formatter(timeZone);
  const p = {};
  for (const part of fmt.formatToParts(date)) p[part.type] = part.value;
  if (p.hour === "24") p.hour = "00";
  return p; // {year, month, day, hour, minute, second, weekday}
}

// Offset (in minutes) of a timezone from UTC at a given instant.
// Offsets only change at clock changes, so cache the offset at the start and end
// of each UTC day; when they match, the whole day shares it. Clock-change days
// fall through to an exact lookup.
const DAY_OFF = new Map();
export function tzOffsetMinutes(date, timeZone) {
  if (timeZone === "UTC") return 0;
  const day = Math.floor(date.getTime() / 86400000);
  const key = timeZone + "|" + day;
  let c = DAY_OFF.get(key);
  if (c === undefined) {
    const a = exactOffset(new Date(day * 86400000), timeZone);
    const b = exactOffset(new Date(day * 86400000 + 86399000), timeZone);
    c = a === b ? a : null;
    if (DAY_OFF.size > 5000) DAY_OFF.clear();
    DAY_OFF.set(key, c === null ? "x" : c);
  }
  if (typeof c === "number") return c;
  return exactOffset(date, timeZone);
}

function exactOffset(date, timeZone) {
  const p = tzParts(date, timeZone);
  const asUTC = Date.UTC(+p.year, +p.month - 1, +p.day, +p.hour, +p.minute, +p.second);
  return Math.round((asUTC - date.getTime()) / 60000);
}

// Convert a wall-clock time in `timeZone` to a real UTC Date.
export function wallToUTC(y, m, d, hh, mm, timeZone, ss = 0) {
  const guess = new Date(Date.UTC(y, m - 1, d, hh, mm, ss));
  const off = tzOffsetMinutes(guess, timeZone);
  let out = new Date(guess.getTime() - off * 60000);
  // Second pass settles times either side of a clock change.
  const off2 = tzOffsetMinutes(out, timeZone);
  if (off2 !== off) out = new Date(guess.getTime() - off2 * 60000);
  return out;
}

export function isValidTimeZone(tz) {
  if (!tz) return false;
  try { new Intl.DateTimeFormat("en-GB", { timeZone: tz }); return true; } catch { return false; }
}
