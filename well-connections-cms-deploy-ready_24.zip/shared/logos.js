// Validation shared by /api/logos and /api/logos/:id.
export const LOGO_PAGES = ["home", "schools", "businesses", "charities"];

export function cleanLogo(b, existing = {}) {
  const pick = (k, d) => (k in b ? b[k] : existing[k] ?? d);
  const kind = pick("kind", "logo") === "label" ? "label" : "logo";
  const name = String(pick("name", "") || "").trim().slice(0, 120);
  if (!name) return { error: "Name is required" };

  let image_url = kind === "logo" ? String(pick("image_url", "") || "").trim() : "";
  // Only our own uploads or bundled images; anything else would be blocked by
  // the site's image policy anyway.
  if (image_url && !/^\/(media|images)\/[A-Za-z0-9._\-\/]+$/.test(image_url)) {
    return { error: "Please upload the logo image using the Upload button" };
  }
  const status = pick("status", "published") === "draft" ? "draft" : "published";
  if (kind === "logo" && status === "published" && !image_url) {
    return { error: "Upload a logo image before publishing (or save as Draft)" };
  }

  let pages = pick("pages", "");
  if (Array.isArray(pages)) pages = pages.join(",");
  pages = String(pages || "").split(",").map(s => s.trim()).filter(p => LOGO_PAGES.includes(p));
  if (kind === "label") pages = ["home"]; // labels only live in the homepage carousel
  pages = [...new Set(pages)].join(",");

  const so = pick("sort_order", 0);
  const sort_order = Number.isFinite(+so) ? Math.round(+so) : 0;
  return { kind, name, image_url, pages, status, sort_order };
}
