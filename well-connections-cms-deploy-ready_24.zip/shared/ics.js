// Calendar invite (.ics) for an accepted booking.
//
// Attached to the "booking accepted" emails so it can be added to Outlook (or
// any calendar) in one click. METHOD:PUBLISH means "here is an event to add",
// not a meeting request, so Outlook shows "Add to calendar" and never sends
// replies on anyone's behalf.
//
// The UID is fixed per booking, so opening an updated invite for the same
// booking replaces the earlier copy instead of duplicating it.

function pad(n) { return String(n).padStart(2, "0"); }

function icsDate(ms) {
  const d = new Date(ms);
  return `${d.getUTCFullYear()}${pad(d.getUTCMonth() + 1)}${pad(d.getUTCDate())}T${pad(d.getUTCHours())}${pad(d.getUTCMinutes())}${pad(d.getUTCSeconds())}Z`;
}

// RFC 5545 text escaping.
function icsText(s) {
  return String(s == null ? "" : s)
    .replace(/\\/g, "\\\\")
    .replace(/\r\n|\r|\n/g, "\\n")
    .replace(/;/g, "\\;")
    .replace(/,/g, "\\,");
}

// Fold lines at 75 octets (UTF-8 aware), continuation lines start with a space.
function fold(line) {
  const enc = new TextEncoder();
  if (enc.encode(line).length <= 75) return line;
  const out = [];
  let cur = "", curLen = 0;
  for (const ch of line) {
    const len = enc.encode(ch).length;
    const limit = out.length ? 74 : 75; // continuation lines lose one octet to the leading space
    if (curLen + len > limit) { out.push(cur); cur = ""; curLen = 0; }
    cur += ch; curLen += len;
  }
  if (cur) out.push(cur);
  return out.map((l, i) => (i ? " " + l : l)).join("\r\n");
}

function parseAnswers(raw) {
  if (!raw) return [];
  try {
    const a = JSON.parse(raw);
    return Array.isArray(a) ? a.filter((x) => x && x.label) : [];
  } catch { return []; }
}

// audience: "admin" (full details for Well Connections) or "visitor" (their own copy).
export function bookingIcs(booking, { audience = "admin", siteUrl = "https://wellconnections.co.uk" } = {}) {
  const start = Date.parse(booking.slot_start + (String(booking.slot_start).endsWith("Z") ? "" : "Z"));
  const minutes = Math.max(5, parseInt(booking.duration_min, 10) || 30);
  const end = start + minutes * 60000;
  const service = (booking.service || "Consultation").trim();
  const host = (() => { try { return new URL(siteUrl).host; } catch { return "wellconnections.co.uk"; } })();

  let summary, description, location;
  if (audience === "admin") {
    summary = `${booking.name}: ${service}`;
    const lines = [
      `${service}, ${minutes} minutes`,
      "",
      `Name: ${booking.name}`,
      `Email: ${booking.email}`,
      `Phone: ${booking.phone || "not given"}`,
    ];
    const answers = parseAnswers(booking.answers);
    if (booking.note) lines.push("", `Note: ${booking.note}`);
    if (answers.length) {
      lines.push("");
      for (const a of answers) lines.push(`${a.label}`, `${a.value}`, "");
    }
    lines.push(`Booking in the dashboard: ${siteUrl.replace(/\/$/, "")}/admin`);
    description = lines.join("\n").replace(/\n{3,}/g, "\n\n").trim();
    location = booking.phone ? `Phone call: ${booking.phone}` : "Phone call";
  } else {
    summary = `Well Connections: ${service}`;
    description = `Your ${minutes}-minute ${service} with Well Connections.\n\nIf you need to change or cancel, reply to your confirmation email or contact info@wellconnections.co.uk.`;
    location = "Phone call";
  }

  const lines = [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//Well Connections//Bookings//EN",
    "CALSCALE:GREGORIAN",
    "METHOD:PUBLISH",
    "BEGIN:VEVENT",
    `UID:booking-${booking.token || booking.id}-${audience}@${host}`,
    `DTSTAMP:${icsDate(Date.now())}`,
    `DTSTART:${icsDate(start)}`,
    `DTEND:${icsDate(end)}`,
    `SUMMARY:${icsText(summary)}`,
    `DESCRIPTION:${icsText(description)}`,
    `LOCATION:${icsText(location)}`,
    "STATUS:CONFIRMED",
    "TRANSP:OPAQUE",
    "BEGIN:VALARM",
    "ACTION:DISPLAY",
    `DESCRIPTION:${icsText(summary)}`,
    "TRIGGER:-PT15M",
    "END:VALARM",
    "END:VEVENT",
    "END:VCALENDAR",
  ];
  return lines.map(fold).join("\r\n") + "\r\n";
}

// Base64 for Resend attachments (handles UTF-8 such as names with accents).
export function toBase64(str) {
  const bytes = new TextEncoder().encode(str);
  let bin = "";
  for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return btoa(bin);
}

export function icsFilename(booking) {
  const d = String(booking.slot_start || "").slice(0, 10);
  return `booking-${d || "well-connections"}.ics`;
}
