// Live-chat opening hours.
//
// The chat widget has two independent controls:
//   chat_enabled    the master on/off switch (unchanged behaviour)
//   the schedule    optional days + hours, outside which chat is closed
//
// Nothing here is pre-stored: "is chat open right now" is worked out on every
// request from the saved schedule, in the configured timezone, so British
// Summer Time is handled by the browser's own timezone data rather than by us.
//
// All values live in app_settings as chat_* keys, so no migration is needed.

const KEYS = [
  "chat_enabled",
  "chat_sched_on",
  "chat_sched_days",
  "chat_sched_start",
  "chat_sched_end",
  "chat_sched_tz",
  "chat_sched_mode",
];

const DEFAULTS = {
  chat_enabled: "1",       // master switch: on unless turned off
  chat_sched_on: "0",      // schedule off -> chat is open whenever enabled
  chat_sched_days: "1,2,3,4,5",
  chat_sched_start: "09:00",
  chat_sched_end: "17:00",
  chat_sched_tz: "Europe/London",
  chat_sched_mode: "away", // away | hide
};

export async function getChatSettings(env) {
  const raw = { ...DEFAULTS };
  try {
    const { results } = await env.DB.prepare(
      "SELECT key, value FROM app_settings WHERE key LIKE 'chat_%'"
    ).all();
    for (const r of results || []) {
      if (KEYS.includes(r.key) && r.value != null) raw[r.key] = r.value;
    }
  } catch {
    // Table missing -> defaults are fine, chat behaves as before.
  }
  return {
    enabled: raw.chat_enabled !== "0",
    scheduleOn: raw.chat_sched_on === "1",
    days: parseDays(raw.chat_sched_days, DEFAULTS.chat_sched_days),
    start: normTime(raw.chat_sched_start, DEFAULTS.chat_sched_start),
    end: normTime(raw.chat_sched_end, DEFAULTS.chat_sched_end),
    timezone: (raw.chat_sched_tz || "").trim() || DEFAULTS.chat_sched_tz,
    mode: raw.chat_sched_mode === "hide" ? "hide" : "away",
  };
}

// Is chat taking messages at this instant?
// A schedule that is off, or a master switch that is off, is decided here too,
// so callers never have to combine the two themselves.
export function isChatOpen(settings, now = new Date()) {
  if (!settings.enabled) return false;
  if (!settings.scheduleOn) return true;
  if (!settings.days.length) return false;

  const p = parts(now, settings.timezone);
  if (!p) return true; // bad timezone -> fail open rather than silently closing chat
  if (!settings.days.includes(p.dow)) return false;

  const mins = p.hour * 60 + p.minute;
  const from = hm(settings.start);
  const to = hm(settings.end);
  // An end time earlier than the start (e.g. 18:00 to 02:00) wraps past midnight.
  return to > from ? mins >= from && mins < to : mins >= from || mins < to;
}

// Human summary of the schedule, e.g. "Mon to Fri, 9:00am to 5:00pm".
// Used in the away message and in the dashboard.
export function describeSchedule(settings) {
  if (!settings.scheduleOn) return "";
  const names = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  const picked = [...settings.days].sort((a, b) => a - b);
  let dayText;
  if (!picked.length) dayText = "No days";
  else if (picked.length === 1) dayText = names[picked[0]];
  else if (isRun(picked)) dayText = `${names[picked[0]]} to ${names[picked[picked.length - 1]]}`;
  else dayText = picked.map((d) => names[d]).join(", ");
  return `${dayText}, ${label12(settings.start)} to ${label12(settings.end)}`;
}

// Settings the public widget is allowed to see. Never leak the raw keys.
export function publicChatState(settings, now = new Date()) {
  const open = isChatOpen(settings, now);
  // No days ticked means chat never opens. There are no hours to advertise, so
  // an away message would be promising a reopening that never comes: hide the
  // bubble instead, whatever the configured mode says.
  const closedForGood = settings.scheduleOn && !settings.days.length;
  return {
    enabled: settings.enabled,
    open,
    // What the widget should do when chat is closed by the schedule:
    // "away" keeps the bubble with a message, "hide" removes it entirely.
    mode: closedForGood ? "hide" : settings.mode,
    hours: settings.scheduleOn && !closedForGood ? describeSchedule(settings) : "",
  };
}

function isRun(sorted) {
  for (let i = 1; i < sorted.length; i++) if (sorted[i] !== sorted[i - 1] + 1) return false;
  return true;
}

function parts(date, timeZone) {
  try {
    const fmt = new Intl.DateTimeFormat("en-GB", {
      timeZone, hour: "2-digit", minute: "2-digit", hour12: false, weekday: "short",
    });
    const out = {};
    for (const part of fmt.formatToParts(date)) out[part.type] = part.value;
    const names = { sun: 0, mon: 1, tue: 2, wed: 3, thu: 4, fri: 5, sat: 6 };
    const dow = names[String(out.weekday || "").slice(0, 3).toLowerCase()];
    if (dow === undefined) return null;
    // "24" is returned at midnight by some runtimes; treat it as hour 0.
    const hour = (parseInt(out.hour, 10) || 0) % 24;
    return { dow, hour, minute: parseInt(out.minute, 10) || 0 };
  } catch {
    return null;
  }
}

export function parseDays(v, dflt = "") {
  const src = String(v == null ? "" : v).trim() || dflt;
  const days = src.split(",").map((s) => parseInt(s, 10)).filter((n) => n >= 0 && n <= 6);
  return [...new Set(days)].sort((a, b) => a - b);
}

export function normTime(v, dflt) {
  const m = String(v == null ? "" : v).match(/^(\d{1,2}):(\d{2})$/);
  if (!m) return dflt;
  const h = Math.min(23, Math.max(0, +m[1]));
  const mi = Math.min(59, Math.max(0, +m[2]));
  return `${String(h).padStart(2, "0")}:${String(mi).padStart(2, "0")}`;
}

function hm(str) {
  const [h, m] = String(str || "0:0").split(":").map((n) => parseInt(n, 10) || 0);
  return h * 60 + m;
}

function label12(t) {
  const [h, m] = String(t || "0:0").split(":").map((n) => parseInt(n, 10) || 0);
  const ampm = h >= 12 ? "pm" : "am";
  const hr = h % 12 === 0 ? 12 : h % 12;
  return `${hr}:${String(m).padStart(2, "0")}${ampm}`;
}
