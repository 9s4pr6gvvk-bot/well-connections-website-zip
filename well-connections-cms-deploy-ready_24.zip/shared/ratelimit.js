// D1-backed fixed-window rate limiter for the public form endpoints.
//
// Uses the database you already have (no extra binding to configure). A single
// UPSERT per request increments a per-IP, per-route counter inside the current
// time window, then reads it back. Old rows are swept opportunistically.
//
// Fails OPEN: if the rate_limits table is missing (migration not run yet) or a
// DB error occurs, the request is allowed through. That keeps the contact and
// booking forms working before the migration is applied and avoids blocking
// real visitors on a transient database hiccup. Turnstile remains the primary
// spam defence; this is a second layer that caps volume from any single IP.
//
// Run migrate-rate-limits.sql once to create the table (see DEPLOY-NOTES.md).

export async function rateLimit(env, key, limit, windowSec) {
  if (!env || !env.DB) return { ok: true, skipped: true };

  const now = Math.floor(Date.now() / 1000);
  const windowStart = now - (now % windowSec);
  const expiresAt = windowStart + windowSec;
  const bucket = `${key}:${windowStart}`;

  try {
    // One statement to increment (or create) this window's counter.
    await env.DB.prepare(
      `INSERT INTO rate_limits (bucket, count, expires_at) VALUES (?, 1, ?)
       ON CONFLICT(bucket) DO UPDATE SET count = count + 1`
    ).bind(bucket, expiresAt).run();

    const row = await env.DB.prepare(
      "SELECT count FROM rate_limits WHERE bucket = ?"
    ).bind(bucket).first();
    const count = row ? row.count : 1;

    // Cheap probabilistic cleanup so the table cannot grow without bound.
    if (Math.random() < 0.02) {
      try {
        await env.DB.prepare("DELETE FROM rate_limits WHERE expires_at < ?").bind(now).run();
      } catch { /* sweeping is best-effort */ }
    }

    return {
      ok: count <= limit,
      count,
      limit,
      retryAfter: Math.max(1, expiresAt - now),
    };
  } catch {
    // Table missing or DB unavailable -> allow through (fail open).
    return { ok: true, skipped: true };
  }
}

// Builds the identity a limit is counted against. Falls back to a constant when
// no client IP is present so a missing header cannot be used to dodge the limit
// entirely (all such requests then share one bucket).
export function clientKey(request, route) {
  const ip = request.headers.get("CF-Connecting-IP")
    || request.headers.get("X-Forwarded-For")
    || "noip";
  return `${route}:${ip}`;
}
