import { layout } from "./layout.js";
import { escapeHtml } from "./markdown.js";

const BOOK_URL = "/#book";

// Per-page config. Copy is written unique per city to avoid thin/duplicate
// content and to read naturally for local search.
const PAGES = {
  "therapy-leeds": {
    service: "therapy", city: "Leeds",
    title: "Therapy & Counselling in Leeds | Well Connections",
    description: "Private therapy and counselling in Leeds with no waiting lists. Personally matched with a trusted therapist, in person or online. Book a free discovery call.",
    label: "Therapy in Leeds",
    heading: "Therapy and counselling<br /><em>in Leeds.</em>",
    lede: "Support that fits your life, matched to you by people who know their therapists personally. No waiting lists, no guesswork.",
    intro: [
      "Finding the right therapist in Leeds can feel like the hardest part of getting help. Well Connections takes that weight off you. We match you with a counsellor, psychotherapist or psychologist who fits what you are working through, and we do it quickly, because waiting rarely makes things easier.",
      "Every therapist we work with is personally known to us. We check their credentials, their experience and their approach, so the person you sit down with is someone we would trust ourselves. Sessions are available across Leeds in person, or online if that suits you better.",
      "Whether you are dealing with anxiety, low mood, a relationship that has become difficult, or something you have never put into words before, there is a therapist here who can help you feel heard.",
    ],
    nearby: "We support clients across Leeds and the wider West Yorkshire area, including Headingley, Horsforth, Chapel Allerton, Roundhay and Morley.",
  },
  "therapy-harrogate": {
    service: "therapy", city: "Harrogate",
    title: "Therapy & Counselling in Harrogate | Well Connections",
    description: "Private therapy and counselling in Harrogate with no waiting lists. Personally matched with a trusted therapist, in person or online. Book a free discovery call.",
    label: "Therapy in Harrogate",
    heading: "Therapy and counselling<br /><em>in Harrogate.</em>",
    lede: "A calmer path to the right support, matched to you and available without the wait.",
    intro: [
      "When you are ready to talk to someone, the last thing you need is a waiting list. Well Connections connects people in Harrogate with therapists who are the right fit, and we do it without the long delays that so many services build in.",
      "We know our therapists personally. That means we can point you towards someone whose training and style actually match what you need, rather than handing you a directory and wishing you luck. You can meet your therapist in Harrogate or work with them online, whichever feels right.",
      "From everyday stress and burnout to grief, trauma and relationship difficulties, our team covers a broad range of specialisms, so the support you get is genuinely suited to you.",
    ],
    nearby: "We support clients across Harrogate and the surrounding area, including Knaresborough, Starbeck, Pannal, Bilton and Killinghall.",
  },
  "therapy-ripon": {
    service: "therapy", city: "Ripon",
    title: "Therapy & Counselling in Ripon | Well Connections",
    description: "Private therapy and counselling in Ripon with no waiting lists. Personally matched with a trusted therapist, in person or online. Book a free discovery call.",
    label: "Therapy in Ripon",
    heading: "Therapy and counselling<br /><em>in Ripon.</em>",
    lede: "Trusted, personally matched therapists for Ripon and the surrounding villages. No waiting lists.",
    intro: [
      "Good therapy starts with the right match. In Ripon, Well Connections helps you find a counsellor or psychotherapist who suits what you are facing, chosen from a team we know and trust rather than a faceless list.",
      "Because Ripon is a smaller city, many people worry about choice and privacy. We work discreetly, and we can offer sessions in person locally or online, so distance is never a barrier to getting the support you deserve.",
      "Whatever has brought you here, from anxiety and low mood to loss, life changes or difficulties at home, there is a therapist ready to help you move forward at your own pace.",
    ],
    nearby: "We support clients across Ripon and the surrounding area, including Boroughbridge, Masham, Bishop Monkton and the villages of lower Wensleydale.",
  },
  "coaching-leeds": {
    service: "coaching", city: "Leeds",
    title: "Coaching in Leeds | Well Connections",
    description: "Life, career and executive coaching in Leeds. Personally matched with an experienced coach to help you move forward with clarity. Book a free discovery call.",
    label: "Coaching in Leeds",
    heading: "Coaching<br /><em>in Leeds.</em>",
    lede: "Clarity, momentum and accountability, with a coach matched to where you want to go.",
    intro: [
      "Coaching is for the moments when you know something needs to change but the path is not obvious. In Leeds, Well Connections matches you with an experienced coach who can help you think clearly, set the right goals and actually follow through.",
      "Our coaches cover life, career, executive and wellbeing coaching. We introduce you to someone whose background fits your situation, whether you are navigating a career move, building confidence, or leading a team through change. Sessions run in person across Leeds or online.",
      "This is practical, forward looking work. You bring the ambition, your coach brings structure, challenge and support, and together you make progress that sticks.",
    ],
    nearby: "We work with individuals and organisations across Leeds and West Yorkshire, in person or online.",
  },
  "coaching-harrogate": {
    service: "coaching", city: "Harrogate",
    title: "Coaching in Harrogate | Well Connections",
    description: "Life, career and executive coaching in Harrogate. Personally matched with an experienced coach to help you move forward with clarity. Book a free discovery call.",
    label: "Coaching in Harrogate",
    heading: "Coaching<br /><em>in Harrogate.</em>",
    lede: "Space to think, and a coach who helps you turn that thinking into action.",
    intro: [
      "Sometimes you need more than advice from friends. Coaching gives you a dedicated space to work out what you really want and how to get there. In Harrogate, Well Connections matches you with a coach whose experience fits your goals.",
      "Whether you are weighing a career change, stepping into leadership, or simply want to feel more in control of your direction, we introduce you to the right person rather than leaving you to search alone. Sessions are available in Harrogate or online.",
      "Expect honest conversation, clear goals and steady accountability. Coaching with Well Connections is about real movement, not vague encouragement.",
    ],
    nearby: "We work with individuals and organisations across Harrogate, Knaresborough and the wider district, in person or online.",
  },
  "coaching-ripon": {
    service: "coaching", city: "Ripon",
    title: "Coaching in Ripon | Well Connections",
    description: "Life, career and executive coaching in Ripon. Personally matched with an experienced coach to help you move forward with clarity. Book a free discovery call.",
    label: "Coaching in Ripon",
    heading: "Coaching<br /><em>in Ripon.</em>",
    lede: "A trusted coach, matched to your goals, for Ripon and the surrounding area.",
    intro: [
      "Coaching helps you get unstuck. In Ripon, Well Connections connects you with an experienced coach who can help you find clarity, set meaningful goals and build the confidence to act on them.",
      "Our coaches work across life, career, executive and wellbeing coaching. We match you with someone whose background suits where you are and where you want to be, and sessions can take place locally or online to fit around your life.",
      "It is focused, practical work. You set the direction, your coach keeps you honest and moving, and the change you want starts to feel achievable.",
    ],
    nearby: "We work with individuals and organisations across Ripon and the surrounding villages, in person or online.",
  },
  "therapy-york": {
    service: "therapy", city: "York",
    title: "Therapy & Counselling in York | Well Connections",
    description: "Private therapy and counselling in York with no waiting lists. Personally matched with a trusted therapist, in person or online. Book a free discovery call.",
    label: "Therapy in York",
    heading: "Therapy and counselling<br /><em>in York.</em>",
    lede: "The right therapist for York, matched to you and available without a long wait.",
    intro: [
      "Reaching out for therapy in York should not mean joining a queue. Well Connections matches you with a counsellor, psychotherapist or psychologist who suits what you are working through, and we do it promptly, because the wait is often the hardest part.",
      "Every therapist we recommend is someone we know personally. We check their training, their experience and their approach, so the person you sit down with is one we would trust ourselves. You can meet them in York in person, or work together online if that suits you better.",
      "From anxiety, stress and low mood to grief, trauma and relationship difficulties, our team covers a wide range of specialisms, so the support you receive genuinely fits your situation.",
    ],
    nearby: "We support clients across York and the surrounding area, including Clifton, Acomb, Fulford, Heslington, Haxby and Bishopthorpe.",
  },
  "coaching-york": {
    service: "coaching", city: "York",
    title: "Coaching in York | Well Connections",
    description: "Life, career and executive coaching in York. Personally matched with an experienced coach to help you move forward with clarity. Book a free discovery call.",
    label: "Coaching in York",
    heading: "Coaching<br /><em>in York.</em>",
    lede: "A coach matched to your goals, helping you turn intention into progress in York.",
    intro: [
      "Coaching suits the moments when you know something needs to shift but the way forward is not obvious. In York, Well Connections matches you with an experienced coach who helps you think clearly, set the right goals and actually follow through.",
      "Our coaches cover life, career, executive and wellbeing coaching. We introduce you to someone whose background fits where you are, whether you are changing direction, building confidence, or leading others through change. Sessions run in person across York or online.",
      "This is practical, forward looking work. You bring the ambition, your coach brings structure, challenge and support, and together you make progress that lasts.",
    ],
    nearby: "We work with individuals and organisations across York and the surrounding area, in person or online.",
  },
};

function renderBody(cfg) {
  const otherService = cfg.service === "therapy" ? "coaching" : "therapy";
  const otherLabel = cfg.service === "therapy" ? "Coaching" : "Therapy";
  const intro = cfg.intro.map((p) => `<p>${escapeHtml(p)}</p>`).join("");
  const steps = [
    ["Tell us what you need", "A short, free discovery call so we understand what you are looking for. No pressure, no commitment."],
    ["Get matched", `We introduce you to a ${cfg.service === "therapy" ? "therapist" : "coach"} we know and trust, chosen to fit your situation.`],
    ["Begin when you are ready", `Start your sessions in ${escapeHtml(cfg.city)} or online, at a pace that works for you.`],
  ].map(([h, p], i) => `
    <div class="lp-step">
      <span class="lp-step-n">${i + 1}</span>
      <div><h3>${escapeHtml(h)}</h3><p>${p}</p></div>
    </div>`).join("");

  return `
  <header class="page-head">
    <span class="label">${escapeHtml(cfg.label)}</span>
    <h1>${cfg.heading}</h1>
    <p>${escapeHtml(cfg.lede)}</p>
  </header>
  <main class="wrap lp">
    <section class="lp-intro">${intro}</section>

    <section class="lp-how">
      <h2>How it works</h2>
      <div class="lp-steps">${steps}</div>
    </section>

    <section class="lp-cta">
      <h2>Ready when you are</h2>
      <p>Book a free discovery call and we will match you with the right ${cfg.service === "therapy" ? "therapist" : "coach"} for ${escapeHtml(cfg.city)}.</p>
      <a class="lp-btn" href="${BOOK_URL}">Book a Discovery Call</a>
      <p class="lp-nearby">${escapeHtml(cfg.nearby)}</p>
      <p class="lp-alt">Looking for ${otherService} instead? See <a href="/${otherService}-${cfg.city.toLowerCase()}">${otherLabel} in ${escapeHtml(cfg.city)}</a>.</p>
    </section>
  </main>
  <style>
    .lp{max-width:820px}
    .lp-intro p{font-size:1.05rem;color:#2a3a32;line-height:1.8;margin:0 0 1.2rem}
    .lp-how{margin-top:3rem}
    .lp h2{font-family:'League Spartan',sans-serif;font-weight:600;font-size:1.6rem;color:var(--bark-dark);margin-bottom:1.4rem}
    .lp-steps{display:grid;gap:1.2rem}
    .lp-step{display:flex;gap:1rem;align-items:flex-start;background:#fff;border:1px solid var(--stone);border-radius:8px;padding:1.4rem 1.5rem}
    .lp-step-n{flex:none;width:34px;height:34px;border-radius:50%;background:var(--sage);color:#fff;display:flex;align-items:center;justify-content:center;font-weight:600;font-size:0.95rem}
    .lp-step h3{font-family:'League Spartan',sans-serif;font-weight:600;font-size:1.05rem;margin:0 0 0.3rem;color:var(--text)}
    .lp-step p{margin:0;color:var(--text-muted);font-size:0.95rem;line-height:1.6}
    .lp-cta{margin-top:3rem;background:var(--sage-pale);border-radius:10px;padding:2.5rem 2rem;text-align:center}
    .lp-cta p{color:var(--text-muted);max-width:520px;margin:0 auto 1.5rem;line-height:1.7}
    .lp-btn{display:inline-block;background:var(--sage);color:#fff;text-decoration:none;padding:0.9rem 1.9rem;border-radius:2px;font-size:0.82rem;letter-spacing:0.05em;text-transform:uppercase;font-weight:500;box-shadow:0 2px 10px rgba(90,138,106,0.28);transition:background .2s,transform .2s}
    .lp-btn:hover{background:var(--sage-dark);transform:translateY(-1px)}
    .lp-nearby{font-size:0.9rem;margin-top:1.8rem}
    .lp-alt{font-size:0.9rem;margin-top:0.4rem}
    .lp-alt a,.lp-nearby a{color:var(--teal)}
  </style>`;
}

export function locationPage(key) {
  const cfg = PAGES[key];
  if (!cfg) return new Response("Not found", { status: 404 });
  const SITE = "https://wellconnections.co.uk";
  const canonical = SITE + "/" + key;
  const serviceName = cfg.service === "therapy" ? "Therapy & Counselling" : "Coaching";
  const jsonLd = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "Service",
        "@id": canonical + "#service",
        "name": `${serviceName} in ${cfg.city}`,
        "serviceType": serviceName,
        "description": cfg.description,
        "url": canonical,
        "areaServed": { "@type": "City", "name": cfg.city },
        "provider": {
          "@type": "Organization",
          "name": "Well Connections",
          "url": SITE + "/",
          "telephone": ["+447725035029", "+447736317617"],
          "email": "info@wellconnections.co.uk",
        },
      },
      {
        "@type": "BreadcrumbList",
        "itemListElement": [
          { "@type": "ListItem", "position": 1, "name": "Home", "item": SITE + "/" },
          { "@type": "ListItem", "position": 2, "name": `${serviceName} in ${cfg.city}`, "item": canonical },
        ],
      },
    ],
  };
  return new Response(layout({
    title: cfg.title,
    description: cfg.description,
    body: renderBody(cfg),
    canonical,
    jsonLd,
  }), { headers: { "Content-Type": "text/html; charset=utf-8" } });
}

export const LOCATION_SLUGS = Object.keys(PAGES);
