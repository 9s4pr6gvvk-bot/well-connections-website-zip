# Well Connections CMS — Training Manual

A short, practical guide to running the website content yourself. No code, no
WordPress. You log in, make changes, and the website updates.

---

## 1. Signing in

1. Go to **your-site-address/admin**
2. Sign in with your email through the Cloudflare security page. It sends you a
   one-time code (or uses your Google login) to confirm it's you.

You stay signed in for a while, then you'll be asked to confirm your email
again. Click **Sign out** (top right) any time you're on a shared computer.

If you can't get in, your web person can check that your email is on the allowed
list in a few seconds.

---

## 2. The three sections

Across the top you'll see three tabs:

- **Teams** — your specialism pages (Child & Teens, Couples, Coaching, and so on)
- **Therapists** — the people, and which team pages they appear on
- **Blog Posts** — articles

Everything you publish shows on the live site straight away. Anything left as a
**Draft** stays hidden from the public until you're ready.

---

## 3. Teams (your specialism pages)

Each team is its own page on the website, for example
`your-site/team/child-teens`. It has a heading, an intro paragraph, and a grid of
the therapists you've assigned to it.

**To add a team**

1. Open the **Teams** tab, click **+ Add team**
2. Type the **team name** (e.g. "Couples Counselling")
3. Write the **intro text** — a sentence or two shown at the top of the page
4. Leave status as **Published**, click **Save**

The web address (slug) is created automatically from the name. A brand-new team
page will look empty until you assign therapists to it (next section).

**To edit or remove a team**

- **Edit** changes the name, intro, or sort order at any time. Doing this is
  safe: it will NOT change the team's web address.
- **Delete** removes the page. Therapists assigned to it aren't deleted — they
  simply stop showing on that page. It will warn you how many are affected.

**Tip:** Set the **sort order** number to control the order teams appear in on
the "all teams" page. Lower numbers come first.

### Important: the "Web address (slug)" field — leave it alone

When you edit a team you'll see a field called **Web address (slug)**. This is
the last part of the page's address (the `child-teens` in
`/team/child-teens`). It is set once when the team is created, and you should
**leave it as it is**.

Here's why it matters. Your therapists are linked to a team by this web
address, not by the team's display name. So if you change a team's slug:

- The team's page moves to a new address, and the old address stops working
  ("Team not found").
- **Every therapist on that team drops off the page**, because they're still
  pointing at the old address. They aren't deleted, they just stop showing
  until the slug is put back.
- Any links to the old address (from the home page, menu, or anything you've
  shared) will break.

So treat the web address like a house address: set sensibly once, then don't
touch it. You never need to change it for normal day-to-day updates. If you
ever change one by accident and therapists vanish from a team page, the fix is
simply to set the slug back to what it was.

---

## 4. Therapists

**To add a therapist**

1. Open the **Therapists** tab, click **+ Add therapist**
2. Fill in:
   - **Name** (required)
   - **Role / title** — e.g. "Psychotherapist"
   - **Photo** — paste an image link, or click **Choose file** to upload one
   - **Qualifications & Accreditations** — the letters/qualifications line, e.g.
     "BACP · MA Family and Marriage Therapy"
   - **Enquiry email** (optional) — see below
   - **Teams** — tick every team page this person should appear on. You can tick
     more than one.
   - **Profile link** (optional) — a "Read profile" button links here
   - **Short bio** (optional)
3. Leave **Currently accepting clients** ticked if they are
4. **Save**

**To edit or remove a therapist**

- **Edit** to change any detail, their photo, or which teams they're on.
- **Delete** removes them from the site entirely (this can't be undone).

**Moving someone between teams** is just editing them and changing the ticks. To
temporarily hide someone without deleting, set their status to **Draft**.

**Blanket availability**

The **Blanket Availability** tab sets the days, hours and session length for
every booking on the site. Booking pages can have their own settings, and a page
with its own settings ignores the blanket ones, which is how discovery calls and
an organisation page can end up different lengths.

The panel at the bottom of that tab shows every booking page and whether it is
following the blanket settings or using its own. To put everything on the same
footing, tick the settings you want to push and press **Apply to all booking
pages**. Those pages then follow the blanket settings from then on, including
next time you change them. The confirmation tells you which pages will change.
It only touches scheduling: names, intros and booking questions stay as they are,
and it cannot be undone.

**Closing bookings entirely**

Untick every day on the Blanket Availability tab and the website offers no
booking times at all: visitors see "No times available right now" with a link to
the enquiry form instead. It asks you to confirm first. Booking pages that have
their own days carry on using them, so untick the days and then apply the blanket
settings if you want everything shut.

**Live chat opening hours**

The **Messages** tab has the live chat switch at the top right, and underneath it
an opening hours panel. Tick **Only show chat at set times**, pick the days and
the opening and closing time, then choose what happens outside them:

- **Show an away message** keeps the chat bubble on the site. Visitors who open
  it see a message saying chat is closed, with a button through to the enquiry
  form.
- **Hide chat completely** takes the bubble off the site until it opens again.

Either way nobody can send a chat message while it is closed, so you will not
come back to messages sitting unanswered from the middle of the night. The panel
shows whether chat is open or closed right now.

Untick every day and chat stays closed all week, with the bubble off the site
altogether. It asks you to confirm first.

The away message wording is in the **Content** tab under "Live chat: outside
opening hours". Leave `{hours}` in the text and it fills itself in with your
opening hours.

**Enquiries for one person**

Every therapist has a **Send an enquiry to [name]** button on their own profile
page. Those enquiries arrive labelled with the person's name: in the dashboard
the Enquiries list shows "For [name]", and the email you get is subject-lined
"New enquiry for [name]".

They always come to the main inbox. If you want a therapist to get their own copy
as well, put their address in **Enquiry email** on their record. Leave it blank
and only the main inbox is notified. The address is never shown on the website.
Bear in mind these emails contain the client's contact details and message, so
only add an address where the therapist is expecting them.

The wording of both enquiry emails can be edited in the **Content** tab, under
"Email: new enquiry" and "Email: enquiry for a practitioner".

---

## 5. Photos

Two ways to add an image, both fine:

- **Upload:** click **Choose file** and pick a photo from your computer.
- **Paste a link:** if the photo already lives online, paste its web address.

A small preview appears so you can check it's the right one. Square-ish photos
look best; the site crops them to a neat square automatically.

---

## 6. Blog posts

**To write a post**

1. Open the **Blog Posts** tab, click **+ New post**
2. Fill in:
   - **Title** (required)
   - **Author** — e.g. "Well Connections"
   - **Cover image** — upload or paste a link (optional)
   - **Excerpt** — one or two lines shown in the blog list
   - **Body** — the article itself
3. Set status to **Published** when ready (or leave as **Draft** to finish later)
4. **Save**

**Formatting the body**

The body uses simple text formatting. A live **Preview** shows exactly how it
will look as you type. The basics:

| You type | You get |
|---|---|
| `# Big heading` | A large heading |
| `## Smaller heading` | A section heading |
| `**important**` | **bold text** |
| `*gentle*` | *italic text* |
| `- item` | a bullet list (one `- ` per line) |
| `> a line` | an indented quote |
| `[click here](https://...)` | a link |

Leave a blank line between paragraphs. That's all you need.

---

## 6a. Logos

The **Logos** tab controls the logos of organisations you work with.

**To add a logo**
1. Only add a logo once the organisation has agreed to it being used.
2. Click **+ Add logo**, keep the type as **Organisation logo** and type the
   organisation's name.
3. Upload the image. A PNG with a transparent background, at least 600px wide,
   looks best. (SVG files can't be uploaded.)
4. Tick where it should appear: the **Home page strip**, and/or the
   **Schools & Colleges**, **Businesses & Employers** or **Charities & Community**
   pages.
5. Choose **Published** and click **Save**. It's live straight away.

**Carousel labels** are the words that scroll between the logos on the home
page (Families, Schools, Organisations, Individuals). Add or edit them the same
way, choosing **Carousel label** as the type.

**Order:** use the up and down arrows. The home page strip follows the same
order.

Good to know:
- Each page's logo section only appears once it has at least one logo.
- The home page strip only appears once at least 3 logos are ticked for it.
- Logos show in grey and come into colour when someone hovers over them.

---

## 7. Draft vs Published — the golden rule

- **Published** = live on the website now.
- **Draft** = saved but hidden from the public.

Use Draft to prepare a therapist profile, a new team page, or an article before
it goes live. Switch it to Published when you're happy. You can switch back to
Draft to pull something offline without losing it.

---

## 8. Quick answers

**I published something but can't see it on the site.**
Refresh the public page (the site caches for speed). If it's still missing,
check the item isn't set to **Draft**, and that the therapist is ticked for the
team page you're looking at.

**A photo isn't showing.**
The image link may be broken. Re-upload the photo, or paste a fresh link.

**I deleted something by mistake.**
Deletions can't be undone from here. Add the item again, or ask your web person
whether a backup is available.

**Do I need to "publish the whole site" after changes?**
No. Every Save takes effect immediately. There's no separate publish step for
the site as a whole.

---

## 9. Everyday checklist

- Adding a new therapist → **Therapists → + Add therapist → tick their teams → Save**
- New specialism page → **Teams → + Add team → Save**, then add/tick therapists
- New article → **Blog Posts → + New post → write → Published → Save**
- Taking something offline → **Edit → set to Draft → Save**

Keep your password somewhere safe, and sign out on shared machines. That's the
whole system.
