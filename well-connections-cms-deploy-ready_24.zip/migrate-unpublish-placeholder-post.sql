-- Unpublish the demo/placeholder blog article flagged for replacement.
-- Sam asked for the incomplete article and its watermarked image to be removed
-- before launch. This sets it to draft so it no longer shows on the public
-- /blog list, without deleting it (so the content can be revisited if wanted).
-- Run once:
--   npx wrangler d1 execute wellconnections-cms --remote --file=./migrate-unpublish-placeholder-post.sql

UPDATE posts
SET status = 'draft',
    updated_at = datetime('now')
WHERE slug = 'helping-a-teenager-who-wont-talk';

-- Verify:
SELECT slug, status FROM posts;
