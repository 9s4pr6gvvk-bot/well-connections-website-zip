# Well Connections CMS — Developer Notes (for Frankie)

Your own pick-it-up guide. Not for the client. This is what you need to
remember to work on, change, or redeploy this site later.

---

## 1. What this project is, in one paragraph

A static-feeling website with a custom CMS, running entirely on Cloudflare.
The home page is plain HTML. The team pages, therapist listings, and blog are
generated on the fly from a database. The business owner logs in at `/admin`
to manage content. No WordPress, no build step, no npm packages to install.

Live site: **https://wellconnections.pages.dev**
Admin: **https://wellconnections.pages.dev/admin**

---

## 2. The stack (what each piece is)

- **Cloudflare Pages** — hosts the site. Free tier.
- **Pages Functions** — the code in the `functions/` folder. Runs the API and
  renders the dynamic pages (`/team`, `/team/<slug>`, `/blog`, etc).
- **D1** — the database (Cloudflare's SQLite). Holds teams, therapists, posts.
  Named `wellconnections-cms`.
- **R2** — image storage. NOT enabled yet (needs a card on file). Uploads are
  off; image URLs are pasted instead. To enable later: turn on R2 in the
  dashboard, create the bucket, uncomment the `[[r2_buckets]]` block in
  `wrangler.toml`, redeploy.
- **Admin access** — controlled by Cloudflare Access (Zero Trust), not a
  password. Two env vars, `CF_ACCESS_TEAM_DOMAIN` and `CF_ACCESS_AUD`, let the
  origin verify the Access JWT. Stored in Cloudflare, not in the files.

There is **no card on the Cloudflare account**, so it cannot be billed.
Everything sits in free tiers.

---

## 3. Folder map (what lives where)

```
public/
  index.html            Home page (plain HTML, hand-edited)
  admin/index.html      The CMS admin app (one big HTML file, vanilla JS)
functions/
  _middleware.js        Blocks API writes unless logged in
  team.js               /team hub (lists teams)
  team/[slug].js        /team/<slug> single team page
  blog.js               /blog list
  blog/[slug].js        /blog/<slug> article
  media/[[path]].js     Serves R2 images (when R2 is on)
  api/
    login.js logout.js me.js  upload.js
    teams.js       teams/[id].js
    therapists.js  therapists/[id].js
    posts.js       posts/[id].js
shared/
  auth.js               Login/session code (HMAC-signed cookies)
  layout.js             Shared page shell — nav + footer for all dynamic pages
  markdown.js           Markdown -> HTML for blog bodies; slug helper
schema.sql              Database table definitions
seed.sql                Demo data (teams + 27 therapists + 1 post)
wrangler.toml           Cloudflare config (has the real database_id)
TRAINING-MANUAL.md      The CLIENT's guide (for the owner, not you)
DEVELOPER-NOTES.md      This file
_reference/             Original static pages, kept for reference
```

Rule of thumb: **content changes happen in `/admin`, not in files. Code or
design changes happen in the files, then you redeploy.**

---

## 4. The two things that trip you up (learned the hard way)

**a) The `.wrangler` folder and folder name (1)/(2)/(3).** When you re-download
and extract the zip, Windows names it `well-connections-cms (2)` etc. The
number is irrelevant — commands run from inside the folder. A hidden
`.wrangler` folder appears after you run commands; ignore it.

**b) Slugs are the glue.** Therapists are linked to a team by the team's
**slug** (e.g. `child-teens`), stored in the therapist's `teams` field as
`|child-teens|`. If a team's slug changes, its therapists drop off the page
until the slug is put back. The team editor no longer changes slugs
automatically (that was a bug, now fixed) — it only changes if you type a new
one in the "Web address (slug)" box. **Set slugs once, leave them alone.**

---

## 5. How to make a change and put it live

Everything runs from the project folder. Open a terminal there: open the
folder in File Explorer, click the address bar, type `cmd`, Enter.

**First time on a new computer only:**
```
npx wrangler login
```
(Opens the browser to authorise. One time.)

**To deploy any code/design change:**
```
npx wrangler pages deploy
```
Wait for "Deployment complete!". That's it. Content in the database is
untouched by a deploy.

**To view a page as the public sees it:** use an Incognito window and hard
refresh (Ctrl+F5). Cloudflare caches, and Incognito also disables browser
extensions that can distort how the page looks.

---

## 6. Database commands (rarely needed)

You almost never touch the database directly — the admin does it. But if you
must:

```
# Run a SQL file against the live database
npx wrangler d1 execute wellconnections-cms --remote --file=./schema.sql

# Run a one-off query (example: list team slugs)
npx wrangler d1 execute wellconnections-cms --remote --command="SELECT name, slug FROM teams;"
```

The database id is already in `wrangler.toml`. If you ever recreate the
database, paste the new id into that file's `database_id` line.

---

## 7. Managing admin access

Access is granted through Cloudflare Access (Zero Trust), not a password. To add
or remove who can reach `/admin`, edit the Access application's policy in the
Cloudflare dashboard (add or remove the allowed email addresses). Changes take
effect immediately, with no redeploy.

The origin verifies the Access JWT using two env vars:
```
npx wrangler pages secret put CF_ACCESS_TEAM_DOMAIN   # e.g. yourteam.cloudflareaccess.com
npx wrangler pages secret put CF_ACCESS_AUD           # the Access application AUD tag
```
If either is unset, all admin reads and writes fail closed.

---

## 8. Known gaps / TODO (as of handover)

Things discussed but not yet built — pick these up when ready:

- **Therapist profile pages.** The "Read profile" links currently point at the
  OLD WordPress site (`wellconnections.co.uk/therapist/...`). There are no
  individual profile pages in the new CMS yet. To build: add a `slug` and
  richer profile fields to therapists, a `/therapist/[slug].js` page template,
  and repoint the card links. Content to come from Frankie.

- **Security hardening for production.** Login has no rate-limiting, and there's
  a low-risk CSRF gap (mitigated by SameSite=Strict cookies). Fine for a demo;
  add both before this holds real client data long-term.

- **SEO for go-live.** Before this replaces the real site on
  `wellconnections.co.uk`: add canonical tags, an XML sitemap, a robots.txt,
  and BLOCK the `.pages.dev` address from Google (to avoid duplicate content).
  Also plan redirects from old WordPress URLs to new ones so existing rankings
  aren't lost.

- **Custom domain.** Currently on `wellconnections.pages.dev`. To go live on the
  real domain, add it as a custom domain in the Pages project settings and
  point DNS. (This is also where the SEO items above become important.)

- **R2 image uploads.** Off until a card is added and R2 enabled. Until then,
  photos are added by pasting image URLs.

---

## 9. If something breaks

- **A page shows "not found" or "0 therapists":** almost always a slug mismatch.
  Check the team's slug in `/admin` matches what the therapists are tagged to.
- **A deploy fails mentioning R2:** the `[[r2_buckets]]` block is in
  `wrangler.toml` but R2 isn't enabled. Comment that block out (or enable R2).
- **Admin changes don't show on the site:** hard refresh (Ctrl+F5) / Incognito;
  it's caching, not a bug.
- **"wrangler not found":** close and reopen the terminal (needs a fresh window
  after Node install), and make sure you're inside the project folder.

You built this. It's simpler than it looks — mostly plain HTML, a bit of
vanilla JavaScript, and small server files. Nothing here needs a framework or
a build tool.
