import { json } from "../../shared/layout.js";

export async function onRequestGet(context) {
  const { env, data } = context;
  const isAdmin = !!data.session;
  const sql = isAdmin
    ? "SELECT * FROM faqs ORDER BY sort_order ASC, id ASC"
    : "SELECT * FROM faqs WHERE status='published' ORDER BY sort_order ASC, id ASC";
  const { results } = await env.DB.prepare(sql).all();
  return json(results || []);
}

export async function onRequestPost(context) {
  const { request, env } = context;
  let b;
  try { b = await request.json(); } catch { return json({ error: "Bad request" }, 400); }
  const question = (b.question || "").trim();
  const answer = (b.answer || "").trim();
  if (!question) return json({ error: "Question is required" }, 400);
  if (!answer) return json({ error: "Answer is required" }, 400);
  const status = b.status === "draft" ? "draft" : "published";
  const sort = Number.isFinite(+b.sort_order) ? +b.sort_order : 0;
  const { results } = await env.DB.prepare(
    `INSERT INTO faqs (question, answer, status, sort_order) VALUES (?, ?, ?, ?) RETURNING *`
  ).bind(question, answer, status, sort).all();
  return json(results[0], 201);
}
