import { json } from "../../../shared/layout.js";

export async function onRequestGet(context) {
  const { env, params, data } = context;
  const row = await env.DB.prepare("SELECT * FROM testimonials WHERE id=?").bind(params.id).first();
  if (!row) return json({ error: "Not found" }, 404);
  if (row.status !== "published" && !data.session) return json({ error: "Not found" }, 404);
  return json(row);
}

export async function onRequestPut(context) {
  const { request, env, params } = context;
  const id = Number(params.id);
  let b;
  try { b = await request.json(); } catch { return json({ error: "Bad request" }, 400); }
  const existing = await env.DB.prepare("SELECT * FROM testimonials WHERE id=?").bind(id).first();
  if (!existing) return json({ error: "Not found" }, 404);
  const quote = ("quote" in b ? b.quote : existing.quote || "").trim();
  if (!quote) return json({ error: "Quote is required" }, 400);
  const author = "author" in b ? b.author : existing.author;
  const detail = "detail" in b ? b.detail : existing.detail;
  const status = ("status" in b ? b.status : existing.status) === "draft" ? "draft" : "published";
  const sort = "sort_order" in b ? (+b.sort_order || 0) : existing.sort_order;
  const { results } = await env.DB.prepare(
    `UPDATE testimonials SET quote=?, author=?, detail=?, status=?, sort_order=?, updated_at=datetime('now') WHERE id=? RETURNING *`
  ).bind(quote, author || "", detail || "", status, sort, id).all();
  return json(results[0]);
}

export async function onRequestDelete(context) {
  const { env, params } = context;
  await env.DB.prepare("DELETE FROM testimonials WHERE id=?").bind(params.id).run();
  return json({ ok: true });
}
