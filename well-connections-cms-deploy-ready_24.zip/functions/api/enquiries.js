import { json } from "../../shared/layout.js";
import { sendEmail, emailShell, esc, detailsTable, emailHeading, fromWithName } from "../../shared/email.js";
import { verifyTurnstile } from "../../shared/turnstile.js";
import { getContent, fill } from "../../shared/content.js";
import { slugify } from "../../shared/markdown.js";

// Resolve the practitioner an enquiry was sent from. The browser only sends the
// profile slug; the name and inbox come from the database so neither can be
// forged in the payload. Returns blanks if the slug matches nobody published.
async function resolvePractitioner(env, slug) {
  if (!slug) return { name: "", email: "" };
  try {
    const { results } = await env.DB.prepare(
      "SELECT * FROM therapists WHERE status='published'"
    ).all();
    const match = (results || []).find((p) => slugify(p.name) === slug);
    if (!match) return { name: "", email: "" };
    const email = (match.enquiry_email || "").toString().trim();
    return { name: match.name || "", email };
  } catch {
    return { name: "", email: "" };
  }
}

// GET  /api/enquiries  -> admin: all enquiries (newest first, unread first)
// POST /api/enquiries  -> public: contact-form submission
export async function onRequestGet(context) {
  const { env, data } = context;
  if (!data.session) return json({ error: "Not authenticated" }, 401);
  const { results } = await env.DB.prepare(
    "SELECT * FROM enquiries ORDER BY created_at DESC, id DESC"
  ).all();
  return json(results || []);
}

export async function onRequestPost(context) {
  const { request, env } = context;
  let b;
  try { b = await request.json(); } catch { return json({ error: "Bad request" }, 400); }

  const ts = await verifyTurnstile(env, b.turnstile_token, request.headers.get("CF-Connecting-IP"));
  if (!ts.ok) return json({ error: "Please complete the verification and try again." }, 400);

  const name = (b.name || "").toString().trim().slice(0, 120);
  const email = (b.email || "").toString().trim().slice(0, 200);
  if (!name) return json({ error: "Please enter your name." }, 400);
  if (!/^[^\s@"'<>&]+@[^\s@"'<>&]+\.[^\s@"'<>&]+$/.test(email)) return json({ error: "Please enter a valid email address." }, 400);

  const phone = (b.phone || "").toString().trim().slice(0, 60);
  const organisation = (b.organisation || "").toString().trim().slice(0, 160);
  const service = (b.service || "").toString().trim().slice(0, 160);
  const message = (b.message || "").toString().trim().slice(0, 4000);
  const therapistSlug = (b.therapist_slug || "").toString().trim().slice(0, 160);

  const practitioner = await resolvePractitioner(env, therapistSlug);

  let row;
  try {
    const res = await env.DB.prepare(
      `INSERT INTO enquiries (name, email, phone, organisation, service, message, therapist)
       VALUES (?, ?, ?, ?, ?, ?, ?) RETURNING *`
    ).bind(name, email, phone, organisation, service, message, practitioner.name).all();
    row = res.results[0];
  } catch (e) {
    // Older database without the `therapist` column (migration not run yet):
    // still save the enquiry rather than losing it, and let the email carry
    // the practitioner through.
    try {
      const res = await env.DB.prepare(
        `INSERT INTO enquiries (name, email, phone, organisation, service, message)
         VALUES (?, ?, ?, ?, ?, ?) RETURNING *`
      ).bind(name, email, phone, organisation, service, message).all();
      row = res.results[0];
    } catch (e2) {
      return json({ error: "Could not send your enquiry. Please try again." }, 500);
    }
  }

  const adminTo = env.BOOKING_TO || env.ADMIN_EMAIL;
  // The team inbox always gets it. A practitioner is copied in only when an
  // enquiry email is set against their profile in the dashboard.
  const to = [adminTo, practitioner.email].filter(Boolean);
  if (to.length) {
    const C = await getContent(env);
    const vars = { name, therapist: practitioner.name };
    const pairs = [
      ...(practitioner.name ? [["Enquiry for", practitioner.name]] : []),
      ["Name", name], ["Email", email], ["Phone", phone || "\u2014"],
      ["Organisation", organisation || "\u2014"], ["Interested in", service || "\u2014"],
      ["Message", message || "\u2014"],
    ];
    // Enquiry alerts send from "New Enquiry" (not "Well Connections") so they
    // stand out in the inbox and don't get lost among CC'd mail. Same verified
    // address as everything else. Override the display name with ENQUIRY_FROM_NAME.
    await sendEmail(env, {
      to,
      replyTo: email,
      from: fromWithName(env.BOOKING_FROM, env.ENQUIRY_FROM_NAME || "New Enquiry"),
      subject: fill(practitioner.name ? C.email_enq_person_subject : C.email_enq_subject, vars),
      html: emailShell(
        emailHeading(
          fill(practitioner.name ? C.email_enq_person_heading : C.email_enq_heading, vars),
          fill(practitioner.name ? C.email_enq_person_intro : C.email_enq_intro, vars)
        )
        + detailsTable(pairs)
        + `<p style="margin:18px 0 0;font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;font-size:13px;color:#5a6b63;">${esc(fill(C.email_enq_footnote, vars))}</p>`
      , env.SITE_URL),
    });
  }

  return json({ ok: true });
}
