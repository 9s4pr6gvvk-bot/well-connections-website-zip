import { json } from "../../../shared/layout.js";
import { sendEmail, emailShell, esc, detailsTable, emailHeading } from "../../../shared/email.js";
import { bookingIcs, toBase64, icsFilename } from "../../../shared/ics.js";
import { getSettings, formatSlot } from "../../../shared/availability.js";
import { getContent, fill, htmlText } from "../../../shared/content.js";

// GET    /api/bookings/:id  -> admin views one booking (marks it seen)
// PUT    /api/bookings/:id  -> admin acts: { action: accept|decline, admin_note? }
// DELETE /api/bookings/:id  -> admin removes a booking
export async function onRequestGet(context) {
  const { env, params, data } = context;
  if (!data.session) return json({ error: "Not authenticated" }, 401);
  const row = await env.DB.prepare("SELECT * FROM bookings WHERE id=?").bind(params.id).first();
  if (!row) return json({ error: "Not found" }, 404);
  if (!row.seen_by_admin) {
    await env.DB.prepare("UPDATE bookings SET seen_by_admin=1 WHERE id=?").bind(row.id).run();
    row.seen_by_admin = 1;
  }
  return json(row);
}

export async function onRequestPut(context) {
  const { request, env, params, data } = context;
  if (!data.session) return json({ error: "Not authenticated" }, 401);
  let b;
  try { b = await request.json(); } catch { return json({ error: "Bad request" }, 400); }

  const booking = await env.DB.prepare("SELECT * FROM bookings WHERE id=?").bind(params.id).first();
  if (!booking) return json({ error: "Not found" }, 404);

  const action = (b.action || "").toString();
  const isPreview = b.preview === true || b.preview === "1";

  let status;
  if (action === "accept") status = "accepted";
  else if (action === "decline") status = "declined";
  else return json({ error: "Unknown action." }, 400);

  // The admin edits the whole email, so the message body and subject are fully
  // custom. On the first preview call none are supplied yet, so fall back to the
  // editable defaults built from the content templates. Once the admin types,
  // their exact subject and body are what gets previewed and sent.
  const defaults = await defaultEmail(env, booking, status);
  const hasCustomSubject = typeof b.subject === "string";
  const hasCustomBody = typeof b.body === "string";
  const subject = (hasCustomSubject ? b.subject : defaults.subject).toString().slice(0, 300);
  const body = (hasCustomBody ? b.body : defaults.body).toString().slice(0, 8000);
  const html = emailShell(bodyToHtml(body));

  // Preview mode: render only, do not change the booking or send anything.
  // Return the editable defaults too, so the card can prefill its fields.
  if (isPreview) {
    return json({ preview: true, to: booking.email, status, subject, body, html });
  }

  // The full sent text is stored in admin_note as a record of what went out.
  const { results } = await env.DB.prepare(
    `UPDATE bookings SET status=?, admin_note=?, updated_at=datetime('now') WHERE id=? RETURNING *`
  ).bind(status, body.trim().slice(0, 8000), booking.id).all();
  const updated = results[0];

  const siteUrl = env.SITE_URL || "https://wellconnections.co.uk";
  const invite = (audience) => [{
    filename: icsFilename(updated),
    content: toBase64(bookingIcs(updated, { audience, siteUrl })),
    content_type: "text/calendar; charset=utf-8; method=PUBLISH",
  }];

  // Visitor: the decision email, plus their own calendar invite when accepted.
  await sendEmail(env, {
    to: booking.email,
    replyTo: env.BOOKING_TO || env.ADMIN_EMAIL || undefined,
    subject,
    html,
    ...(status === "accepted" ? { attachments: invite("visitor") } : {}),
  });

  // Well Connections: a copy with the full details and an invite to add to Outlook.
  const adminTo = env.BOOKING_TO || env.ADMIN_EMAIL;
  if (status === "accepted" && adminTo) {
    const settings = await getSettings(env);
    const when = formatSlot(updated.slot_start, settings.timezone);
    await sendEmail(env, {
      to: adminTo,
      replyTo: booking.email,
      subject: `Accepted: ${booking.name}, ${when}`,
      html: emailShell(
        emailHeading("Booking accepted", "Open the attached invite to add this booking to your calendar.")
        + detailsTable([
          ["Name", booking.name], ["When", when], ["Length", (updated.duration_min || 30) + " min"],
          ["Service", updated.service || "Not given"], ["Email", booking.email], ["Phone", booking.phone || "Not given"],
        ]),
        env.SITE_URL
      ),
      attachments: invite("admin"),
    });
  }

  return json(updated);
}

// The editable default subject + full message body for a decision, built from
// the content templates with {name}/{when} filled in. Everything a visitor
// reads is one plain-text block the admin can edit end to end.
async function defaultEmail(env, booking, status) {
  const settings = await getSettings(env);
  const when = formatSlot(booking.slot_start, settings.timezone);
  const C = await getContent(env);
  const vars = { name: booking.name, when };
  const f = (k) => fill(C[k], vars);

  let subject, parts;
  if (status === "accepted") {
    subject = f("email_bk_accept_subject");
    parts = [
      f("email_bk_accept_greeting"),
      f("email_bk_accept_line1") + "\n" + when,
      f("email_bk_accept_line2"),
      f("email_signoff"),
    ];
  } else {
    subject = f("email_bk_decline_subject");
    parts = [
      f("email_bk_decline_greeting"),
      f("email_bk_decline_line1"),
      f("email_bk_decline_line2"),
      f("email_signoff"),
    ];
  }
  return { subject, body: parts.join("\n\n") };
}

// Turn the admin's plain-text message into the branded email body: blank lines
// separate paragraphs, single newlines become line breaks. Everything is
// escaped, so no admin input can break the HTML.
function bodyToHtml(text) {
  const blocks = String(text == null ? "" : text)
    .replace(/\r\n/g, "\n")
    .split(/\n{2,}/)
    .map((s) => s.trim())
    .filter(Boolean);
  if (!blocks.length) return `<p style="margin:0;font-size:15px;color:#1a2820">&nbsp;</p>`;
  return blocks
    .map((block, i) => {
      const last = i === blocks.length - 1;
      const style = last
        ? "margin:24px 0 0;font-size:13px;color:#5a6b63;line-height:1.6"
        : "margin:0 0 14px;font-size:15px;line-height:1.65;color:#1a2820";
      return `<p style="${style}">${esc(block).replace(/\n/g, "<br>")}</p>`;
    })
    .join("");
}

export async function onRequestDelete(context) {
  const { env, params, data } = context;
  if (!data.session) return json({ error: "Not authenticated" }, 401);
  await env.DB.prepare("DELETE FROM bookings WHERE id=?").bind(params.id).run();
  return json({ ok: true });
}
