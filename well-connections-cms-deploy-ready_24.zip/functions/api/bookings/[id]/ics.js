import { json } from "../../../../shared/layout.js";
import { bookingIcs, icsFilename } from "../../../../shared/ics.js";

// GET /api/bookings/:id/ics -> admin downloads the calendar invite for a booking,
// for adding it to Outlook again if the email copy has gone.
export async function onRequestGet(context) {
  const { env, params, data } = context;
  if (!data.session) return json({ error: "Not authenticated" }, 401);
  const row = await env.DB.prepare("SELECT * FROM bookings WHERE id=?").bind(params.id).first();
  if (!row) return json({ error: "Not found" }, 404);
  return new Response(bookingIcs(row, { audience: "admin", siteUrl: env.SITE_URL || "https://wellconnections.co.uk" }), {
    headers: {
      "content-type": "text/calendar; charset=utf-8",
      "content-disposition": `attachment; filename="${icsFilename(row)}"`,
      "cache-control": "no-store",
    },
  });
}
