import { json } from "../../shared/layout.js";
import { CONTENT_GROUPS, CONTENT_DEFAULTS, CONTENT_KEYS, getContent } from "../../shared/content.js";

// Admin-only editor for all chat and email copy.
// GET /api/content -> { groups, values, defaults }
// PUT /api/content -> save overrides { key: value, ... } into app_settings (txt_*)
export async function onRequestGet(context) {
  const { env, data } = context;
  if (!data.session) return json({ error: "Not authenticated" }, 401);
  return json({
    groups: CONTENT_GROUPS,
    values: await getContent(env),
    defaults: CONTENT_DEFAULTS,
  });
}

export async function onRequestPut(context) {
  const { request, env, data } = context;
  if (!data.session) return json({ error: "Not authenticated" }, 401);

  let b;
  try { b = await request.json(); } catch { return json({ error: "Bad request" }, 400); }
  if (!b || typeof b !== "object") return json({ error: "Bad request" }, 400);

  const updates = [];
  for (const key of CONTENT_KEYS) {
    if (!(key in b)) continue;
    // Empty/blank -> remove the override so the default is used again.
    const val = b[key] == null ? "" : String(b[key]).slice(0, 5000);
    updates.push({ key, val });
  }

  try {
    for (const { key, val } of updates) {
      const sKey = "txt_" + key;
      if (val.trim() === "") {
        await env.DB.prepare("DELETE FROM app_settings WHERE key=?").bind(sKey).run();
      } else {
        await env.DB.prepare(
          `INSERT INTO app_settings (key, value, updated_at) VALUES (?, ?, datetime('now'))
           ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=datetime('now')`
        ).bind(sKey, val).run();
      }
    }
  } catch {
    return json({ error: "Could not save. Is the settings table set up? Run the bookings migration." }, 500);
  }

  return json({ values: await getContent(env) });
}
