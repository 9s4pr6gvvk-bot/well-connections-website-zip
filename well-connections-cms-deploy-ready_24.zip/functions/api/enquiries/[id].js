import { json } from "../../../shared/layout.js";

// GET    /api/enquiries/:id  -> admin views one (marks read)
// PUT    /api/enquiries/:id  -> admin sets status { status: read|archived|new }
// DELETE /api/enquiries/:id  -> admin removes it
export async function onRequestGet(context) {
  const { env, params, data } = context;
  if (!data.session) return json({ error: "Not authenticated" }, 401);
  const row = await env.DB.prepare("SELECT * FROM enquiries WHERE id=?").bind(params.id).first();
  if (!row) return json({ error: "Not found" }, 404);
  if (row.status === "new") {
    await env.DB.prepare("UPDATE enquiries SET status='read' WHERE id=?").bind(row.id).run();
    row.status = "read";
  }
  return json(row);
}

export async function onRequestPut(context) {
  const { request, env, params, data } = context;
  if (!data.session) return json({ error: "Not authenticated" }, 401);
  let b;
  try { b = await request.json(); } catch { return json({ error: "Bad request" }, 400); }
  const status = ["new", "read", "archived"].includes(b.status) ? b.status : "read";
  const { results } = await env.DB.prepare(
    "UPDATE enquiries SET status=? WHERE id=? RETURNING *"
  ).bind(status, params.id).all();
  if (!results.length) return json({ error: "Not found" }, 404);
  return json(results[0]);
}

export async function onRequestDelete(context) {
  const { env, params, data } = context;
  if (!data.session) return json({ error: "Not authenticated" }, 401);
  await env.DB.prepare("DELETE FROM enquiries WHERE id=?").bind(params.id).run();
  return json({ ok: true });
}
