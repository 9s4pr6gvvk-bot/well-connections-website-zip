import { json } from "../../../shared/layout.js";
import { cleanLogo } from "../../../shared/logos.js";

export async function onRequestPut(context) {
  const { request, env, params } = context;
  const id = Number(params.id);
  let b;
  try { b = await request.json(); } catch { return json({ error: "Bad request" }, 400); }
  const existing = await env.DB.prepare("SELECT * FROM logos WHERE id=?").bind(id).first();
  if (!existing) return json({ error: "Not found" }, 404);
  const c = cleanLogo(b, existing);
  if (c.error) return json({ error: c.error }, 400);
  const { results } = await env.DB.prepare(
    "UPDATE logos SET kind=?, name=?, image_url=?, pages=?, status=?, sort_order=?, updated_at=datetime('now') WHERE id=? RETURNING *"
  ).bind(c.kind, c.name, c.image_url, c.pages, c.status, c.sort_order, id).all();
  return json(results[0]);
}

export async function onRequestDelete(context) {
  const { env, params } = context;
  await env.DB.prepare("DELETE FROM logos WHERE id=?").bind(params.id).run();
  return json({ ok: true });
}
