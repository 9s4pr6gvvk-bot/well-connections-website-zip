import { json } from "../../../shared/layout.js";
import { getContent } from "../../../shared/content.js";
import {
  getChatSettings, publicChatState, describeSchedule, parseDays, normTime,
} from "../../../shared/chat-schedule.js";

// Live-chat configuration, stored in app_settings under chat_* keys.
//
// GET  /api/chat/config -> public: { enabled, open, mode, hours, copy }.
//                          The widget reads this on every page load: it only
//                          builds itself when enabled, and when `open` is false
//                          it either shows an away message or stays hidden,
//                          depending on `mode`.
// PUT  /api/chat/config -> admin: { enabled, schedule: { on, days, start, end,
//                          timezone, mode } }. Any field left out is unchanged.
//
// Defaults: master switch ON, schedule OFF. So chat behaves exactly as it did
// before this build until opening hours are deliberately turned on.

export async function onRequestGet(context) {
  const { env, data } = context;
  const settings = await getChatSettings(env);
  const state = publicChatState(settings);
  // Expose only the chat_* copy to the public widget (never email copy).
  const all = await getContent(env);
  const copy = {};
  for (const k of Object.keys(all)) if (k.startsWith("chat_")) copy[k] = all[k];
  // The dashboard needs the raw schedule to fill in its form; the public
  // widget only ever needs to know whether chat is open right now.
  const forAdmin = data && data.session ? {
    schedule: {
      on: settings.scheduleOn,
      days: settings.days,
      start: settings.start,
      end: settings.end,
      timezone: settings.timezone,
      mode: settings.mode,
      summary: describeSchedule(settings),
    },
  } : {};
  return json({ ...state, ...forAdmin, copy });
}

export async function onRequestPut(context) {
  const { request, env, data } = context;
  // Middleware already gates admin writes, but check here too (defence in depth).
  if (!data.session) return json({ error: "Not authenticated" }, 401);

  let b;
  try { b = await request.json(); } catch { return json({ error: "Bad request" }, 400); }

  const writes = [];
  if ("enabled" in b) writes.push(["chat_enabled", b.enabled ? "1" : "0"]);

  const sched = b.schedule;
  if (sched && typeof sched === "object") {
    if ("on" in sched) writes.push(["chat_sched_on", sched.on ? "1" : "0"]);
    if ("days" in sched) {
      const days = parseDays(Array.isArray(sched.days) ? sched.days.join(",") : sched.days, "");
      writes.push(["chat_sched_days", days.join(",")]);
    }
    if ("start" in sched) writes.push(["chat_sched_start", normTime(sched.start, "09:00")]);
    if ("end" in sched) writes.push(["chat_sched_end", normTime(sched.end, "17:00")]);
    if ("timezone" in sched) {
      writes.push(["chat_sched_tz", String(sched.timezone || "").trim().slice(0, 60) || "Europe/London"]);
    }
    if ("mode" in sched) writes.push(["chat_sched_mode", sched.mode === "hide" ? "hide" : "away"]);
  }

  try {
    for (const [key, value] of writes) {
      await env.DB.prepare(
        `INSERT INTO app_settings (key, value, updated_at) VALUES (?, ?, datetime('now'))
         ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=datetime('now')`
      ).bind(key, value).run();
    }
  } catch {
    return json({ error: "Could not save. Is the settings table set up? Run the bookings migration." }, 500);
  }

  const settings = await getChatSettings(env);
  return json({
    ...publicChatState(settings),
    schedule: {
      on: settings.scheduleOn,
      days: settings.days,
      start: settings.start,
      end: settings.end,
      timezone: settings.timezone,
      mode: settings.mode,
      summary: describeSchedule(settings),
    },
  });
}
