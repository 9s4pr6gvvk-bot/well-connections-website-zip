import { json } from "../../../shared/layout.js";

// GET /api/chat/messages?token=...  -> visitor polls their own thread.
// The token is an unguessable UUID, so it authorises access to that thread only.
export async function onRequestGet(context) {
  const { request, env } = context;
  const token = new URL(request.url).searchParams.get("token");
  if (!token) return json({ messages: [] });
  const thread = await env.DB.prepare("SELECT id FROM chat_threads WHERE token=?").bind(token).first();
  if (!thread) return json({ messages: [] });

  // mark admin replies as seen by the visitor
  await env.DB.prepare("UPDATE chat_messages SET seen_by_visitor=1 WHERE thread_id=? AND sender='admin'").bind(thread.id).run();

  const msgs = (await env.DB.prepare(
    "SELECT sender, body, created_at FROM chat_messages WHERE thread_id=? ORDER BY id ASC"
  ).bind(thread.id).all()).results || [];
  return json({ messages: msgs });
}
