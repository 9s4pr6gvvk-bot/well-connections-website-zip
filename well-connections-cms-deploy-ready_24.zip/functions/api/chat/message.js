import { json } from "../../../shared/layout.js";
import { verifyTurnstile } from "../../../shared/turnstile.js";
import { sendEmail, emailShell, emailHeading, detailsTable, esc } from "../../../shared/email.js";
import { getChatSettings, isChatOpen, describeSchedule } from "../../../shared/chat-schedule.js";
import { getContent, fill } from "../../../shared/content.js";

// POST /api/chat/message  { token?, name?, email?, body, turnstile_token? }
// Public (visitors are anonymous). Creates a thread on first message,
// otherwise appends to the existing thread identified by the token.
export async function onRequestPost(context) {
  const { request, env } = context;
  let b;
  try { b = await request.json(); } catch { return json({ error: "Bad request" }, 400); }

  const body = (b.body || "").toString().trim();
  if (!body) return json({ error: "Message is required" }, 400);
  if (body.length > 2000) return json({ error: "Message is too long" }, 400);

  // Chat closed (master switch off, or outside opening hours)? Refuse the
  // message rather than taking one nobody is going to see. The widget hides or
  // disables its box at the same time; this is the check that actually holds,
  // since a page left open past closing time still has a live send button.
  const chat = await getChatSettings(env);
  if (!isChatOpen(chat)) {
    const C = await getContent(env);
    const hours = describeSchedule(chat);
    return json({
      error: fill(C.chat_closed_notice, { hours: hours || "our usual hours" }),
      closed: true,
      hours,
    }, 403);
  }

  let thread = null;
  if (b.token) {
    thread = await env.DB.prepare("SELECT * FROM chat_threads WHERE token=?").bind(b.token).first();
  }
  const isNewThread = !thread;

  if (!thread) {
    // Starting a new thread is the spammable action, so verify Turnstile here.
    // Follow-up messages on an existing thread (valid token) are already vouched
    // for and skip the check, keeping the conversation smooth. Inert until
    // TURNSTILE_SECRET_KEY is set, so this changes nothing before setup.
    const ts = await verifyTurnstile(env, b.turnstile_token, request.headers.get("CF-Connecting-IP"));
    if (!ts.ok) return json({ error: "Please complete the verification and try again." }, 400);

    const token = crypto.randomUUID();
    const name = (b.name || "").toString().slice(0, 120);
    const email = (b.email || "").toString().slice(0, 200);
    const res = await env.DB.prepare(
      "INSERT INTO chat_threads (token, name, email) VALUES (?, ?, ?) RETURNING *"
    ).bind(token, name, email).all();
    thread = res.results[0];
  } else if ((b.name || b.email) && (!thread.name || !thread.email)) {
    // fill in details if provided later
    await env.DB.prepare("UPDATE chat_threads SET name=COALESCE(NULLIF(?,''),name), email=COALESCE(NULLIF(?,''),email) WHERE id=?")
      .bind((b.name||"").toString().slice(0,120), (b.email||"").toString().slice(0,200), thread.id).run();
  }

  await env.DB.prepare(
    "INSERT INTO chat_messages (thread_id, sender, body, seen_by_visitor) VALUES (?, 'visitor', ?, 1)"
  ).bind(thread.id, body).run();
  await env.DB.prepare("UPDATE chat_threads SET last_message_at=datetime('now') WHERE id=?").bind(thread.id).run();

  const msgs = (await env.DB.prepare(
    "SELECT sender, body, created_at FROM chat_messages WHERE thread_id=? ORDER BY id ASC"
  ).bind(thread.id).all()).results || [];

  // Notify the admin that a visitor has sent a chat message. Booking and
  // enquiry submissions already do this; live chat did not, so replies could be
  // missed. Sent in the background (waitUntil) so the visitor's send stays
  // instant, and no-ops safely until RESEND_API_KEY is configured.
  const to = env.BOOKING_TO || env.ADMIN_EMAIL;
  if (to) {
    const visitorName = (thread.name || b.name || "").toString().trim() || "Website visitor";
    const visitorEmail = (thread.email || b.email || "").toString().trim();
    const adminUrl = (env.SITE_URL || "https://wellconnections.co.uk") + "/admin/";
    const heading = isNewThread
      ? `New website chat from ${visitorName}`
      : `New chat reply from ${visitorName}`;
    const intro = isNewThread
      ? "Someone has started a conversation in the website live chat."
      : "A visitor has replied in an existing live chat conversation.";
    const pairs = [
      ["From", visitorName],
      ["Email", visitorEmail || "— (not provided)"],
      ["Message", body],
    ];
    const emailPromise = sendEmail(env, {
      to,
      replyTo: visitorEmail || undefined,
      subject: heading,
      html: emailShell(
        emailHeading(heading, intro)
        + detailsTable(pairs)
        + `<p style="margin:18px 0 0;font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;font-size:14px;color:#1a2820;">`
        + `<a href="${esc(adminUrl)}" style="color:#2d6e5e;">Open your dashboard</a> and go to the Messages tab to reply.</p>`
        + `<p style="margin:10px 0 0;font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;font-size:13px;color:#5a6b63;">`
        + `Replies you send from the dashboard appear in the visitor's chat window.</p>`
      , env.SITE_URL),
    });
    if (context.waitUntil) context.waitUntil(emailPromise); else await emailPromise;
  }

  return json({ token: thread.token, messages: msgs });
}
