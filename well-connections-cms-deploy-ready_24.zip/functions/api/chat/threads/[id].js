import { json } from "../../../../shared/layout.js";

// GET  /api/chat/threads/:id        -> admin views a thread (marks visitor msgs seen)
// POST /api/chat/threads/:id        -> admin posts a reply { body }
export async function onRequestGet(context) {
  const { env, params, data } = context;
  if (!data.session) return json({ error: "Not authenticated" }, 401);
  const thread = await env.DB.prepare("SELECT * FROM chat_threads WHERE id=?").bind(params.id).first();
  if (!thread) return json({ error: "Not found" }, 404);
  await env.DB.prepare("UPDATE chat_messages SET seen_by_admin=1 WHERE thread_id=? AND sender='visitor'").bind(thread.id).run();
  const messages = (await env.DB.prepare(
    "SELECT sender, body, created_at FROM chat_messages WHERE thread_id=? ORDER BY id ASC"
  ).bind(thread.id).all()).results || [];
  return json({ thread, messages });
}

export async function onRequestPost(context) {
  const { request, env, params, data } = context;
  if (!data.session) return json({ error: "Not authenticated" }, 401);
  let b;
  try { b = await request.json(); } catch { return json({ error: "Bad request" }, 400); }
  const body = (b.body || "").toString().trim();
  if (!body) return json({ error: "Reply is required" }, 400);
  const thread = await env.DB.prepare("SELECT * FROM chat_threads WHERE id=?").bind(params.id).first();
  if (!thread) return json({ error: "Not found" }, 404);

  await env.DB.prepare(
    "INSERT INTO chat_messages (thread_id, sender, body, seen_by_admin) VALUES (?, 'admin', ?, 1)"
  ).bind(thread.id, body).run();
  await env.DB.prepare("UPDATE chat_threads SET last_message_at=datetime('now') WHERE id=?").bind(thread.id).run();

  const messages = (await env.DB.prepare(
    "SELECT sender, body, created_at FROM chat_messages WHERE thread_id=? ORDER BY id ASC"
  ).bind(thread.id).all()).results || [];
  return json({ thread, messages });
}

export async function onRequestDelete(context) {
  const { env, params, data } = context;
  if (!data.session) return json({ error: "Not authenticated" }, 401);
  await env.DB.prepare("DELETE FROM chat_messages WHERE thread_id=?").bind(params.id).run();
  await env.DB.prepare("DELETE FROM chat_threads WHERE id=?").bind(params.id).run();
  return json({ ok: true });
}
