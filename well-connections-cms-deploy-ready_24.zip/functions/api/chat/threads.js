import { json } from "../../../shared/layout.js";

// GET /api/chat/threads  -> admin: all threads with last message + unread count
export async function onRequestGet(context) {
  const { env, data } = context;
  if (!data.session) return json({ error: "Not authenticated" }, 401);
  const { results } = await env.DB.prepare(
    `SELECT t.*,
      (SELECT body FROM chat_messages m WHERE m.thread_id=t.id ORDER BY m.id DESC LIMIT 1) AS last_body,
      (SELECT COUNT(*) FROM chat_messages m WHERE m.thread_id=t.id AND m.sender='visitor' AND m.seen_by_admin=0) AS unread
     FROM chat_threads t ORDER BY t.last_message_at DESC`
  ).all();
  return json(results || []);
}
