import { json } from "../../shared/layout.js";
import { sendEmail, emailShell, esc, detailsTable, emailHeading } from "../../shared/email.js";
import { getSettings, getPageSettings, isSlotBookable, formatSlot, parseQuestions } from "../../shared/availability.js";
import { verifyTurnstile } from "../../shared/turnstile.js";
import { getContent, fill, htmlText } from "../../shared/content.js";

// GET  /api/bookings   -> admin: all bookings (pending first, then by slot)
// POST /api/bookings   -> public: visitor claims an available slot
export async function onRequestGet(context) {
  const { env, data } = context;
  if (!data.session) return json({ error: "Not authenticated" }, 401);
  const { results } = await env.DB.prepare(
    "SELECT * FROM bookings ORDER BY created_at DESC, id DESC"
  ).all();
  return json(results || []);
}

export async function onRequestPost(context) {
  const { request, env } = context;
  let b;
  try { b = await request.json(); } catch { return json({ error: "Bad request" }, 400); }

  const ts = await verifyTurnstile(env, b.turnstile_token, request.headers.get("CF-Connecting-IP"));
  if (!ts.ok) return json({ error: "Please complete the verification and try again." }, 400);

  const name = (b.name || "").toString().trim().slice(0, 120);
  const email = (b.email || "").toString().trim().slice(0, 200);
  const slot = (b.slot_start || "").toString().trim().slice(0, 40);

  if (!name) return json({ error: "Please enter your name." }, 400);
  if (!/^[^\s@"'<>&]+@[^\s@"'<>&]+\.[^\s@"'<>&]+$/.test(email)) return json({ error: "Please enter a valid email address." }, 400);
  if (!slot) return json({ error: "Please choose a time." }, 400);

  // A booking may come through a specific booking page, which can carry its own
  // availability rules and custom questions. No page slug = the global flow.
  const pageSlug = (b.page || "").toString().trim().slice(0, 80);
  let page = null;
  if (pageSlug) {
    try {
      page = await env.DB.prepare(
        "SELECT * FROM booking_pages WHERE slug=? AND status='published'"
      ).bind(pageSlug).first();
    } catch { page = null; }
    if (!page) return json({ error: "That booking page is no longer available." }, 404);
  }

  const settings = page ? await getPageSettings(env, page) : await getSettings(env);

  // Collect answers to this page's custom questions, enforcing required ones.
  let answers = "";
  if (page) {
    const defs = parseQuestions(page.questions);
    const given = (b.answers && typeof b.answers === "object") ? b.answers : {};
    const collected = [];
    for (const q of defs) {
      const raw = given[q.label];
      let val;
      if (q.type === "checkbox") {
        // Tick boxes arrive as an array; keep only real choices.
        const picked = (Array.isArray(raw) ? raw : (raw ? [raw] : []))
          .map((v) => String(v).trim()).filter((v) => q.options.includes(v));
        val = picked.join("; ");
      } else {
        val = (raw || "").toString().trim().slice(0, 2000);
        if (val && (q.type === "select" || q.type === "radio") && q.options.length && !q.options.includes(val)) {
          return json({ error: `Please choose one of the options for: ${q.label}` }, 400);
        }
      }
      if (q.required && !val) return json({ error: `Please answer: ${q.label}` }, 400);
      if (val) collected.push({ label: q.label, value: val });
    }
    answers = collected.length ? JSON.stringify(collected) : "";
  }

  // Re-validate the slot server-side so nobody can book outside availability
  // or grab a slot someone else just took.
  const ok = await isSlotBookable(env, slot, settings);
  if (!ok) return json({ error: "Sorry, that time is no longer available. Please pick another." }, 409);

  const phone = (b.phone || "").toString().trim().slice(0, 60);
  const service = (b.service || "").toString().trim().slice(0, 160);
  const note = page && page.note_hidden ? "" : (b.note || "").toString().trim().slice(0, 2000);
  if (page && page.phone_required && !phone) return json({ error: "Please enter your phone number." }, 400);
  const token = crypto.randomUUID();

  let booking;
  try {
    const res = await env.DB.prepare(
      `INSERT INTO bookings (token, name, email, phone, service, slot_start, duration_min, note, page_id, answers)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?) RETURNING *`
    ).bind(token, name, email, phone, service || (page ? page.name : ""), slot,
           settings.duration, note, page ? page.id : null, answers).all();
    booking = res.results[0];
  } catch (e) {
    return json({ error: "Could not save your request. Please try again." }, 500);
  }

  const when = formatSlot(slot, settings.timezone);
  const C = await getContent(env);
  const vars = { name, when, service: service || (page ? page.name : "") };

  // Notify admin.
  const to = env.BOOKING_TO || env.ADMIN_EMAIL;
  if (to) {
    const pairs = [
      ["Name", name], ["Email", email], ["Phone", phone || "\u2014"],
      ["Service", service || (page ? page.name : "\u2014")], ["Requested slot", when],
      ["Duration", settings.duration + " min"],
      ...(page && page.note_hidden ? [] : [[(page && page.note_label) || "Note", note || "\u2014"]]),
      ...(answers ? JSON.parse(answers).map((a) => [a.label, a.value]) : []),
    ];
    await sendEmail(env, {
      to,
      replyTo: email,
      subject: fill(C.email_bk_admin_subject, vars),
      html: emailShell(
        emailHeading(fill(C.email_bk_admin_heading, vars), fill(C.email_bk_admin_intro, vars))
        + detailsTable(pairs)
        + `<p style="margin:18px 0 0;font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;font-size:13px;color:#5a6b63;">${esc(fill(C.email_bk_admin_footnote, vars))}</p>`
      , env.SITE_URL),
    });
  }

  // Acknowledge to the visitor.
  await sendEmail(env, {
    to: email,
    replyTo: to || undefined,
    subject: fill(C.email_bk_ack_subject, vars),
    html: emailShell(
      emailHeading(fill(C.email_bk_ack_greeting, vars), fill(C.email_bk_ack_intro, vars))
      + `<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin:16px 0;"><tr><td style="background:#e8f2ec;border-left:4px solid #5a8a6a;border-radius:6px;padding:16px 18px;font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;font-size:17px;font-weight:bold;color:#3d6b52;">${esc(when)}</td></tr></table>`
      + `<p style="margin:0 0 14px;font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;font-size:15px;color:#1a2820;line-height:1.65;">${htmlText(C.email_bk_ack_body, vars)}</p>`
      + `<p style="margin:0;font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;font-size:14px;color:#5a6b63;">${htmlText(C.email_signoff, vars)}</p>`
    , env.SITE_URL),
  });

  return json({ ok: true, token: booking.token, when });
}
