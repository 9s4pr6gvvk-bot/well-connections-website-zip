import { json } from "../../shared/layout.js";

// POST /api/upload (multipart form-data, field "file") -> { url: "/media/<key>" }
// Requires an R2 binding named MEDIA. If absent, returns 501 so the admin can
// fall back to pasting an external image URL.
export async function onRequestPost(context) {
  const { request, env } = context;
  if (!env.MEDIA) {
    return json({ error: "Image upload is not configured. Paste an image URL instead, or add an R2 bucket bound as MEDIA." }, 501);
  }
  const form = await request.formData();
  const file = form.get("file");
  if (!file || typeof file === "string") return json({ error: "No file provided" }, 400);

  const type = file.type || "application/octet-stream";
  // Only allow raster image types. SVG is deliberately excluded: it is an XML
  // document that can carry <script>, so serving it inline from our own origin
  // would be a stored-XSS vector.
  const ALLOWED = ["image/jpeg", "image/png", "image/gif", "image/webp", "image/avif"];
  if (!ALLOWED.includes(type)) return json({ error: "Only JPEG, PNG, GIF, WebP or AVIF images are allowed" }, 400);
  if (file.size > 8 * 1024 * 1024) return json({ error: "Image must be under 8MB" }, 400);

  const safeName = (file.name || "image").toLowerCase().replace(/[^a-z0-9.\-]/g, "-");
  const key = `uploads/${Date.now()}-${safeName}`;
  await env.MEDIA.put(key, file.stream(), { httpMetadata: { contentType: type } });

  return json({ url: `/media/${key}` }, 201);
}
