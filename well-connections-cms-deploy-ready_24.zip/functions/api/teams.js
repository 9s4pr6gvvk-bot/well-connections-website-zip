import { json } from "../../shared/layout.js";
import { slugify } from "../../shared/markdown.js";

async function uniqueSlug(env, base, excludeId) {
  let slug = slugify(base) || "team";
  let n = 1;
  while (true) {
    const row = await env.DB.prepare("SELECT id FROM teams WHERE slug=?").bind(slug).first();
    if (!row || (excludeId && row.id === excludeId)) return slug;
    n++; slug = `${slugify(base)}-${n}`;
  }
}

// GET /api/teams -> admin: all; public: published only
export async function onRequestGet(context) {
  const { env, data } = context;
  const isAdmin = !!data.session;
  const sql = isAdmin
    ? "SELECT * FROM teams ORDER BY sort_order ASC, name ASC"
    : "SELECT * FROM teams WHERE status='published' ORDER BY sort_order ASC, name ASC";
  const { results } = await env.DB.prepare(sql).all();
  return json(results || []);
}

export async function onRequestPost(context) {
  const { request, env } = context;
  let b;
  try { b = await request.json(); } catch { return json({ error: "Bad request" }, 400); }
  const name = (b.name || "").trim();
  if (!name) return json({ error: "Team name is required" }, 400);
  const slug = await uniqueSlug(env, b.slug || name);
  const status = b.status === "draft" ? "draft" : "published";
  const sort = Number.isFinite(+b.sort_order) ? +b.sort_order : 0;

  const { results } = await env.DB.prepare(
    `INSERT INTO teams (name, slug, tagline, sort_order, status) VALUES (?, ?, ?, ?, ?) RETURNING *`
  ).bind(name, slug, b.tagline || "", sort, status).all();
  return json(results[0], 201);
}
