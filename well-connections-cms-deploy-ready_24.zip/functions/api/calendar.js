import { json } from "../../shared/layout.js";
import { getSettings, formatSlot } from "../../shared/availability.js";
import { getCalendarConfig, saveCalendarConfig, normaliseIcsUrl, getBusy } from "../../shared/calendar.js";

// Outlook calendar sync settings. Admin only (the middleware gates every write;
// GET checks the session here because the link is private).
//
// GET  /api/calendar  -> current link, on/off, and the state of the last sync
// PUT  /api/calendar  -> { url, enabled } save, then sync straight away
// POST /api/calendar  -> sync now

export async function onRequestGet(context) {
  const { env, data } = context;
  if (!data.session) return json({ error: "Not authenticated" }, 401);
  return json(await status(env, false));
}

export async function onRequestPut(context) {
  const { env, request, data } = context;
  if (!data.session) return json({ error: "Not authenticated" }, 401);
  let b;
  try { b = await request.json(); } catch { return json({ error: "Bad request" }, 400); }

  const update = {};
  if ("url" in b) {
    const url = normaliseIcsUrl(b.url);
    if (url === null) return json({ error: "That isn't a valid https calendar link." }, 400);
    const current = await getCalendarConfig(env);
    if (url !== current.url) update.url = url;
  }
  if ("enabled" in b) update.enabled = !!b.enabled;
  await saveCalendarConfig(env, update);
  return json(await status(env, true));
}

export async function onRequestPost(context) {
  const { env, data } = context;
  if (!data.session) return json({ error: "Not authenticated" }, 401);
  return json(await status(env, true));
}

async function status(env, force) {
  const cfg = await getCalendarConfig(env);
  const raw = await env.DB.prepare(
    "SELECT key, value FROM app_settings WHERE key IN ('calendar_ics_url','calendar_sync_enabled')"
  ).all().catch(() => ({ results: [] }));
  const kv = {};
  for (const r of raw.results || []) kv[r.key] = r.value;

  const out = {
    url: kv.calendar_ics_url || "",
    enabled: kv.calendar_sync_enabled === "1",
    active: cfg.enabled,
    fetched_at: 0,
    error: "",
    stale: false,
    busy_blocks: 0,
    upcoming: [],
  };
  if (!cfg.enabled) return out;

  const s = await getSettings(env);
  const busy = await getBusy(env, { force, fallbackTz: s.timezone });
  const now = Date.now();
  const future = busy.intervals.filter((iv) => iv[1] > now);
  out.fetched_at = busy.fetchedAt || 0;
  out.error = busy.error || "";
  out.stale = !!busy.stale;
  out.busy_blocks = future.filter((iv) => iv[0] < now + s.horizon * 86400000).length;
  // A few upcoming blocks so Sam can check them against Outlook.
  out.upcoming = future.slice(0, 6).map(([a, b]) => {
    const iso = (ms) => new Date(ms).toISOString().slice(0, 16);
    const startLabel = formatSlot(iso(a), s.timezone);
    const endLabel = formatSlot(iso(b), s.timezone);
    const sameDay = startLabel.split(", ")[0] === endLabel.split(", ")[0];
    return sameDay ? `${startLabel} to ${endLabel.split(", ").pop()}` : `${startLabel} to ${endLabel}`;
  });
  return out;
}
