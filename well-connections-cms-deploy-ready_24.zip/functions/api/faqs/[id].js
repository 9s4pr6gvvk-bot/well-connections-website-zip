import { json } from "../../../shared/layout.js";

export async function onRequestGet(context) {
  const { env, params, data } = context;
  const row = await env.DB.prepare("SELECT * FROM faqs WHERE id=?").bind(params.id).first();
  if (!row) return json({ error: "Not found" }, 404);
  if (row.status !== "published" && !data.session) return json({ error: "Not found" }, 404);
  return json(row);
}

export async function onRequestPut(context) {
  const { request, env, params } = context;
  const id = Number(params.id);
  let b;
  try { b = await request.json(); } catch { return json({ error: "Bad request" }, 400); }
  const existing = await env.DB.prepare("SELECT * FROM faqs WHERE id=?").bind(id).first();
  if (!existing) return json({ error: "Not found" }, 404);
  const question = ("question" in b ? b.question : existing.question || "").trim();
  const answer = ("answer" in b ? b.answer : existing.answer || "").trim();
  if (!question) return json({ error: "Question is required" }, 400);
  if (!answer) return json({ error: "Answer is required" }, 400);
  const status = ("status" in b ? b.status : existing.status) === "draft" ? "draft" : "published";
  const sort = "sort_order" in b ? (+b.sort_order || 0) : existing.sort_order;
  const { results } = await env.DB.prepare(
    `UPDATE faqs SET question=?, answer=?, status=?, sort_order=?, updated_at=datetime('now') WHERE id=? RETURNING *`
  ).bind(question, answer, status, sort, id).all();
  return json(results[0]);
}

export async function onRequestDelete(context) {
  const { env, params } = context;
  await env.DB.prepare("DELETE FROM faqs WHERE id=?").bind(params.id).run();
  return json({ ok: true });
}
