import { json } from "../../../shared/layout.js";

const FIELDS = ["name", "role", "credentials", "photo_url", "profile_url", "teams", "bio", "enquiry_email", "accepting", "status", "sort_order"];

function packTeams(v) {
  let arr = [];
  if (Array.isArray(v)) arr = v;
  else if (typeof v === "string") arr = v.split(/[|,]/);
  arr = arr.map((s) => String(s).trim()).filter(Boolean);
  return arr.length ? "|" + arr.join("|") + "|" : "";
}

export async function onRequestGet(context) {
  const { env, params, data } = context;
  const row = await env.DB.prepare("SELECT * FROM therapists WHERE id=?").bind(params.id).first();
  if (!row) return json({ error: "Not found" }, 404);
  if (row.status !== "published" && !data.session) return json({ error: "Not found" }, 404);
  if (!data.session) {
    // enquiry_email is an internal routing address: never serve it publicly.
    const { enquiry_email, ...rest } = row;
    return json(rest);
  }
  return json(row);
}

export async function onRequestPut(context) {
  const { request, env, params } = context;
  let body;
  try { body = await request.json(); } catch { return json({ error: "Bad request" }, 400); }

  const existing = await env.DB.prepare("SELECT * FROM therapists WHERE id=?").bind(params.id).first();
  if (!existing) return json({ error: "Not found" }, 404);

  const t = { ...existing };
  for (const f of FIELDS) if (f in body) t[f] = body[f];
  t.name = (t.name || "").trim();
  if (!t.name) return json({ error: "Name is required" }, 400);
  t.enquiry_email = (t.enquiry_email || "").toString().trim().slice(0, 200);
  t.teams = packTeams(t.teams);
  t.accepting = t.accepting ? 1 : 0;
  t.status = t.status === "draft" ? "draft" : "published";
  t.sort_order = Number.isFinite(+t.sort_order) ? +t.sort_order : 0;

  const { results } = await env.DB.prepare(
    `UPDATE therapists SET name=?, role=?, credentials=?, photo_url=?, profile_url=?, teams=?, bio=?,
      enquiry_email=?, accepting=?, status=?, sort_order=?, updated_at=datetime('now') WHERE id=? RETURNING *`
  ).bind(t.name, t.role || "", t.credentials || "", t.photo_url || "", t.profile_url || "",
         t.teams || "", t.bio || "", t.enquiry_email || "", t.accepting, t.status, t.sort_order, params.id).all();

  return json(results[0]);
}

export async function onRequestDelete(context) {
  const { env, params } = context;
  await env.DB.prepare("DELETE FROM therapists WHERE id=?").bind(params.id).run();
  return json({ ok: true });
}
