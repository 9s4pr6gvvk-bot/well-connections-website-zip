import { json } from "../../../shared/layout.js";
import { slugify } from "../../../shared/markdown.js";

async function uniqueSlug(env, base, excludeId) {
  let slug = slugify(base) || "team";
  let n = 1;
  while (true) {
    const row = await env.DB.prepare("SELECT id FROM teams WHERE slug=?").bind(slug).first();
    if (!row || row.id === excludeId) return slug;
    n++; slug = `${slugify(base)}-${n}`;
  }
}

export async function onRequestGet(context) {
  const { env, params, data } = context;
  const row = await env.DB.prepare("SELECT * FROM teams WHERE id=?").bind(params.id).first();
  if (!row) return json({ error: "Not found" }, 404);
  if (row.status !== "published" && !data.session) return json({ error: "Not found" }, 404);
  return json(row);
}

export async function onRequestPut(context) {
  const { request, env, params } = context;
  const id = Number(params.id);
  let b;
  try { b = await request.json(); } catch { return json({ error: "Bad request" }, 400); }
  const existing = await env.DB.prepare("SELECT * FROM teams WHERE id=?").bind(id).first();
  if (!existing) return json({ error: "Not found" }, 404);

  const name = ("name" in b ? b.name : existing.name || "").trim();
  if (!name) return json({ error: "Team name is required" }, 400);
  // Keep the existing slug on edit. Only change it if an explicit, non-empty
  // slug is sent (so editing a team's name or sort order never breaks its URL
  // or its link to therapists).
  const slug = ("slug" in b && String(b.slug).trim())
    ? await uniqueSlug(env, b.slug, id)
    : existing.slug;
  const tagline = "tagline" in b ? b.tagline : existing.tagline;
  const status = ("status" in b ? b.status : existing.status) === "draft" ? "draft" : "published";
  const sort = "sort_order" in b ? (+b.sort_order || 0) : existing.sort_order;

  const { results } = await env.DB.prepare(
    `UPDATE teams SET name=?, slug=?, tagline=?, sort_order=?, status=?, updated_at=datetime('now')
     WHERE id=? RETURNING *`
  ).bind(name, slug, tagline || "", sort, status, id).all();
  return json(results[0]);
}

export async function onRequestDelete(context) {
  const { env, params } = context;
  await env.DB.prepare("DELETE FROM teams WHERE id=?").bind(params.id).run();
  return json({ ok: true });
}
