import { json } from "../../shared/layout.js";

// Booking availability settings. Keys are booking_* in app_settings.
// GET /api/settings  -> admin reads current values (with defaults filled in)
// PUT /api/settings  -> admin saves { booking_days, booking_start, ... }
const KEYS = [
  "booking_days", "booking_start", "booking_end", "booking_duration",
  "booking_buffer", "booking_lead_hours", "booking_horizon", "booking_timezone",
];
const DEFAULTS = {
  booking_days: "1,2,3,4,5",
  booking_start: "09:00",
  booking_end: "17:00",
  booking_duration: "30",
  booking_buffer: "0",
  booking_lead_hours: "24",
  booking_horizon: "21",
  booking_timezone: "Europe/London",
};

export async function onRequestGet(context) {
  const { env, data } = context;
  if (!data.session) return json({ error: "Not authenticated" }, 401);
  const out = { ...DEFAULTS };
  try {
    const { results } = await env.DB.prepare(
      "SELECT key, value FROM app_settings WHERE key LIKE 'booking_%'"
    ).all();
    for (const r of results || []) out[r.key] = r.value;
  } catch {
    return json({ error: "Settings table not set up yet. Run the bookings migration." }, 500);
  }
  return json(out);
}

export async function onRequestPut(context) {
  const { request, env, data } = context;
  if (!data.session) return json({ error: "Not authenticated" }, 401);
  let b;
  try { b = await request.json(); } catch { return json({ error: "Bad request" }, 400); }

  // Light validation.
  const clean = {};
  if ("booking_days" in b) {
    const days = String(b.booking_days).split(",").map((s) => parseInt(s, 10)).filter((n) => n >= 0 && n <= 6);
    clean.booking_days = [...new Set(days)].sort().join(",");
  }
  if ("booking_start" in b) clean.booking_start = normTime(b.booking_start, "09:00");
  if ("booking_end" in b) clean.booking_end = normTime(b.booking_end, "17:00");
  if ("booking_duration" in b) clean.booking_duration = String(clampInt(b.booking_duration, 5, 480, 30));
  if ("booking_buffer" in b) clean.booking_buffer = String(clampInt(b.booking_buffer, 0, 240, 0));
  if ("booking_lead_hours" in b) clean.booking_lead_hours = String(clampInt(b.booking_lead_hours, 0, 720, 24));
  if ("booking_horizon" in b) clean.booking_horizon = String(clampInt(b.booking_horizon, 1, 120, 21));
  if ("booking_timezone" in b) clean.booking_timezone = String(b.booking_timezone).slice(0, 60) || "Europe/London";

  for (const key of Object.keys(clean)) {
    if (!KEYS.includes(key)) continue;
    await env.DB.prepare(
      `INSERT INTO app_settings (key, value, updated_at) VALUES (?, ?, datetime('now'))
       ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=datetime('now')`
    ).bind(key, clean[key]).run();
  }

  const out = { ...DEFAULTS };
  const { results } = await env.DB.prepare(
    "SELECT key, value FROM app_settings WHERE key LIKE 'booking_%'"
  ).all();
  for (const r of results || []) out[r.key] = r.value;
  return json(out);
}

function clampInt(v, min, max, dflt) {
  const n = parseInt(v, 10);
  if (isNaN(n)) return dflt;
  return Math.min(max, Math.max(min, n));
}
function normTime(v, dflt) {
  const m = String(v).match(/^(\d{1,2}):(\d{2})$/);
  if (!m) return dflt;
  const h = Math.min(23, Math.max(0, +m[1]));
  const mi = Math.min(59, Math.max(0, +m[2]));
  return `${String(h).padStart(2, "0")}:${String(mi).padStart(2, "0")}`;
}
