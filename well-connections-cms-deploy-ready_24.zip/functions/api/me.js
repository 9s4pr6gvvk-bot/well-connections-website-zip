import { json } from "../../shared/layout.js";

// Lets the admin app know whether the current cookie is valid.
export async function onRequestGet(context) {
  const session = context.data.session;
  return json({ authenticated: !!session });
}
