import { json } from "../../shared/layout.js";
import { cleanLogo } from "../../shared/logos.js";

// GET  /api/logos  -> published logos/labels (public); everything for admins
// POST /api/logos  -> create (admin only, enforced in _middleware)
export async function onRequestGet(context) {
  const { env, data } = context;
  const sql = data.session
    ? "SELECT * FROM logos ORDER BY sort_order ASC, id ASC"
    : "SELECT id, kind, name, image_url, pages, sort_order FROM logos WHERE status='published' ORDER BY sort_order ASC, id ASC";
  try {
    const { results } = await env.DB.prepare(sql).all();
    return json(results || []);
  } catch {
    // Table not created yet: the public site simply shows no logos.
    return data.session ? json({ error: "Logos table not set up yet" }, 500) : json([]);
  }
}

export async function onRequestPost(context) {
  const { request, env } = context;
  let b;
  try { b = await request.json(); } catch { return json({ error: "Bad request" }, 400); }
  const c = cleanLogo(b);
  if (c.error) return json({ error: c.error }, 400);
  const { results } = await env.DB.prepare(
    "INSERT INTO logos (kind, name, image_url, pages, status, sort_order) VALUES (?, ?, ?, ?, ?, ?) RETURNING *"
  ).bind(c.kind, c.name, c.image_url, c.pages, c.status, c.sort_order).all();
  return json(results[0], 201);
}
