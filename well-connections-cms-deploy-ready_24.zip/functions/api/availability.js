import { json } from "../../shared/layout.js";
import { getSettings, getPageSettings, computeAvailability } from "../../shared/availability.js";

// GET /api/availability             -> global availability (unchanged behaviour)
// GET /api/availability?page=<slug> -> availability for one booking page, using
//                                      that page's own rules where they are set.
export async function onRequestGet(context) {
  const { env, request } = context;
  const url = new URL(request.url);
  const slug = (url.searchParams.get("page") || "").trim();

  let settings;
  let page = null;

  if (slug) {
    try {
      page = await env.DB.prepare(
        "SELECT * FROM booking_pages WHERE slug=? AND status='published'"
      ).bind(slug).first();
    } catch {
      page = null; // table not migrated yet
    }
    if (!page) return json({ error: "Booking page not found" }, 404);
    settings = await getPageSettings(env, page);
  } else {
    settings = await getSettings(env);
  }

  const days = await computeAvailability(env, settings);

  return json({
    duration: settings.duration,
    timezone: settings.timezone,
    days,
    ...(page ? { page: { slug: page.slug, name: page.name } } : {}),
  });
}
