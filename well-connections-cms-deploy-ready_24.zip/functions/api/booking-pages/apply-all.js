import { json } from "../../../shared/layout.js";

// POST /api/booking-pages/apply-all  (admin)
//
// Blanket availability. The Availability tab holds one set of rules; each
// booking page may override any of them, which is how the discovery call ended
// up on a different session length from Arthritis UK. This clears the chosen
// overrides on every booking page so they all follow the blanket settings, and
// keep following them whenever those settings change.
//
// Body: { fields: ["days","time_start","time_end","duration_min","buffer_min",
//                  "lead_hours","horizon_days","timezone"],
//         slugs: ["arthritis-uk", ...] }     // optional, defaults to every page
//
// Clearing a column is what makes a page inherit, so nothing is copied and
// there is no second copy of the rules to drift out of step.

// Columns a page may override, with the Availability setting each one shadows.
const OVERRIDES = {
  days: "booking_days",
  time_start: "booking_start",
  time_end: "booking_end",
  duration_min: "booking_duration",
  buffer_min: "booking_buffer",
  lead_hours: "booking_lead_hours",
  horizon_days: "booking_horizon",
  timezone: "booking_timezone",
};

export async function onRequestPost(context) {
  const { request, env, data } = context;
  if (!data.session) return json({ error: "Not authenticated" }, 401);

  let b;
  try { b = await request.json(); } catch { return json({ error: "Bad request" }, 400); }

  const fields = Array.isArray(b.fields)
    ? b.fields.filter((f) => Object.prototype.hasOwnProperty.call(OVERRIDES, f))
    : Object.keys(OVERRIDES);
  if (!fields.length) return json({ error: "Pick at least one setting to apply." }, 400);

  const slugs = Array.isArray(b.slugs)
    ? b.slugs.map((s) => String(s).trim()).filter(Boolean).slice(0, 200)
    : null;

  let pages;
  try {
    pages = (await env.DB.prepare("SELECT * FROM booking_pages").all()).results || [];
  } catch {
    return json({ error: "Booking pages table not set up yet. Run the booking-pages migration." }, 500);
  }

  const targets = slugs ? pages.filter((p) => slugs.includes(p.slug)) : pages;
  if (!targets.length) return json({ error: "No matching booking pages." }, 400);

  // Record what was overridden before, so the dashboard can report the change
  // and so there is a trail of what this cleared.
  const cleared = targets.map((p) => ({
    slug: p.slug,
    name: p.name,
    had: fields.filter((f) => p[f] !== null && p[f] !== undefined && String(p[f]).trim() !== ""),
  }));

  const setSql = fields.map((f) => `${f}=NULL`).join(", ");
  const ids = targets.map((p) => p.id);
  const placeholders = ids.map(() => "?").join(",");
  await env.DB.prepare(
    `UPDATE booking_pages SET ${setSql}, updated_at=datetime('now') WHERE id IN (${placeholders})`
  ).bind(...ids).run();

  const after = (await env.DB.prepare("SELECT * FROM booking_pages ORDER BY name ASC").all()).results || [];

  return json({
    ok: true,
    applied: fields,
    pages: targets.length,
    changed: cleared.filter((c) => c.had.length).length,
    detail: cleared,
    booking_pages: after,
  });
}
