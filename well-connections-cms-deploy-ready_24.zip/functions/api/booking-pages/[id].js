import { json } from "../../../shared/layout.js";

function slugify(s) {
  return (s || "")
    .toLowerCase()
    .replace(/&/g, " and ")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60);
}

function cleanQuestions(input) {
  if (!Array.isArray(input)) return null;
  const out = input
    .filter((q) => q && typeof q.label === "string" && q.label.trim())
    .slice(0, 20)
    .map((q) => ({
      label: String(q.label).trim().slice(0, 160),
      type: ["text", "textarea", "select", "email", "tel"].includes(q.type) ? q.type : "text",
      required: q.required ? 1 : 0,
      options: Array.isArray(q.options)
        ? q.options.map((o) => String(o).trim()).filter(Boolean).slice(0, 20)
        : [],
    }));
  return JSON.stringify(out);
}

function orNull(v) {
  if (v === undefined || v === null) return null;
  const s = String(v).trim();
  if (!s) return null;
  const n = parseInt(s, 10);
  return Number.isFinite(n) ? n : null;
}
function strOrNull(v) {
  if (v === undefined || v === null) return null;
  const s = String(v).trim();
  return s || null;
}
function pick(b, key, existing, fn) {
  return key in b ? fn(b[key]) : existing;
}

export async function onRequestGet(context) {
  const { env, params, data } = context;
  const row = await env.DB.prepare("SELECT * FROM booking_pages WHERE id=?").bind(params.id).first();
  if (!row) return json({ error: "Not found" }, 404);
  if (row.status !== "published" && !data.session) return json({ error: "Not found" }, 404);
  return json(row);
}

export async function onRequestPut(context) {
  const { request, env, params } = context;
  const id = Number(params.id);
  let b;
  try { b = await request.json(); } catch { return json({ error: "Bad request" }, 400); }

  const ex = await env.DB.prepare("SELECT * FROM booking_pages WHERE id=?").bind(id).first();
  if (!ex) return json({ error: "Not found" }, 404);

  const name = ("name" in b ? b.name : ex.name || "").trim();
  if (!name) return json({ error: "Name is required" }, 400);

  // Keep the existing address unless one is explicitly changed, so links stay alive.
  let slug = ex.slug;
  if ("slug" in b && slugify(b.slug) && slugify(b.slug) !== ex.slug) {
    slug = slugify(b.slug);
    const base = slug;
    for (let i = 2; i < 50; i++) {
      const clash = await env.DB.prepare(
        "SELECT id FROM booking_pages WHERE slug=? AND id<>?"
      ).bind(slug, id).first();
      if (!clash) break;
      slug = `${base}-${i}`;
    }
  }

  const questions = "questions" in b ? (cleanQuestions(b.questions) ?? ex.questions) : ex.questions;

  const { results } = await env.DB.prepare(
    `UPDATE booking_pages SET
       name=?, slug=?, kind=?, organisation=?, intro=?, confirm_note=?,
       duration_min=?, buffer_min=?, days=?, time_start=?, time_end=?,
       lead_hours=?, horizon_days=?, timezone=?, questions=?,
       notes=?, notify_email=?, listed=?, status=?, sort_order=?,
       phone_required=?, note_label=?, note_hidden=?,
       updated_at=datetime('now')
     WHERE id=? RETURNING *`
  ).bind(
    name, slug,
    ("kind" in b ? b.kind : ex.kind) === "general" ? "general" : "organisation",
    pick(b, "organisation", ex.organisation || "", (v) => String(v).trim()),
    pick(b, "intro", ex.intro || "", (v) => String(v).trim()),
    pick(b, "confirm_note", ex.confirm_note || "", (v) => String(v).trim()),
    pick(b, "duration_min", ex.duration_min, orNull),
    pick(b, "buffer_min", ex.buffer_min, orNull),
    pick(b, "days", ex.days, strOrNull),
    pick(b, "time_start", ex.time_start, strOrNull),
    pick(b, "time_end", ex.time_end, strOrNull),
    pick(b, "lead_hours", ex.lead_hours, orNull),
    pick(b, "horizon_days", ex.horizon_days, orNull),
    pick(b, "timezone", ex.timezone, strOrNull),
    questions,
    pick(b, "notes", ex.notes || "", (v) => String(v).trim()),
    pick(b, "notify_email", ex.notify_email || "", (v) => String(v).trim()),
    "listed" in b ? (b.listed ? 1 : 0) : ex.listed,
    ("status" in b ? b.status : ex.status) === "draft" ? "draft" : "published",
    "sort_order" in b ? (+b.sort_order || 0) : ex.sort_order,
    "phone_required" in b ? (b.phone_required ? 1 : 0) : (ex.phone_required || 0),
    pick(b, "note_label", ex.note_label || "", (v) => String(v).trim().slice(0, 400)),
    "note_hidden" in b ? (b.note_hidden ? 1 : 0) : (ex.note_hidden || 0),
    id
  ).all();

  return json(results[0]);
}

export async function onRequestDelete(context) {
  const { env, params } = context;
  await env.DB.prepare("DELETE FROM booking_pages WHERE id=?").bind(params.id).run();
  return json({ ok: true });
}
