import { json } from "../../../shared/layout.js";
import { slugify } from "../../../shared/markdown.js";

async function uniqueSlug(env, base, excludeId) {
  let slug = slugify(base) || "post";
  let n = 1;
  while (true) {
    const row = await env.DB.prepare("SELECT id FROM posts WHERE slug=?").bind(slug).first();
    if (!row || row.id === excludeId) return slug;
    n++; slug = `${slugify(base)}-${n}`;
  }
}

export async function onRequestGet(context) {
  const { env, params, data } = context;
  const row = await env.DB.prepare("SELECT * FROM posts WHERE id=?").bind(params.id).first();
  if (!row) return json({ error: "Not found" }, 404);
  if (row.status !== "published" && !data.session) return json({ error: "Not found" }, 404);
  return json(row);
}

export async function onRequestPut(context) {
  const { request, env, params } = context;
  const id = Number(params.id);
  let b;
  try { b = await request.json(); } catch { return json({ error: "Bad request" }, 400); }

  const existing = await env.DB.prepare("SELECT * FROM posts WHERE id=?").bind(id).first();
  if (!existing) return json({ error: "Not found" }, 404);

  const title = ("title" in b ? b.title : existing.title || "").trim();
  if (!title) return json({ error: "Title is required" }, 400);

  const slugBase = b.slug || title;
  const slug = await uniqueSlug(env, slugBase, id);
  const status = ("status" in b ? b.status : existing.status) === "published" ? "published" : "draft";
  // Set published_at the first time it goes live; keep existing thereafter.
  let publishedAt = existing.published_at;
  if (status === "published" && !publishedAt) publishedAt = new Date().toISOString();
  if (status !== "published") publishedAt = null;

  const merged = {
    excerpt: "excerpt" in b ? b.excerpt : existing.excerpt,
    body: "body" in b ? b.body : existing.body,
    cover_url: "cover_url" in b ? b.cover_url : existing.cover_url,
    author: "author" in b ? b.author : existing.author,
  };

  const { results } = await env.DB.prepare(
    `UPDATE posts SET title=?, slug=?, excerpt=?, body=?, cover_url=?, author=?, status=?,
      published_at=?, updated_at=datetime('now') WHERE id=? RETURNING *`
  ).bind(title, slug, merged.excerpt || "", merged.body || "", merged.cover_url || "",
         merged.author || "", status, publishedAt, id).all();

  return json(results[0]);
}

export async function onRequestDelete(context) {
  const { env, params } = context;
  await env.DB.prepare("DELETE FROM posts WHERE id=?").bind(params.id).run();
  return json({ ok: true });
}
