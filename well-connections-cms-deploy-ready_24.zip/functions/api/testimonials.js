import { json } from "../../shared/layout.js";

export async function onRequestGet(context) {
  const { env, data } = context;
  const isAdmin = !!data.session;
  const sql = isAdmin
    ? "SELECT * FROM testimonials ORDER BY sort_order ASC, id DESC"
    : "SELECT * FROM testimonials WHERE status='published' ORDER BY sort_order ASC, id DESC";
  const { results } = await env.DB.prepare(sql).all();
  return json(results || []);
}

export async function onRequestPost(context) {
  const { request, env } = context;
  let b;
  try { b = await request.json(); } catch { return json({ error: "Bad request" }, 400); }
  const quote = (b.quote || "").trim();
  if (!quote) return json({ error: "Quote is required" }, 400);
  const status = b.status === "draft" ? "draft" : "published";
  const sort = Number.isFinite(+b.sort_order) ? +b.sort_order : 0;
  const { results } = await env.DB.prepare(
    `INSERT INTO testimonials (quote, author, detail, status, sort_order) VALUES (?, ?, ?, ?, ?) RETURNING *`
  ).bind(quote, b.author || "", b.detail || "", status, sort).all();
  return json(results[0], 201);
}
