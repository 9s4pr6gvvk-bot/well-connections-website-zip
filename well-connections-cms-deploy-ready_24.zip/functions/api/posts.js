import { json } from "../../shared/layout.js";
import { slugify } from "../../shared/markdown.js";

async function uniqueSlug(env, base, excludeId) {
  let slug = slugify(base) || "post";
  let n = 1;
  while (true) {
    const row = await env.DB.prepare("SELECT id FROM posts WHERE slug=?").bind(slug).first();
    if (!row || (excludeId && row.id === excludeId)) return slug;
    n++; slug = `${slugify(base)}-${n}`;
  }
}

// GET /api/posts -> admin: all; public: published only
export async function onRequestGet(context) {
  const { env, data } = context;
  const isAdmin = !!data.session;
  const sql = isAdmin
    ? "SELECT * FROM posts ORDER BY COALESCE(published_at, created_at) DESC"
    : "SELECT * FROM posts WHERE status='published' ORDER BY published_at DESC";
  const { results } = await env.DB.prepare(sql).all();
  return json(results || []);
}

// POST /api/posts
export async function onRequestPost(context) {
  const { request, env } = context;
  let b;
  try { b = await request.json(); } catch { return json({ error: "Bad request" }, 400); }
  const title = (b.title || "").trim();
  if (!title) return json({ error: "Title is required" }, 400);

  const slug = await uniqueSlug(env, b.slug || title);
  const status = b.status === "published" ? "published" : "draft";
  const publishedAt = status === "published" ? (b.published_at || new Date().toISOString()) : null;

  const { results } = await env.DB.prepare(
    `INSERT INTO posts (title, slug, excerpt, body, cover_url, author, status, published_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?) RETURNING *`
  ).bind(title, slug, b.excerpt || "", b.body || "", b.cover_url || "", b.author || "", status, publishedAt).all();

  return json(results[0], 201);
}
