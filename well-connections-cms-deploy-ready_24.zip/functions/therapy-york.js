import { locationPage } from "../shared/locations.js";
export const onRequestGet = () => locationPage("therapy-york");
