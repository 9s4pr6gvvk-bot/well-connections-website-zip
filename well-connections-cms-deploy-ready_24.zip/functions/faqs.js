import { layout } from "../shared/layout.js";
import { escapeHtml } from "../shared/markdown.js";

// /faqs -> CMS-editable FAQ accordions
export async function onRequestGet(context) {
  const { env } = context;
  const faqs = (await env.DB.prepare(
    "SELECT * FROM faqs WHERE status='published' ORDER BY sort_order ASC, id ASC"
  ).all()).results || [];

  const items = faqs.map((f, i) => `
    <div class="faq-item">
      <button class="faq-q" aria-expanded="false" aria-controls="faq-a-${i}" id="faq-q-${i}">
        <span>${escapeHtml(f.question)}</span>
        <svg class="faq-chev" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="6 9 12 15 18 9"/></svg>
      </button>
      <div class="faq-a" id="faq-a-${i}" role="region" aria-labelledby="faq-q-${i}">
        <div class="faq-a-inner"><p>${escapeHtml(f.answer)}</p></div>
      </div>
    </div>`).join("");

  const body = `
  <header class="page-head">
    <span class="label">Frequently Asked Questions</span>
    <h1>Answers for organisations<br /><em>and individuals.</em></h1>
    <p>How we work, how support begins, and what to expect. If your question isn't here, get in touch and we'll be glad to help.</p>
  </header>
  <main class="wrap faq-wrap">
    ${faqs.length ? `<div class="faq-list">${items}</div>` : `<p style="text-align:center;color:var(--text-muted)">FAQs are being added.</p>`}
    <div class="faq-cta">
      <p>Still have a question?</p>
      <a href="/#contact" class="faq-cta-btn">Contact us</a>
      <a href="/#book" class="faq-cta-btn faq-cta-alt">Book a discovery call</a>
    </div>
  </main>
  <style>
    .faq-wrap{max-width:840px}
    .faq-list{display:flex;flex-direction:column;gap:0.75rem}
    .faq-item{border:1px solid var(--stone);border-radius:8px;background:#fff;overflow:hidden}
    .faq-q{width:100%;display:flex;align-items:center;justify-content:space-between;gap:1rem;text-align:left;background:none;border:none;cursor:pointer;padding:1.15rem 1.35rem;font-family:'Quicksand',sans-serif;font-size:1rem;font-weight:400;color:var(--bark-dark);line-height:1.5}
    .faq-q:hover{color:var(--teal)}
    .faq-chev{flex-shrink:0;color:var(--sage-dark);transition:transform .25s ease}
    .faq-item.open .faq-chev{transform:rotate(180deg)}
    .faq-a{max-height:0;overflow:hidden;transition:max-height .28s ease}
    .faq-a-inner{padding:0 1.35rem 1.25rem}
    .faq-a-inner p{font-size:0.94rem;color:var(--text-muted);line-height:1.7}
    .faq-cta{margin-top:3rem;text-align:center;padding:2.5rem 1.5rem;background:var(--cream);border:1px solid var(--stone);border-radius:10px}
    .faq-cta p{font-family:'League Spartan',sans-serif;font-size:1.5rem;color:var(--bark-dark);margin-bottom:1.25rem}
    .faq-cta-btn{display:inline-block;background:var(--sage);color:#fff!important;text-decoration:none;padding:0.8rem 1.6rem;border-radius:2px;font-size:0.88rem;letter-spacing:0.04em;font-weight:500;margin:0 0.35rem 0.5rem;transition:background .2s}
    .faq-cta-btn:hover{background:var(--sage-dark)}
    .faq-cta-alt{background:transparent;color:var(--teal)!important;border:1px solid var(--sage-light)}
    .faq-cta-alt:hover{background:var(--sage-pale)}
  </style>
  <script>
  (function(){
    document.querySelectorAll('.faq-q').forEach(function(btn){
      btn.addEventListener('click', function(){
        var item = btn.closest('.faq-item');
        var panel = item.querySelector('.faq-a');
        var isOpen = item.classList.contains('open');
        if (isOpen){
          item.classList.remove('open');
          btn.setAttribute('aria-expanded','false');
          panel.style.maxHeight = '0px';
        } else {
          item.classList.add('open');
          btn.setAttribute('aria-expanded','true');
          panel.style.maxHeight = panel.scrollHeight + 'px';
        }
      });
    });
  })();
  </script>`;

  const faqJsonLd = faqs.length ? {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "@id": "https://wellconnections.co.uk/faqs#faqpage",
    "mainEntity": faqs.map((f) => ({
      "@type": "Question",
      "name": f.question,
      "acceptedAnswer": { "@type": "Answer", "text": f.answer },
    })),
  } : undefined;

  return new Response(
    layout({
      title: "FAQs: Mental Health & Wellbeing Support | Well Connections",
      description: "Answers to common questions about Well Connections' mental health and wellbeing support for organisations and individuals.",
      body,
      canonical: "/faqs",
      jsonLd: faqJsonLd,
    }),
    { headers: { "Content-Type": "text/html; charset=utf-8" } }
  );
}
