import { layout } from "../shared/layout.js";
import { escapeHtml, markdownToHtml } from "../shared/markdown.js";
const DEFAULT_PRIVACY = `This notice explains how Well Connections Ltd collects, uses, stores and shares personal information when providing referral, counselling, therapy, coaching, training and wellbeing services, and when you use this website.

## 1. Who we are

Well Connections Ltd provides mental health and wellbeing referral, counselling, therapy, coaching, training and consultancy services.

We are registered with the Information Commissioner's Office under registration number ZB782600.

**Contact details**

- Email: info@wellconnections.co.uk
- Telephone: 07736 317617
- Website: www.wellconnections.co.uk

For the purposes of data protection law, Well Connections Ltd is generally the Data Controller of the personal information it collects and uses.

In some circumstances, such as when we deliver services on behalf of a school, charity, employer or other organisation, we may process some personal information on that organisation's behalf. Additional privacy information may apply to these services.

## 2. Who this Privacy Notice applies to

This Privacy Notice applies to anyone who interacts with Well Connections, including:

- Clients and individuals seeking support.
- Children, young people, parents and guardians.
- People referred by schools, employers, charities or other organisations.
- Practitioners and associates working with Well Connections.
- Representatives of organisations using our services.
- Visitors to our website.

We may provide additional privacy information where a specific service handles information differently.

## 3. Information we collect

We collect personal information relevant to the services we provide and to running this website.

**Information you give us**

- Names, ages, dates of birth and contact details.
- Parent, guardian or emergency contact information.
- Referral and appointment information.
- Information about mental health, emotional wellbeing and physical health.
- Personal, family, educational, employment or relationship circumstances.
- Safeguarding, welfare or risk-related information.
- Disability, accessibility or special educational needs information.
- Clinical or professional records.
- Assessment or outcome-measure information.
- Communications, feedback or complaints.
- Payment, invoicing and contract information.

When you use our website, this may include the details you enter into our discovery call, enquiry or booking forms (such as your name, email address, phone number, organisation and any message you send), and the name, email address and message content you provide if you use our live chat.

**Information collected automatically**

- Technical and log data: our hosting provider records standard server information such as your IP address, browser type and the pages you request. This is used to deliver the site securely and reliably.
- A chat identifier: when you start a live chat, a small token is stored in your browser so your conversation can continue across page loads. It does not identify you on its own.

Some of this information may be classified as special category data, including information about physical or mental health, ethnicity, religion, sexual orientation or other sensitive personal circumstances. We may also process information relating to alleged or confirmed criminal matters where this is necessary for safeguarding or risk management.

We do not use advertising trackers, and we do not buy or sell personal data.

## 4. How we collect information

We may collect personal information:

- Directly from individuals or their parents or guardians.
- Through referral, enquiry, booking and contact forms submitted on our website.
- Through our live chat.
- Through consultations, assessments and appointments.
- From schools, employers, charities, healthcare professionals or other referring organisations.
- From practitioners delivering services.
- During counselling, therapy, coaching or other wellbeing services.
- Through email, telephone, video calls or booking systems.
- From safeguarding or statutory services where necessary.

Where information is provided by another person or organisation, we expect them to have an appropriate reason for sharing it.

## 5. How we use information

We may use personal information to:

- Respond to enquiries and arrange consultations, discovery calls or assessments.
- Understand the support being requested.
- Identify and introduce an appropriate practitioner or service.
- Arrange and administer appointments.
- Deliver counselling, therapy, coaching and wellbeing support.
- Provide live chat and reply to your messages.
- Maintain appropriate referral, administrative and professional records.
- Support professional supervision and clinical governance.
- Safeguard individuals and manage welfare or risk concerns.
- Communicate with clients, parents, practitioners and organisations.
- Monitor attendance and service delivery.
- Process payments and maintain financial records.
- Keep the website secure and working and prevent misuse.
- Respond to complaints, legal matters or regulatory enquiries.
- Meet our legal, professional, contractual and insurance obligations.
- Review and improve our services.

Where possible, we use anonymised or combined information for reporting and service development.

Practitioner recommendations and referral decisions involve human consideration. We do not use solely automated decision-making to determine which practitioner or service may be suitable.

## 6. Our lawful reasons for using information

Under UK GDPR we must have a lawful basis for using your personal information. The lawful reason depends on the service and circumstances. We may rely on:

- **Consent**, for example where you contact us through the website or live chat, or where we have asked for and received clear agreement for a particular use.
- **Contract**, where processing is needed to take steps at your request or to arrange or provide an agreed service.
- **Legitimate interests**, where processing is reasonably necessary to operate, protect and improve our services and keep the website safe and functioning.
- **Legal obligation**, where information must be processed or retained to comply with the law.
- **Vital interests**, where processing is necessary to protect someone's life.
- **Public task**, where this applies to a commissioned public service.

Where we process information on behalf of another organisation, that organisation may be responsible for identifying the lawful basis for that processing.

Additional legal conditions apply when we process special category information. These may include:

- Providing or managing counselling, health or social care services.
- Safeguarding children or adults at risk.
- Protecting someone's vital interests.
- Explicit consent.
- Establishing, exercising or defending legal claims.
- Other reasons of substantial public interest permitted by law.

Where we rely on consent, you can withdraw it at any time by contacting us. Withdrawing consent does not affect anything we did before you withdrew it.

## 7. Referrals and practitioners

Well Connections may share relevant enquiry or referral information with a practitioner being considered to provide support. We will only share information reasonably needed for the practitioner to:

- Consider whether they can provide appropriate support.
- Confirm their availability.
- Understand relevant support, accessibility or risk needs.
- Arrange or provide the agreed service.

Some practitioners work as independent professionals and may act as separate Data Controllers for their own clinical records. Where this applies, they are responsible for how they use, store and retain those records and may provide their own privacy information. Well Connections does not routinely have access to every clinical record created by an independent practitioner.

## 8. Counselling and clinical records

Qualified practitioners may maintain proportionate clinical or professional records to support safe and effective professional practice, professional supervision, safeguarding and risk management, clinical governance, insurance and professional requirements, and complaints or legal matters.

Clinical records are treated as confidential and are not routinely shared with schools, employers, charities or commissioning organisations. Relevant information may be shared where the client has agreed, where there is a safeguarding or serious welfare concern, where sharing is necessary to protect someone from harm, or where disclosure is required by law or professional obligations.

## 9. Children and young people

Children and young people have rights over their own personal information. We aim to explain confidentiality and the use of personal information in language appropriate to the young person's age and understanding. Parents or guardians may also receive information where appropriate.

Requests from parents or guardians to access a child's information will be considered in light of the young person's age, understanding and capacity, their confidentiality, safeguarding considerations, professional obligations and the young person's best interests.

Separate child-friendly or service-specific privacy information may be provided for school counselling and other commissioned services.

## 10. Cookies and website storage

This site is deliberately light on cookies. We do not use analytics, advertising or tracking cookies.

We use only strictly necessary storage:

- Our live chat feature stores a small token in your browser so your conversation works across pages.
- If the site owner logs in to the private admin area, a session cookie is used to keep them signed in.
- Our booking, enquiry and chat forms use Cloudflare Turnstile, which may set a cookie to confirm you are not a bot before your submission is accepted.

Because we set only strictly necessary storage for visitors, you will not see a cookie consent banner. You can clear this storage at any time through your browser settings.

## 11. Who we share it with

We never sell your data. Where necessary and appropriate, we may share relevant personal information with:

- Practitioners being considered for or providing support.
- Schools, employers, charities or commissioning organisations.
- Parents or guardians where appropriate.
- Designated safeguarding leads.
- Health, education or social care professionals.
- Local authorities, emergency services and statutory agencies.
- Professional supervisors, using anonymised or limited information wherever possible.
- Insurers, accountants and legal advisers.
- Regulators, courts and law-enforcement agencies where required.

We also use trusted service providers who help us run the site and respond to you, and only so far as they need it. These processors include:

- **Cloudflare**, which hosts the website, stores enquiry, booking and live chat records in its database service on our behalf, and runs a challenge (Turnstile) on our forms to filter out spam and automated abuse.
- **Resend**, which delivers the notification emails that let us know you have made an enquiry, booking or started a chat.
Our website fonts and images are hosted on our own site rather than by third parties, so viewing the site does not share your information with external font or image providers.

Where another organisation processes information on our behalf, we require it to protect the information, maintain confidentiality and only use it for the agreed purpose.

## 12. Confidentiality and safeguarding

Information shared during a consultation, assessment, counselling, therapy or coaching session is treated as confidential. Confidentiality may need to be limited where a child or adult may be at risk of harm, where someone else may be at risk, where there is an immediate or serious welfare concern, where disclosure is required by law, a court or a regulator, or where the individual has agreed to the sharing.

Where it is appropriate and safe, we will explain the proposed sharing before information is disclosed.

## 13. International transfers

Some of the providers above are based outside the United Kingdom, including in the United States. Where your information is transferred abroad, we rely on appropriate safeguards recognised under UK data protection law, such as the UK International Data Transfer Agreement or the UK extension to the EU Standard Contractual Clauses, so your information keeps a similar level of protection.

## 14. How we keep it secure

The site is served over an encrypted connection, and enquiry, booking and chat records are held in a protected database accessible only through a private, password-protected admin area. We also use appropriate technical and organisational measures such as access controls, multi-factor authentication where available, secure email and cloud-based systems, confidentiality requirements for practitioners and contractors, and secure deletion processes. While no online service can be guaranteed completely secure, we take reasonable steps to protect your information against loss, misuse and unauthorised access.

## 15. How long we keep it

We retain personal information only for as long as it is reasonably required. The appropriate retention period may depend on the type of information and service, whether the person was a child or adult when the service was provided, safeguarding considerations, professional and insurance requirements, contractual and legal obligations, financial and accounting requirements, and whether a complaint, investigation or legal claim is ongoing or reasonably anticipated.

As a general guide:

- Website enquiries and discovery call requests are kept for as long as we are in contact with you and for up to 12 months after our last contact, unless you become a client.
- Live chat transcripts are kept for up to 12 months, then deleted.
- Referral, clinical and financial records are kept in line with our professional, insurance and legal obligations, which may be longer.

Information will be securely deleted or destroyed when it is no longer required. Further information about the period applying to a particular record can be requested by contacting us.

## 16. Your rights

Depending on the circumstances, you may have the right to:

- Be informed about how your information is used.
- Request access to information held about you.
- Ask for inaccurate or incomplete information to be corrected.
- Request deletion or restriction of information.
- Object to certain uses of your information.
- Request transfer of information in an appropriate format.
- Withdraw consent where consent is the lawful basis.
- Complain about how your information has been handled.

These rights are not absolute. Information may sometimes need to be retained for safeguarding, legal, professional or insurance reasons.

To make a request, contact info@wellconnections.co.uk. We may need to confirm your identity and authority before responding, and we will normally respond within one month.

## 17. Marketing

We may send information about our services where we have permission or another lawful reason to do so. You can unsubscribe or ask us to stop at any time. We do not use counselling or clinical information for marketing purposes.

## 18. Complaints

Please contact us if you have concerns about how your personal information has been handled:

- Email: info@wellconnections.co.uk
- Telephone: 07736 317617

You also have the right to complain to the Information Commissioner's Office (ICO), the UK data protection regulator, at ico.org.uk/make-a-complaint or on 0303 123 1113. We would welcome the chance to resolve your concern first, so please do consider contacting us before you approach the ICO.

## 19. Changes to this Privacy Notice

We may update this Privacy Notice where our services, systems, legal requirements or working arrangements change. The most recent version will be available on our website, with the latest update date shown at the top.`;
const DEFAULT_UPDATED = "22 September 2026";


// /privacy -> Privacy Notice. Body text is stored in app_settings under
// 'privacy_notice' so it can be pasted in without a redeploy.
export async function onRequestGet(context) {
  const { env } = context;

  let content = "";
  let updated = "";
  try {
    const row = await env.DB.prepare(
      "SELECT value, updated_at FROM app_settings WHERE key='privacy_notice'"
    ).first();
    content = (row && row.value) || "";
    updated = (row && row.updated_at) || "";
  } catch {
    content = "";
  }

  const hasContent = content.trim().length > 0;
  const bodyMd = hasContent ? content : DEFAULT_PRIVACY;
  const updatedLabel = hasContent
    ? (updated ? escapeHtml(String(updated).slice(0, 10)) : "")
    : DEFAULT_UPDATED;

  const body = `
  <header class="page-head">
    <span class="label">Legal</span>
    <h1>Privacy<br /><em>Notice.</em></h1>
    ${updatedLabel ? `<p>Last updated ${updatedLabel}.</p>` : ""}
  </header>

  <main class="wrap legal-wrap">
    <div class="legal-body">${markdownToHtml(bodyMd)}</div>
  </main>
  ${LEGAL_CSS}`;

  return new Response(
    layout({
      title: "Privacy Notice | Well Connections",
      description: "How Well Connections collects, uses and protects your personal information.",
      canonical: "/privacy",
      body
    }),
    { headers: { "content-type": "text/html;charset=UTF-8" } }
  );
}

export const LEGAL_CSS = `
<style>
  .legal-wrap{max-width:760px;padding-bottom:5rem}
  .legal-body{font-size:.96rem;color:var(--text-muted);line-height:1.8}
  .legal-body h2{font-family:'League Spartan',sans-serif;font-size:1.2rem;font-weight:600;
    color:var(--bark-dark);margin:2.25rem 0 .75rem}
  .legal-body h3{font-family:'League Spartan',sans-serif;font-size:1rem;font-weight:600;
    color:var(--bark-dark);margin:1.75rem 0 .5rem}
  .legal-body p{margin-bottom:1rem}
  .legal-body ul,.legal-body ol{margin:0 0 1rem 1.25rem}
  .legal-body li{margin-bottom:.45rem}
  .legal-body a{color:var(--teal)}
  .legal-pending{background:var(--cream);border:1px solid var(--stone);border-radius:10px;
    padding:2.5rem;text-align:center}
  .legal-pending h2{font-family:'League Spartan',sans-serif;font-size:1.2rem;font-weight:600;
    color:var(--bark-dark);margin-bottom:.75rem}
  .legal-pending p{font-size:.93rem;color:var(--text-muted);line-height:1.75;
    max-width:52ch;margin:0 auto 1rem}
  .legal-ico{font-size:.85rem!important}
  .legal-btn{display:inline-block;margin-top:.75rem;background:var(--sage);color:#fff!important;
    text-decoration:none;padding:.8rem 1.6rem;border-radius:4px;font-size:.88rem;font-weight:500;
    letter-spacing:.03em;transition:background .2s}
  .legal-btn:hover{background:var(--sage-dark)}
  .legal-btn:focus-visible{outline:2px solid var(--teal);outline-offset:3px}
</style>`;
