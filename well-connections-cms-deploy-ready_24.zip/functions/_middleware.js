import { json } from "../shared/layout.js";
import { verifyAccess } from "../shared/access.js";
import { rateLimit, clientKey } from "../shared/ratelimit.js";

// Per-IP caps for the three anonymous write endpoints. Tuned to be generous for
// real people and still choke automated abuse. Adjust here in one place.
// [limit, windowSeconds]
const PUBLIC_LIMITS = {
  "/api/enquiries":    [5, 600],   // 5 contact-form sends per 10 minutes
  "/api/bookings":     [5, 600],   // 5 booking requests per 10 minutes
  "/api/chat/message": [20, 300],  // 20 chat messages per 5 minutes
};

// Runs on every request. Admin access is controlled by Cloudflare Zero Trust
// (Access) in front of /admin. The Access JWT rides to /api on the same
// hostname, and we verify it here so admin API calls are protected by your
// Zero Trust policy — while the public form endpoints (booking, enquiry, chat)
// stay open to anonymous visitors. The verified identity is exposed as
// `context.data.session` so the rest of the app's existing admin checks work
// unchanged (no password anywhere).
//
// Requires two env vars (see shared/access.js): CF_ACCESS_TEAM_DOMAIN and
// CF_ACCESS_AUD. Until they are set, admin writes fail closed.
export async function onRequest(context) {
  const { request } = context;
  const url = new URL(request.url);
  const method = request.method.toUpperCase();

  const identity = await verifyAccess(context);
  context.data.session = identity; // { sub, email } when a valid Access JWT is present, else null

  const isApi = url.pathname.startsWith("/api/");
  // Visitors are anonymous, so the public chat-send endpoint is allowed without
  // Access — but only POST, the one method it handles. Any other write method
  // to that path stays gated.
  const isPublicChat = url.pathname === "/api/chat/message" && method === "POST";
  // Visitors submit booking requests without Access (POST /api/bookings only).
  const isPublicBooking = url.pathname === "/api/bookings" && method === "POST";
  // Visitors submit contact-form enquiries without Access (POST /api/enquiries only).
  const isPublicEnquiry = url.pathname === "/api/enquiries" && method === "POST";
  const isWrite = ["POST", "PUT", "PATCH", "DELETE"].includes(method);

  // CSRF defence in depth: state-changing API requests must originate from our
  // own site. Browsers always attach an Origin header to cross-site writes, so
  // a mismatch means a forged request riding the admin's session cookie. We only
  // reject when an Origin/Referer is present and points elsewhere, so same-origin
  // calls and non-browser clients are unaffected.
  if (isApi && isWrite) {
    const originHeader = request.headers.get("Origin") || request.headers.get("Referer");
    if (originHeader) {
      let ok = false;
      try { ok = new URL(originHeader).host === url.host; } catch { ok = false; }
      if (!ok) return json({ error: "Cross-origin request blocked" }, 403);
    }
  }

  if (isApi && isWrite && !isPublicChat && !isPublicBooking && !isPublicEnquiry && !context.data.session) {
    return json({ error: "Not authenticated" }, 401);
  }

  // Rate-limit the anonymous write endpoints per IP (second layer behind
  // Turnstile). Authenticated admin requests are never limited. Fails open if
  // the rate_limits table has not been migrated yet.
  if ((isPublicChat || isPublicBooking || isPublicEnquiry) && !context.data.session) {
    const conf = PUBLIC_LIMITS[url.pathname];
    if (conf) {
      const [limit, windowSec] = conf;
      const rl = await rateLimit(context.env, clientKey(request, url.pathname), limit, windowSec);
      if (!rl.ok) {
        return json(
          { error: "Too many requests. Please wait a moment and try again." },
          429,
          { "Retry-After": String(rl.retryAfter || windowSec) }
        );
      }
    }
  }

  return context.next();
}
