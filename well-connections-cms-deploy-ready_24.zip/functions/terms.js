import { layout } from "../shared/layout.js";
import { escapeHtml, markdownToHtml } from "../shared/markdown.js";
import { LEGAL_CSS } from "./privacy.js";

// Public Website and Booking Terms, as supplied by Sam (Oct 2026).
// Used whenever app_settings has no 'terms' row, the same way /privacy works.
const DEFAULT_TERMS = `## About our services

Well Connections Ltd helps individuals, families, schools and organisations access counselling, psychological support, coaching, training and wellbeing services.

These terms cover enquiries and bookings made through our website. Further terms specific to your sessions, programme or organisational service will be provided before that service begins.

## Enquiries and bookings

An introductory or discovery call gives us an opportunity to understand your needs and discuss suitable support. It is not a therapy session.

Submitting an enquiry or booking request does not guarantee a particular practitioner, appointment or service. We will confirm the arrangements with you.

## Our practitioners

We take time to understand your needs and recommend appropriate support from our network of practitioners.

Before a practitioner joins our network, we check their qualifications, professional registration or membership where applicable, professional indemnity insurance and DBS status, including the appropriate level of clearance for their role. We also take references, review their supervision arrangements and meet them for a personal interview to understand their experience and approach.

Where we recommend, place or introduce you to a practitioner, they may pay Well Connections a referral fee. Any fees payable by you will be explained before you agree to proceed.

Practitioners are responsible for working within their qualifications, experience and professional standards. Before sessions begin, you will be told who is providing your support, who your agreement is with and who to contact about appointments or concerns.

## Our clinical partnership

We also work in clinical partnership with Krysallis. Where your support is provided through this partnership, we will explain how the service is arranged, who will provide your sessions and who holds clinical responsibility for your care.

## Working with schools and colleges

We work alongside schools and colleges to agree clear arrangements for referrals, consent, safeguarding, confidentiality and secure record keeping before support begins.

We liaise with the school's Designated Safeguarding Lead and relevant staff, following agreed procedures for reporting and escalating concerns. Where required, practitioners use the school's safeguarding system, such as CPOMS, after receiving appropriate access and training.

Client records and documents are held securely, with access restricted to authorised people. Information is shared only where necessary and appropriate, in line with data protection requirements, safeguarding responsibilities and the agreed service arrangements.

Any reporting on attendance, engagement and outcomes is agreed with the school, with clear boundaries around the confidentiality of individual sessions.

## Fees and cancellations

Fees, payment arrangements and cancellation terms will be confirmed before you commit to a paid service.

For school, workplace or other funded programmes, eligibility, session entitlement and attendance arrangements are governed by the relevant programme agreement.

Please contact us promptly if you need to cancel or rearrange a website booking. For ongoing sessions, contact your practitioner using the arrangements they have provided.

Nothing in these terms limits your statutory consumer rights.

## Privacy and confidentiality

Please read our [Privacy Notice](/privacy) for information about how Well Connections handles your personal information.

Your practitioner will explain confidentiality, record keeping and the circumstances in which information may need to be shared, including safeguarding concerns or legal requirements.

## Questions or concerns

If you have a concern about our service or a referral, please email [info@wellconnections.co.uk](mailto:info@wellconnections.co.uk). We will explain the appropriate complaints process and help direct your concern to the right person.

## Urgent support

Our website, enquiry forms and live chat are not emergency services and are not continuously monitored. If someone is in immediate danger, call 999.

## Website information

The information on this website is general information and does not replace individual professional advice or an assessment of your needs.`;
const DEFAULT_UPDATED = "19 October 2026";

// /terms -> Website and Booking Terms. A 'terms' row in app_settings
// overrides the default above, so wording can change without a redeploy.
export async function onRequestGet(context) {
  const { env } = context;

  let content = "";
  let updated = "";
  try {
    const row = await env.DB.prepare(
      "SELECT value, updated_at FROM app_settings WHERE key='terms'"
    ).first();
    content = (row && row.value) || "";
    updated = (row && row.updated_at) || "";
  } catch {
    content = "";
  }

  const hasContent = content.trim().length > 0;
  const bodyMd = hasContent ? content : DEFAULT_TERMS;
  const updatedLabel = hasContent
    ? (updated ? escapeHtml(String(updated).slice(0, 10)) : "")
    : DEFAULT_UPDATED;

  const body = `
  <header class="page-head">
    <span class="label">Legal</span>
    <h1>Website and<br /><em>booking terms.</em></h1>
    ${updatedLabel ? `<p>Last updated ${updatedLabel}.</p>` : ""}
  </header>

  <main class="wrap legal-wrap">
    <div class="legal-body">${markdownToHtml(bodyMd)}</div>
  </main>
  ${LEGAL_CSS}`;

  return new Response(
    layout({
      title: "Website and Booking Terms | Well Connections",
      description: "The terms that apply to enquiries and bookings made through the Well Connections website.",
      canonical: "/terms",
      body
    }),
    { headers: { "content-type": "text/html;charset=UTF-8" } }
  );
}
