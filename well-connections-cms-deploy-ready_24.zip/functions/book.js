import { layout } from "../shared/layout.js";
import { escapeHtml } from "../shared/markdown.js";

// /book -> directory of the publicly listed call types.
// Partner-specific links stay unlisted by default: those are shared directly
// with the organisation rather than advertised on the site.
export async function onRequestGet(context) {
  const { env } = context;

  let rows = [];
  try {
    rows = (await env.DB.prepare(
      `SELECT * FROM booking_pages
        WHERE status='published' AND listed=1
        ORDER BY kind DESC, sort_order ASC, id ASC`
    ).all()).results || [];
  } catch {
    rows = []; // table not migrated yet
  }

  const cards = rows.map(r => `
    <a class="bkd-card" href="/book/${escapeHtml(r.slug)}">
      <span class="bkd-kind">${r.kind === "general" ? "Open to everyone" : escapeHtml(r.organisation || "Partner organisation")}</span>
      <h2>${escapeHtml(r.name)}</h2>
      ${r.intro ? `<p>${escapeHtml(r.intro)}</p>` : ""}
      <span class="bkd-go">Choose a time <span aria-hidden="true">&rarr;</span></span>
    </a>`).join("");

  const body = `
  <header class="page-head">
    <span class="label">Book a call</span>
    <h1>Find a time<br /><em>that works for you.</em></h1>
    <p>We offer a free initial call within 24 hours of an enquiry. Where your availability allows, a first session can usually follow within a week.</p>
  </header>

  <main class="wrap bkd-wrap">
    ${rows.length
      ? `<div class="bkd-grid">${cards}</div>`
      : `<div class="bkd-empty">
           <p>Booking links are being set up. Please <a href="/#contact">send us a message</a> and we will arrange a time with you directly.</p>
         </div>`}

    <div class="bkd-note">
      <h2>Been sent a link by your organisation?</h2>
      <p>Some of the organisations we work with have their own dedicated booking page. Use the link they gave you rather than the options above, so your booking reaches the right team.</p>
    </div>

    <p class="bkd-urgent">
      Well Connections is not an emergency service. If you need urgent help, contact your GP,
      call 111 or 999, or call the Samaritans free on 116 123.
    </p>
  </main>

  <style>
    .bkd-wrap{max-width:1000px;padding-bottom:5rem}
    .bkd-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:1.25rem}
    .bkd-card{display:flex;flex-direction:column;background:#fff;border:1px solid var(--stone);
      border-top:3px solid var(--teal);border-radius:10px;padding:1.75rem;text-decoration:none;
      transition:transform .18s ease,box-shadow .18s ease,border-color .18s ease}
    .bkd-card:hover{transform:translateY(-3px);box-shadow:0 12px 32px rgba(30,48,40,.1)}
    .bkd-card:focus-visible{outline:2px solid var(--teal);outline-offset:3px}
    @media (prefers-reduced-motion:reduce){.bkd-card{transition:none}.bkd-card:hover{transform:none}}
    .bkd-kind{font-size:.7rem;letter-spacing:.14em;text-transform:uppercase;color:var(--teal);
      font-weight:500;margin-bottom:.6rem}
    .bkd-card h2{font-family:'League Spartan',sans-serif;font-size:1.25rem;font-weight:600;
      color:var(--bark-dark);line-height:1.25;margin-bottom:.6rem}
    .bkd-card p{font-size:.9rem;color:var(--text-muted);line-height:1.7;flex:1;margin-bottom:1.25rem}
    .bkd-go{font-size:.84rem;color:var(--teal);font-weight:500;letter-spacing:.03em}
    .bkd-card:hover .bkd-go{text-decoration:underline}
    .bkd-empty{background:var(--cream);border:1px solid var(--stone);border-radius:10px;
      padding:2.5rem;text-align:center;color:var(--text-muted)}
    .bkd-empty a{color:var(--teal)}
    .bkd-note{margin-top:2.5rem;background:var(--sage-pale);border:1px solid var(--stone);
      border-radius:10px;padding:1.75rem}
    .bkd-note h2{font-family:'League Spartan',sans-serif;font-size:1.05rem;font-weight:600;
      color:var(--bark-dark);margin-bottom:.5rem}
    .bkd-note p{font-size:.9rem;color:var(--text-muted);line-height:1.7}
    .bkd-urgent{margin-top:2rem;font-size:.8rem;color:var(--text-muted);text-align:center;
      line-height:1.7;max-width:56ch;margin-inline:auto}
  </style>`;

  return new Response(
    layout({
      title: "Book a Free Discovery Call | Well Connections",
      description: "Book a free initial call with Well Connections. Discovery calls for organisations and personal support calls for individuals.",
      body,
      canonical: "/book"
    }),
    { headers: { "content-type": "text/html;charset=UTF-8" } }
  );
}
