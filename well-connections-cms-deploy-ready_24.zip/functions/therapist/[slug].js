import { layout } from "../../shared/layout.js";
import { markdownToHtml, escapeHtml, slugify } from "../../shared/markdown.js";

const BOOK_URL = "/#book";

const TITLES = ["dr", "dr.", "mr", "mr.", "mrs", "mrs.", "ms", "ms.", "miss", "prof", "prof.", "professor", "rev", "rev."];

// First name for button copy ("Send an enquiry to Sam"), keeping a leading
// title with the name that follows it so "Dr Patel" never becomes "Dr".
function shortName(full) {
  const parts = String(full || "").trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return "us";
  if (parts.length > 1 && TITLES.includes(parts[0].toLowerCase())) return parts[0] + " " + parts[1];
  return parts[0];
}

// /therapist/<slug>  -> individual profile. Slug is derived from the name,
// so no database column is needed and existing records work as-is.
// Old or misspelt profile slugs that Google still has -> current slug.
// Pages Functions are not covered by _redirects, so these live here.
const SLUG_ALIASES = {
  "lorna-chippendale": "lorna-chippindale",
};

export async function onRequestGet(context) {
  const { env, params, data } = context;
  if (SLUG_ALIASES[params.slug]) {
    return Response.redirect(new URL(`/therapist/${SLUG_ALIASES[params.slug]}`, context.request.url).toString(), 301);
  }
  const isAdmin = !!data.session;

  const sql = isAdmin
    ? "SELECT * FROM therapists"
    : "SELECT * FROM therapists WHERE status='published'";
  const people = (await env.DB.prepare(sql).all()).results || [];
  const t = people.find((p) => slugify(p.name) === params.slug);

  if (!t) {
    return new Response(layout({
      title: "Profile not found | Well Connections",
      description: "The profile you were looking for could not be found.",
      noindex: true,
      body: `<main class="wrap" style="text-align:center;padding:5rem 5%"><h1 style="font-weight:600">Profile not found</h1><p style="margin-top:1rem"><a href="/team">Back to our teams</a></p></main>`,
    }), { status: 404, headers: { "Content-Type": "text/html; charset=utf-8" } });
  }

  const allTeams = (await env.DB.prepare(
    "SELECT * FROM teams WHERE status='published' ORDER BY sort_order ASC, name ASC"
  ).all()).results || [];
  const myTeamSlugs = (t.teams || "").split("|").filter(Boolean);
  const myTeams = allTeams.filter((tm) => myTeamSlugs.includes(tm.slug));
  const otherTeams = allTeams.filter((tm) => !myTeamSlugs.includes(tm.slug));

  const photo = t.photo_url
    ? `<img class="p-photo" src="${escapeHtml(t.photo_url)}" alt="${escapeHtml(t.name)}" />`
    : `<div class="p-photo p-ph">${escapeHtml((t.name || "?").charAt(0))}</div>`;

  const bioHtml = t.bio ? markdownToHtml(t.bio) : `<p class="p-nobio">A full profile for ${escapeHtml(t.name)} is coming soon.</p>`;

  const teamLinks = otherTeams.map((tm) =>
    `<a href="/team/${escapeHtml(tm.slug)}">${escapeHtml(tm.name)}</a>`).join("");

  const backTeam = myTeams[0];

  const body = `
  <article>
    <header class="page-head">
      <nav class="crumb">
        <a href="/">Home</a> <span>&rsaquo;</span>
        ${backTeam ? `<a href="/team/${escapeHtml(backTeam.slug)}">${escapeHtml(backTeam.name)}</a> <span>&rsaquo;</span> ` : `<a href="/team">Teams</a> <span>&rsaquo;</span> `}
        <span>${escapeHtml(t.name)}</span>
      </nav>
      <h1>${escapeHtml(t.name)}</h1>
      ${t.role ? `<p class="p-role">${escapeHtml(t.role)}</p>` : ""}
    </header>

    <main class="wrap p-layout">
      <aside class="p-side">
        ${photo}
        ${t.credentials ? `<div class="p-creds"><h3>Qualifications &amp; Accreditations</h3><p>${escapeHtml(t.credentials)}</p></div>` : ""}
        ${t.accepting ? `<p class="p-avail">Currently accepting clients</p>` : ""}
        <a class="p-cta" href="${BOOK_URL}">Book a free consultation</a>
        <a class="p-cta-ghost" href="/#contact"
           data-enquiry-therapist="${escapeHtml(params.slug)}"
           data-enquiry-therapist-name="${escapeHtml(t.name)}">Send an enquiry to ${escapeHtml(shortName(t.name))}</a>
      </aside>

      <div class="p-main">
        <div class="p-bio">${bioHtml}</div>
        ${myTeams.length ? `<div class="p-teams-in"><span>Part of:</span> ${myTeams.map((tm)=>`<a href="/team/${escapeHtml(tm.slug)}">${escapeHtml(tm.name)}</a>`).join("")}</div>` : ""}
        ${teamLinks ? `<div class="p-otherteams"><h3>Explore our other therapy teams</h3><div class="p-teamlinks">${teamLinks}</div></div>` : ""}
        <p class="p-back"><a href="${backTeam ? "/team/" + escapeHtml(backTeam.slug) : "/team"}">&larr; Back to ${backTeam ? escapeHtml(backTeam.name) : "our teams"}</a></p>
      </div>
    </main>
  </article>

  <style>
    .page-head .crumb{font-size:.8rem;margin-bottom:1rem;color:rgba(255,255,255,.6)}
    .page-head .crumb a{color:var(--sage-light);text-decoration:none}
    .p-role{color:var(--sage-light);font-size:1rem;margin-top:.5rem}
    .p-layout{display:grid;grid-template-columns:300px 1fr;gap:3rem;align-items:start}
    .p-side{position:sticky;top:110px}
    .p-photo{width:100%;aspect-ratio:1/1;object-fit:cover;object-position:top;border-radius:10px;background:var(--sage-pale);display:block}
    .p-ph{display:flex;align-items:center;justify-content:center;font-family:'League Spartan',sans-serif;font-size:5rem;color:var(--sage)}
    .p-creds{margin-top:1.5rem;padding-top:1.4rem;border-top:1px solid var(--stone)}
    .p-creds h3{font-size:.72rem;letter-spacing:.08em;text-transform:uppercase;color:var(--sage-dark);font-weight:600;margin-bottom:.5rem}
    .p-creds p{font-size:.86rem;color:var(--text-muted);line-height:1.6}
    .p-avail{margin-top:1.2rem;font-size:.78rem;letter-spacing:.04em;text-transform:uppercase;color:var(--sage-dark);font-weight:500}
    .p-avail::before{content:"\\25CF  ";color:var(--sage)}
    .p-cta{display:block;text-align:center;margin-top:1.4rem;background:var(--sage);color:#fff;padding:.85rem 1rem;border-radius:3px;text-decoration:none;font-size:.9rem;letter-spacing:.03em;transition:background .2s}
    .p-cta:hover{background:var(--sage-dark)}
    .p-cta-ghost{display:block;text-align:center;margin-top:.6rem;color:var(--teal);padding:.7rem 1rem;border:1px solid var(--stone);border-radius:3px;text-decoration:none;font-size:.88rem}
    .p-cta-ghost:hover{border-color:var(--sage)}
    .p-bio p{margin:0 0 1.2rem;font-size:1.05rem;line-height:1.8;color:#2a3a32}
    .p-bio h2,.p-bio h3{font-family:'League Spartan',sans-serif;font-weight:600;margin:1.5rem 0 .6rem;color:var(--text)}
    .p-nobio{color:var(--text-muted);font-style:italic}
    .p-teams-in{margin-top:1.5rem;font-size:.9rem;color:var(--text-muted)}
    .p-teams-in span{text-transform:uppercase;letter-spacing:.06em;font-size:.72rem;margin-right:.4rem}
    .p-teams-in a{color:var(--teal);text-decoration:none;margin-right:.6rem}
    .p-otherteams{margin-top:2.5rem;padding-top:2rem;border-top:1px solid var(--stone)}
    .p-otherteams h3{font-family:'League Spartan',sans-serif;font-weight:600;font-size:1.1rem;margin-bottom:1rem}
    .p-teamlinks{display:flex;flex-wrap:wrap;gap:.6rem}
    .p-teamlinks a{font-size:.82rem;background:var(--sage-pale);color:var(--sage-dark);padding:.45rem .9rem;border-radius:20px;text-decoration:none;transition:background .2s}
    .p-teamlinks a:hover{background:var(--sage-light)}
    .p-back{margin-top:2.5rem}
    .p-back a{color:var(--teal);text-decoration:none}
    @media(max-width:760px){.p-layout{grid-template-columns:1fr;gap:2rem}.p-side{position:static}.p-photo{max-width:260px}}
  </style>`;

  const SITE = "https://wellconnections.co.uk";
  const canonical = `${SITE}/therapist/${params.slug}`;
  const personJsonLd = {
    "@context": "https://schema.org",
    "@type": "Person",
    "@id": canonical + "#person",
    "name": t.name,
    "url": canonical,
    "jobTitle": t.role || "Practitioner",
    "worksFor": { "@type": "Organization", "name": "Well Connections", "url": SITE + "/" },
    ...(t.photo_url ? { "image": t.photo_url.startsWith("http") ? t.photo_url : SITE + t.photo_url } : {}),
  };
  return new Response(layout({
    title: `${t.name}${t.role ? ", " + t.role : ""} | Well Connections`,
    description: t.role ? `${t.name} — ${t.role} at Well Connections.` : `${t.name} at Well Connections.`,
    body,
    canonical,
    ogType: "profile",
    jsonLd: personJsonLd,
  }), { headers: { "Content-Type": "text/html; charset=utf-8" } });
}
