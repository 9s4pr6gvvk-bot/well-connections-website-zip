// Serves objects back out of the R2 MEDIA bucket at /media/<key>
export async function onRequestGet(context) {
  const { env, params } = context;
  if (!env.MEDIA) return new Response("Not found", { status: 404 });
  const key = Array.isArray(params.path) ? params.path.join("/") : params.path;
  const obj = await env.MEDIA.get(key);
  if (!obj) return new Response("Not found", { status: 404 });
  const headers = new Headers();
  obj.writeHttpMetadata(headers);
  headers.set("etag", obj.httpEtag);
  headers.set("Cache-Control", "public, max-age=31536000, immutable");
  // Defence in depth: never let the browser sniff a stored object into an
  // executable type, and force any non-image to download rather than render.
  headers.set("X-Content-Type-Options", "nosniff");
  const ct = (headers.get("content-type") || "").toLowerCase();
  if (!/^image\/(jpeg|png|gif|webp|avif)$/.test(ct)) {
    headers.set("Content-Type", "application/octet-stream");
    headers.set("Content-Disposition", "attachment");
  }
  return new Response(obj.body, { headers });
}
