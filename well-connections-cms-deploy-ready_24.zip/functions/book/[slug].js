import { layout } from "../../shared/layout.js";
import { escapeHtml } from "../../shared/markdown.js";
import { getPageSettings, parseQuestions } from "../../shared/availability.js";

// /book/<slug> -> native booking page. Two steps: pick a time, then confirm
// details. Slots come from /api/availability?page=<slug>, so a page can carry
// its own hours, duration and questions.
export async function onRequestGet(context) {
  const { env, params, data } = context;

  let page = null;
  try {
    page = await env.DB.prepare("SELECT * FROM booking_pages WHERE slug=?")
      .bind(params.slug).first();
  } catch {
    page = null;
  }

  if (!page || (page.status !== "published" && !data.session)) {
    return new Response(
      layout({
        title: "Booking page not found | Well Connections",
        description: "This booking page is not available.",
        body: `
        <header class="page-head">
          <span class="label">Booking</span>
          <h1>This page isn't<br /><em>available.</em></h1>
          <p>The link you followed may have been changed or retired. Please get in touch and we will send you a current one.</p>
        </header>
        <main class="wrap" style="text-align:center;padding-bottom:5rem">
          <a href="/#contact" class="bk-btn">Contact us</a>
          <a href="/book" class="bk-btn bk-btn-alt">See booking options</a>
        </main>
        ${BOOK_CSS}`
      }),
      { status: 404, headers: { "content-type": "text/html;charset=UTF-8" } }
    );
  }

  const settings = await getPageSettings(env, page);
  const questions = parseQuestions(page.questions);
  const isDraft = page.status !== "published";

  // Render the custom questions server-side so they work without a round trip.
  // Each question sits in a wrapper carrying its label, type and required flag,
  // which is what the submit handler reads (radio and tick-box groups have no
  // single input to read a value from).
  const questionFields = questions.map((q, i) => {
    const id = `q-${i}`;
    const req = q.required ? " required" : "";
    const star = q.required ? ` <span class="bk-req" aria-hidden="true">*</span>` : "";
    const long = q.label.length > 40 ? " bk-long" : "";
    const wrapAttrs = `data-q="${escapeHtml(q.label)}" data-qtype="${q.type}" data-qreq="${q.required ? 1 : 0}"`;
    if (q.type === "radio" || q.type === "checkbox") {
      const opts = q.options.map((o, j) =>
        `<label class="bk-opt"><input type="${q.type}" name="${id}" value="${escapeHtml(o)}"> <span>${escapeHtml(o)}</span></label>`
      ).join("");
      return `<fieldset class="bk-field bk-group${long}" ${wrapAttrs}><legend>${escapeHtml(q.label)}${star}</legend><div class="bk-opts">${opts}</div></fieldset>`;
    }
    let field;
    if (q.type === "textarea") {
      field = `<textarea id="${id}" name="${escapeHtml(q.label)}" rows="3"${req}></textarea>`;
    } else if (q.type === "select") {
      const opts = q.options.map((o) => `<option value="${escapeHtml(o)}">${escapeHtml(o)}</option>`).join("");
      field = `<select id="${id}" name="${escapeHtml(q.label)}"${req}><option value="">Please choose…</option>${opts}</select>`;
    } else {
      const t = q.type === "email" ? "email" : q.type === "tel" ? "tel" : "text";
      field = `<input type="${t}" id="${id}" name="${escapeHtml(q.label)}"${req}>`;
    }
    return `<div class="bk-field${long}" ${wrapAttrs}><label for="${id}">${escapeHtml(q.label)}${star}</label>${field}</div>`;
  }).join("");

  // Intro: first paragraph under the heading, the rest in an "about this call"
  // panel, so a full Calendly-style description reads properly. Email
  // addresses become mailto links.
  const linkify = (t) => escapeHtml(t).replace(/([A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,})/g, '<a href="mailto:$1">$1</a>');
  const introParas = String(page.intro || "").split(/\n\s*\n|\r\n\s*\r\n/).map((x) => x.trim()).filter(Boolean);
  const introLead = introParas.length ? `<p>${linkify(introParas[0])}</p>` : "";
  const introRest = introParas.slice(1).map((x) => `<p>${linkify(x).replace(/\n/g, "<br>")}</p>`).join("");
  const phoneReq = !!page.phone_required;
  const noteHidden = !!page.note_hidden;
  const noteLabel = (page.note_label || "").trim() || "Anything else we should know?";

  const body = `
  <header class="page-head bk-head">
    <span class="label">${page.organisation ? escapeHtml(page.organisation) : "Book a call"}</span>
    <h1>${escapeHtml(page.name)}</h1>
    ${introLead}
  </header>

  <main class="wrap bk-wrap">
    ${isDraft ? `<div class="bk-draft" role="status">Draft — only visible to you while signed in.</div>` : ""}

    ${introRest ? `<section class="bk-about" aria-label="About this call">${introRest}</section>` : ""}

    <div class="bk-shell">
      <ol class="bk-steps" aria-label="Booking progress">
        <li class="bk-step is-on" data-step="1"><span>1</span> Choose a time</li>
        <li class="bk-step" data-step="2"><span>2</span> Your details</li>
      </ol>

      <div class="bk-meta">
        <span class="bk-chip"><span class="bk-dot"></span>${settings.duration} minutes</span>
        <span class="bk-chip">${escapeHtml(settings.timezone.replace("_", " "))}</span>
        <span class="bk-chip">Free, no obligation</span>
      </div>

      <!-- STEP 1: slot picker -->
      <section id="bk-step1" class="bk-panel" aria-labelledby="bk-s1-h">
        <h2 id="bk-s1-h" class="bk-sr">Choose a time</h2>

        <div id="bk-loading" class="bk-state">
          <span class="bk-spinner" aria-hidden="true"></span>
          <p>Loading available times…</p>
        </div>

        <div id="bk-error" class="bk-state bk-state-err" hidden>
          <p id="bk-error-msg">We couldn't load the calendar.</p>
          <button type="button" class="bk-btn bk-btn-alt" id="bk-retry">Try again</button>
        </div>

        <div id="bk-empty" class="bk-state" hidden>
          <p>There are no times available at the moment.</p>
          <a href="/#contact" class="bk-btn bk-btn-alt">Message us instead</a>
        </div>

        <div id="bk-picker" hidden>
          <div class="bk-cols">
            <div class="bk-col">
              <h3 class="bk-col-h" id="bk-days-h">Date</h3>
              <div class="bk-days" role="tablist" aria-labelledby="bk-days-h" id="bkp-days"></div>
            </div>
            <div class="bk-col">
              <h3 class="bk-col-h" id="bk-times-h">Time</h3>
              <div class="bk-times" role="tabpanel" aria-labelledby="bk-times-h" id="bk-times"></div>
            </div>
          </div>
        </div>
      </section>

      <!-- STEP 2: details -->
      <section id="bk-step2" class="bk-panel" hidden aria-labelledby="bk-s2-h">
        <h2 id="bk-s2-h" class="bk-sr">Your details</h2>

        <div class="bk-chosen">
          <div>
            <span class="bk-chosen-lab">Your slot</span>
            <strong id="bk-chosen-when">—</strong>
          </div>
          <button type="button" class="bk-change" id="bkp-change">Change</button>
        </div>

        <form id="bk-form" novalidate>
          <div class="bk-grid2">
            <div class="bk-field">
              <label for="bkp-first">First name <span class="bk-req" aria-hidden="true">*</span></label>
              <input type="text" id="bkp-first" autocomplete="given-name" required>
            </div>
            <div class="bk-field">
              <label for="bkp-last">Last name <span class="bk-req" aria-hidden="true">*</span></label>
              <input type="text" id="bkp-last" autocomplete="family-name" required>
            </div>
          </div>
          <div class="bk-grid2">
            <div class="bk-field">
              <label for="bkp-email">Email <span class="bk-req" aria-hidden="true">*</span></label>
              <input type="email" id="bkp-email" autocomplete="email" required>
            </div>
            <div class="bk-field">
              <label for="bkp-phone">Phone number${phoneReq ? ' <span class="bk-req" aria-hidden="true">*</span>' : ""}</label>
              <input type="tel" id="bkp-phone" autocomplete="tel"${phoneReq ? " required" : ""}>
            </div>
          </div>

          ${noteHidden ? "" : `<div class="bk-field${noteLabel.length > 40 ? " bk-long" : ""}">
            <label for="bkp-note">${escapeHtml(noteLabel)}</label>
            <textarea id="bkp-note" rows="3"></textarea>
          </div>`}

          ${questionFields}

          <div class="wc-turnstile" style="margin:0 0 0.85rem;"></div>

          <div class="bk-err" id="bk-form-err" role="alert" hidden></div>

          <button type="submit" class="bk-btn bk-submit" id="bkp-submit">
            <span class="bk-submit-label">Request this time</span>
          </button>
          <p class="bk-privacy">Your details are handled in line with our <a href="/privacy">Privacy Notice</a>. We will confirm by email.</p>
        </form>
      </section>

      <!-- STEP 3: done -->
      <section id="bk-done" class="bk-panel bk-done" hidden aria-labelledby="bk-done-h" tabindex="-1">
        <div class="bk-tick" aria-hidden="true">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
        </div>
        <h2 id="bk-done-h">Request received</h2>
        <p id="bk-done-when"></p>
        <p class="bk-done-sub">${page.confirm_note
          ? escapeHtml(page.confirm_note)
          : "We will confirm your time by email shortly. If anything changes, just reply to that email and we will sort it."}</p>
        <a href="/" class="bk-btn bk-btn-alt">Back to the site</a>
      </section>
    </div>

    <p class="bk-urgent">
      Well Connections is not an emergency service. If you need urgent help, contact your GP,
      call 111 or 999, or call the Samaritans free on 116 123.
    </p>
  </main>

  <script>
  (function () {
    var SLUG = ${JSON.stringify(page.slug)};
    var days = [], chosen = null;

    var $ = function (id) { return document.getElementById(id); };
    var elLoading = $("bk-loading"), elErr = $("bk-error"), elEmpty = $("bk-empty"),
        elPicker = $("bk-picker"), elDays = $("bkp-days"), elTimes = $("bk-times"),
        s1 = $("bk-step1"), s2 = $("bk-step2"), done = $("bk-done");

    function show(el, on) { if (el) el.hidden = !on; }
    function setStep(n) {
      document.querySelectorAll(".bk-step").forEach(function (li) {
        li.classList.toggle("is-on", +li.dataset.step <= n);
      });
    }

    function load() {
      show(elErr, false); show(elLoading, true); show(elPicker, false); show(elEmpty, false);
      fetch("/api/availability?page=" + encodeURIComponent(SLUG))
        .then(function (r) { if (!r.ok) throw new Error("Could not load times"); return r.json(); })
        .then(function (d) {
          days = d.days || [];
          show(elLoading, false);
          if (!days.length) { show(elEmpty, true); return; }
          renderDays();
          show(elPicker, true);
        })
        .catch(function (e) {
          show(elLoading, false);
          $("bk-error-msg").textContent = e.message || "We couldn't load the calendar.";
          show(elErr, true);
        });
    }

    function renderDays() {
      elDays.innerHTML = "";
      days.forEach(function (day, i) {
        var b = document.createElement("button");
        b.type = "button";
        b.className = "bk-day" + (i === 0 ? " is-sel" : "");
        b.setAttribute("role", "tab");
        b.setAttribute("aria-selected", i === 0 ? "true" : "false");
        b.innerHTML = '<span class="bk-day-lab">' + day.label + '</span>' +
                      '<span class="bk-day-n">' + day.slots.length + ' time' + (day.slots.length === 1 ? '' : 's') + '</span>';
        b.onclick = function () {
          elDays.querySelectorAll(".bk-day").forEach(function (x) {
            x.classList.remove("is-sel"); x.setAttribute("aria-selected", "false");
          });
          b.classList.add("is-sel"); b.setAttribute("aria-selected", "true");
          renderTimes(day);
        };
        elDays.appendChild(b);
      });
      renderTimes(days[0]);
    }

    function renderTimes(day) {
      elTimes.innerHTML = "";
      day.slots.forEach(function (slot) {
        var b = document.createElement("button");
        b.type = "button";
        b.className = "bk-time";
        b.textContent = slot.label;
        b.onclick = function () {
          chosen = { start: slot.start, when: day.label + ", " + slot.label };
          $("bk-chosen-when").textContent = chosen.when;
          show(s1, false); show(s2, true); setStep(2);
          // The Turnstile widget lives inside step 2, which is hidden (display:none)
          // until now, and Turnstile cannot render into a hidden container. Render
          // it the moment the step becomes visible.
          if (window.wcRenderTurnstile) window.wcRenderTurnstile();
          var f = $("bkp-first"); if (f) f.focus();
          s2.scrollIntoView({ behavior: "smooth", block: "start" });
        };
        elTimes.appendChild(b);
      });
    }

    $("bkp-change").onclick = function () {
      show(s2, false); show(s1, true); setStep(1);
      s1.scrollIntoView({ behavior: "smooth", block: "start" });
    };
    $("bk-retry").onclick = load;

    $("bk-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      var errBox = $("bk-form-err"), btn = $("bkp-submit");
      show(errBox, false);

      var first = $("bkp-first").value.trim();
      var last = $("bkp-last").value.trim();
      var name = (first + " " + last).trim();
      var email = $("bkp-email").value.trim();
      var phone = $("bkp-phone").value.trim();
      if (!first) return fail("Please enter your first name.");
      if (!last) return fail("Please enter your last name.");
      if (!/^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$/.test(email)) return fail("Please enter a valid email address.");
      if (${phoneReq ? "true" : "false"} && !phone) return fail("Please enter your phone number.");
      if (!chosen) return fail("Please choose a time first.");

      var turnstileToken = (window.wcTurnstileToken ? window.wcTurnstileToken() : "");
      if (window.WC_TURNSTILE_SITEKEY && !turnstileToken) return fail("Please complete the verification above.");

      var answers = {};
      var missing = null;
      document.querySelectorAll("#bk-form [data-q]").forEach(function (w) {
        var label = w.getAttribute("data-q"), type = w.getAttribute("data-qtype"), v;
        if (type === "checkbox") {
          v = Array.prototype.map.call(w.querySelectorAll("input:checked"), function (x) { return x.value; });
          if (v.length) answers[label] = v;
          v = v.length ? "x" : "";
        } else if (type === "radio") {
          var c = w.querySelector("input:checked");
          v = c ? c.value : "";
          if (v) answers[label] = v;
        } else {
          var f = w.querySelector("input,select,textarea");
          v = f ? (f.value || "").trim() : "";
          if (v) answers[label] = v;
        }
        if (w.getAttribute("data-qreq") === "1" && !v && !missing) missing = label;
      });
      if (missing) return fail("Please answer: " + missing);

      btn.disabled = true;
      btn.querySelector(".bk-submit-label").textContent = "Sending…";

      fetch("/api/bookings", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          page: SLUG, slot_start: chosen.start, name: name, email: email,
          phone: phone, note: ($("bkp-note") ? $("bkp-note").value.trim() : ""),
          answers: answers, turnstile_token: turnstileToken
        })
      })
        .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, j: j }; }); })
        .then(function (res) {
          if (!res.ok) throw new Error(res.j.error || "Something went wrong.");
          $("bk-done-when").textContent = chosen.when;
          show(s2, false); show(done, true);
          done.focus();
          done.scrollIntoView({ behavior: "smooth", block: "center" });
        })
        .catch(function (e) {
          btn.disabled = false;
          btn.querySelector(".bk-submit-label").textContent = "Request this time";
          fail(e.message);
        });

      function fail(msg) {
        errBox.textContent = msg; show(errBox, true);
        btn.disabled = false;
        btn.querySelector(".bk-submit-label").textContent = "Request this time";
        return false;
      }
    });

    load();
  })();
  </script>
  ${BOOK_CSS}`;

  return new Response(
    layout({
      title: `${page.name} | Book with Well Connections`,
      description: page.intro || `Book ${page.name} with Well Connections.`,
      body
    }),
    { headers: { "content-type": "text/html;charset=UTF-8" } }
  );
}

const BOOK_CSS = `
<style>
  /* The hidden attribute must beat our own display rules, or panels that are
     switched off stay on screen. */
  [hidden]{display:none!important}
  .bk-sr{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap}
  .bk-head h1{max-width:22ch;margin-inline:auto}
  .bk-wrap{max-width:940px;padding-bottom:5rem}
  .bk-draft{background:#fff4e5;border:1px solid #f0d0a0;color:#7a5312;padding:.75rem 1rem;
    border-radius:8px;font-size:.88rem;margin-bottom:1.25rem}

  .bk-shell{background:#fff;border:1px solid var(--stone);border-top:3px solid var(--teal);
    border-radius:12px;padding:1.75rem;box-shadow:0 6px 28px rgba(30,48,40,.06)}

  .bk-steps{display:flex;gap:.5rem;list-style:none;margin:0 0 1.25rem;padding:0;flex-wrap:wrap}
  .bk-step{display:flex;align-items:center;gap:.5rem;font-size:.82rem;color:var(--text-muted);
    padding:.35rem .75rem .35rem .35rem;border-radius:99px;transition:color .2s}
  .bk-step span{width:22px;height:22px;border-radius:50%;background:var(--stone);color:var(--text-muted);
    display:grid;place-items:center;font-size:.75rem;font-weight:600;transition:background .2s,color .2s}
  .bk-step.is-on{color:var(--bark-dark);font-weight:500}
  .bk-step.is-on span{background:var(--sage);color:#fff}

  .bk-meta{display:flex;flex-wrap:wrap;gap:.5rem;margin-bottom:1.5rem}
  .bk-chip{display:inline-flex;align-items:center;gap:.4rem;font-size:.78rem;color:var(--text-muted);
    background:var(--cream);border:1px solid var(--stone);border-radius:99px;padding:.3rem .75rem}
  .bk-dot{width:6px;height:6px;border-radius:50%;background:var(--sage)}

  .bk-state{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:.9rem;
    padding:3rem 1rem;color:var(--text-muted);font-size:.92rem;text-align:center}
  .bk-state-err{color:#8a3b3b}
  .bk-spinner{width:26px;height:26px;border:2px solid var(--stone);border-top-color:var(--sage);
    border-radius:50%;animation:bkspin .8s linear infinite}
  @keyframes bkspin{to{transform:rotate(360deg)}}
  @media (prefers-reduced-motion:reduce){
    .bk-spinner{animation-duration:2.4s}
    html{scroll-behavior:auto}
  }

  .bk-cols{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.15fr);gap:1.5rem}
  @media(max-width:680px){.bk-cols{grid-template-columns:1fr;gap:1.25rem}}
  .bk-col-h{font-size:.72rem;letter-spacing:.14em;text-transform:uppercase;color:var(--teal);
    font-weight:600;margin-bottom:.75rem}

  .bk-days{display:flex;flex-direction:column;gap:.4rem;max-height:340px;overflow-y:auto;padding-right:.25rem}
  .bk-day{display:flex;align-items:center;justify-content:space-between;gap:.75rem;width:100%;
    background:#fff;border:1px solid var(--stone);border-radius:8px;padding:.7rem .9rem;cursor:pointer;
    font-family:'Quicksand',sans-serif;font-size:.9rem;color:var(--bark-dark);text-align:left;
    transition:border-color .15s,background .15s}
  .bk-day:hover{border-color:var(--sage);background:var(--sage-pale)}
  .bk-day.is-sel{border-color:var(--teal);background:var(--sage-pale);font-weight:500}
  .bk-day:focus-visible{outline:2px solid var(--teal);outline-offset:2px}
  .bk-day-n{font-size:.74rem;color:var(--text-muted);white-space:nowrap}

  .bk-times{display:grid;grid-template-columns:repeat(auto-fill,minmax(96px,1fr));gap:.5rem;
    max-height:340px;overflow-y:auto;padding-right:.25rem;align-content:start}
  .bk-time{background:#fff;border:1px solid var(--stone);border-radius:8px;padding:.65rem .5rem;
    cursor:pointer;font-family:'Quicksand',sans-serif;font-size:.88rem;color:var(--bark-dark);
    transition:border-color .15s,background .15s,transform .1s}
  .bk-time:hover{border-color:var(--sage);background:var(--sage-pale)}
  .bk-time:active{transform:translateY(1px)}
  .bk-time:focus-visible{outline:2px solid var(--teal);outline-offset:2px}

  .bk-chosen{display:flex;align-items:center;justify-content:space-between;gap:1rem;
    background:var(--sage-pale);border:1px solid var(--stone);border-radius:8px;
    padding:.9rem 1.1rem;margin-bottom:1.5rem;flex-wrap:wrap}
  .bk-chosen-lab{display:block;font-size:.7rem;letter-spacing:.12em;text-transform:uppercase;
    color:var(--teal);font-weight:600;margin-bottom:.15rem}
  .bk-chosen strong{font-size:.98rem;color:var(--bark-dark);font-weight:500}
  .bk-change{background:none;border:none;color:var(--teal);font-family:'Quicksand',sans-serif;
    font-size:.85rem;cursor:pointer;text-decoration:underline;padding:.25rem}
  .bk-change:focus-visible{outline:2px solid var(--teal);outline-offset:2px}

  .bk-grid2{display:grid;grid-template-columns:1fr 1fr;gap:1rem}
  @media(max-width:600px){.bk-grid2{grid-template-columns:1fr}}
  .bk-field{margin-bottom:1rem}
  .bk-field label{display:block;font-size:.78rem;letter-spacing:.08em;text-transform:uppercase;
    color:var(--text-muted);font-weight:500;margin-bottom:.4rem}
  .bk-req{color:var(--teal)}
  .bk-field input,.bk-field select,.bk-field textarea{width:100%;background:#fff;
    border:1px solid var(--stone);border-radius:6px;padding:.7rem .85rem;
    font-family:'Quicksand',sans-serif;font-size:.94rem;color:var(--text);transition:border-color .15s,box-shadow .15s}
  .bk-field input:focus,.bk-field select:focus,.bk-field textarea:focus{outline:none;
    border-color:var(--sage);box-shadow:0 0 0 3px rgba(90,138,106,.15)}
  .bk-field textarea{resize:vertical;min-height:80px}
  .bk-long label,.bk-group legend{text-transform:none;letter-spacing:0;font-size:.92rem;line-height:1.5;color:var(--text)}
  .bk-group{border:0;padding:0;margin:0 0 1.1rem;min-width:0}
  .bk-group legend{display:block;font-weight:500;margin-bottom:.5rem;padding:0}
  .bk-opts{display:flex;flex-direction:column;gap:.35rem}
  .bk-field .bk-opt{display:flex;align-items:flex-start;gap:.6rem;text-transform:none;letter-spacing:0;
    font-size:.92rem;color:var(--text);font-weight:400;margin:0;cursor:pointer;padding:.45rem .6rem;
    border:1px solid var(--stone);border-radius:6px;background:#fff}
  .bk-field .bk-opt:hover{border-color:var(--sage)}
  .bk-field .bk-opt input{width:auto;margin:.2rem 0 0;accent-color:var(--sage);flex:0 0 auto;padding:0}
  .bk-about{max-width:760px;margin:0 auto 1.5rem;background:#fff;border:1px solid var(--stone);
    border-radius:8px;padding:1.25rem 1.4rem;font-size:.95rem;line-height:1.65;color:var(--text)}
  .bk-about p{margin:0 0 .8rem}.bk-about p:last-child{margin:0}

  .bk-err{background:#fdf0f0;border:1px solid #edc9c9;color:#8a3b3b;border-radius:6px;
    padding:.7rem .9rem;font-size:.88rem;margin-bottom:1rem}

  .bk-btn{display:inline-block;background:var(--sage);color:#fff!important;text-decoration:none;
    border:none;cursor:pointer;padding:.85rem 1.7rem;border-radius:4px;font-family:'Quicksand',sans-serif;
    font-size:.9rem;letter-spacing:.03em;font-weight:500;transition:background .2s,transform .1s}
  .bk-btn:hover{background:var(--sage-dark)}
  .bk-btn:active{transform:translateY(1px)}
  .bk-btn:focus-visible{outline:2px solid var(--teal);outline-offset:3px}
  .bk-btn[disabled]{opacity:.6;cursor:not-allowed;transform:none}
  .bk-btn-alt{background:transparent;color:var(--teal)!important;border:1px solid var(--stone)}
  .bk-btn-alt:hover{background:var(--sage-pale)}
  .bk-submit{width:100%;margin-top:.5rem}
  .bk-privacy{margin-top:.85rem;font-size:.78rem;color:var(--text-muted);text-align:center}
  .bk-privacy a{color:var(--teal)}

  .bk-done{text-align:center;padding:3rem 1.5rem}
  .bk-done:focus{outline:none}
  .bk-tick{width:52px;height:52px;margin:0 auto 1.25rem;border-radius:50%;background:var(--sage-pale);
    color:var(--teal);display:grid;place-items:center}
  .bk-tick svg{width:26px;height:26px}
  .bk-done h2{font-family:'League Spartan',sans-serif;font-size:1.4rem;font-weight:600;
    color:var(--bark-dark);margin-bottom:.5rem}
  .bk-done #bk-done-when{font-size:1rem;color:var(--teal);font-weight:500;margin-bottom:.75rem}
  .bk-done-sub{font-size:.92rem;color:var(--text-muted);line-height:1.7;max-width:46ch;
    margin:0 auto 1.5rem}

  .bk-urgent{margin-top:2rem;font-size:.8rem;color:var(--text-muted);text-align:center;
    line-height:1.7;max-width:56ch;margin-inline:auto}
</style>`;
