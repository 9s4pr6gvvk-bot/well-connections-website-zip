// Dynamic sitemap at /sitemap.xml
// Lists the fixed public pages plus every published blog post, team page and
// therapist profile pulled live from D1, so new content is indexed automatically.

import { slugify } from "../shared/markdown.js";

const SITE = "https://wellconnections.co.uk";

// Fixed public routes. Admin (/admin) and the API are deliberately excluded.
const STATIC_ROUTES = [
  { path: "/",                  priority: "1.0", changefreq: "weekly"  },
  { path: "/services",          priority: "0.8", changefreq: "monthly" },
  { path: "/personal-support",  priority: "0.8", changefreq: "monthly" },
  { path: "/about",             priority: "0.7", changefreq: "monthly" },
  { path: "/impact",            priority: "0.7", changefreq: "monthly" },
  { path: "/contact",           priority: "0.7", changefreq: "monthly" },
  { path: "/businesses",        priority: "0.7", changefreq: "monthly" },
  { path: "/schools",           priority: "0.7", changefreq: "monthly" },
  { path: "/charities",         priority: "0.7", changefreq: "monthly" },
  { path: "/therapy-leeds",     priority: "0.7", changefreq: "monthly" },
  { path: "/therapy-harrogate", priority: "0.7", changefreq: "monthly" },
  { path: "/therapy-ripon",     priority: "0.7", changefreq: "monthly" },
  { path: "/coaching-leeds",    priority: "0.7", changefreq: "monthly" },
  { path: "/coaching-harrogate",priority: "0.7", changefreq: "monthly" },
  { path: "/coaching-ripon",    priority: "0.7", changefreq: "monthly" },
  { path: "/therapy-york",      priority: "0.7", changefreq: "monthly" },
  { path: "/coaching-york",     priority: "0.7", changefreq: "monthly" },
  { path: "/blog",              priority: "0.6", changefreq: "weekly"  },
  { path: "/team",              priority: "0.6", changefreq: "monthly" },
  { path: "/book",              priority: "0.6", changefreq: "monthly" },
  { path: "/faqs",              priority: "0.5", changefreq: "monthly" },
  { path: "/privacy",           priority: "0.3", changefreq: "yearly"  },
  { path: "/terms",             priority: "0.3", changefreq: "yearly"  },
];

function xmlEscape(s) {
  return String(s).replace(/[<>&'"]/g, (c) =>
    ({ "<": "&lt;", ">": "&gt;", "&": "&amp;", "'": "&apos;", '"': "&quot;" }[c])
  );
}

// D1 stores timestamps like "2026-09-22 14:03:00"; W3C sitemaps want a date.
function toDate(ts) {
  if (!ts) return null;
  const m = String(ts).match(/^\d{4}-\d{2}-\d{2}/);
  return m ? m[0] : null;
}

function urlEntry({ path, priority, changefreq, lastmod }) {
  const loc = path.startsWith("http") ? path : SITE + path;
  return `  <url>
    <loc>${xmlEscape(loc)}</loc>${lastmod ? `
    <lastmod>${lastmod}</lastmod>` : ""}${changefreq ? `
    <changefreq>${changefreq}</changefreq>` : ""}${priority ? `
    <priority>${priority}</priority>` : ""}
  </url>`;
}

export async function onRequestGet(context) {
  const { env } = context;
  const entries = STATIC_ROUTES.map(urlEntry);

  // Published blog posts -> /blog/<slug>
  try {
    const { results } = await env.DB.prepare(
      "SELECT slug, updated_at, published_at FROM posts WHERE status='published'"
    ).all();
    for (const p of results || []) {
      if (!p.slug) continue;
      entries.push(urlEntry({
        path: `/blog/${encodeURIComponent(p.slug)}`,
        priority: "0.6",
        changefreq: "monthly",
        lastmod: toDate(p.updated_at || p.published_at),
      }));
    }
  } catch (_) { /* static routes still ship if D1 is unavailable */ }

  // Published specialism teams -> /team/<slug>
  try {
    const { results } = await env.DB.prepare(
      "SELECT slug, updated_at FROM teams WHERE status='published'"
    ).all();
    for (const t of results || []) {
      if (!t.slug) continue;
      entries.push(urlEntry({
        path: `/team/${encodeURIComponent(t.slug)}`,
        priority: "0.5",
        changefreq: "monthly",
        lastmod: toDate(t.updated_at),
      }));
    }
  } catch (_) { /* ignore */ }

  // Published therapists -> /therapist/<slug>. The profile route derives the
  // slug from the name via slugify(), so we do the same here to stay in sync.
  try {
    const { results } = await env.DB.prepare(
      "SELECT name, updated_at FROM therapists WHERE status='published'"
    ).all();
    for (const t of results || []) {
      const slug = slugify(t.name);
      if (!slug) continue;
      entries.push(urlEntry({
        path: `/therapist/${slug}`,
        priority: "0.5",
        changefreq: "monthly",
        lastmod: toDate(t.updated_at),
      }));
    }
  } catch (_) { /* ignore */ }

  const body = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${entries.join("\n")}
</urlset>`;

  return new Response(body, {
    headers: {
      "Content-Type": "application/xml; charset=utf-8",
      "Cache-Control": "public, max-age=3600",
    },
  });
}
