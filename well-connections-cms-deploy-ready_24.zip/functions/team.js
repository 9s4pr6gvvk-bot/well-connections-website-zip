import { layout } from "../shared/layout.js";
import { escapeHtml } from "../shared/markdown.js";

// /team  -> hub listing every specialism team
export async function onRequestGet(context) {
  const { env } = context;
  const teams = (await env.DB.prepare(
    "SELECT * FROM teams WHERE status='published' ORDER BY sort_order ASC, name ASC"
  ).all()).results || [];
  const counts = (await env.DB.prepare(
    "SELECT teams FROM therapists WHERE status='published'"
  ).all()).results || [];

  const countFor = (slug) => counts.filter((r) => (r.teams || "").includes("|" + slug + "|")).length;

  const cards = teams.map((t) => {
    const n = countFor(t.slug);
    return `<a class="tcard" href="/team/${escapeHtml(t.slug)}">
      <h3>${escapeHtml(t.name)}</h3>
      ${t.tagline ? `<p>${escapeHtml(t.tagline)}</p>` : ""}
      <span class="meta">${n} therapist${n === 1 ? "" : "s"} <span aria-hidden="true">&rarr;</span></span>
    </a>`;
  }).join("");

  const body = `
  <header class="page-head">
    <span class="label">Our Therapists</span>
    <h1>Specialist teams,<br /><em>personally vetted.</em></h1>
    <p>Choose the team that fits what you're navigating. Every therapist is personally known to Well Connections, with credentials and experience checked.</p>
  </header>
  <main class="wrap">
    ${teams.length ? `<div class="tgrid">${cards}</div>` : `<p style="text-align:center;color:var(--text-muted)">Team pages are being set up.</p>`}
  </main>
  <style>
    .tgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:1.6rem}
    .tcard{display:flex;flex-direction:column;text-decoration:none;color:inherit;background:#fff;border:1px solid var(--stone);border-radius:8px;padding:1.8rem;transition:box-shadow .25s,transform .25s}
    .tcard:hover{box-shadow:0 14px 44px rgba(30,48,40,.1);transform:translateY(-3px)}
    .tcard h3{font-family:'League Spartan',sans-serif;font-weight:500;font-size:1.5rem;color:var(--text)}
    .tcard p{font-size:.92rem;color:var(--text-muted);line-height:1.65;margin-top:.6rem;flex:1}
    .tcard .meta{margin-top:1.2rem;font-size:.78rem;letter-spacing:.06em;text-transform:uppercase;color:var(--sage-dark);font-weight:500}
  </style>`;

  return new Response(layout({
    title: "Our Specialist Teams | Well Connections",
    description: "Specialist counselling, therapy and coaching teams at Well Connections.",
    canonical: "/team",
    body,
  }), { headers: { "Content-Type": "text/html; charset=utf-8" } });
}
