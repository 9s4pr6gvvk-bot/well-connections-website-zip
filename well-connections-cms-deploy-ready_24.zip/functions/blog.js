import { layout } from "../shared/layout.js";
import { escapeHtml } from "../shared/markdown.js";

function fmtDate(iso) {
  if (!iso) return "";
  const d = new Date(iso);
  return d.toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" });
}

export async function onRequestGet(context) {
  const { env } = context;
  const { results } = await env.DB.prepare(
    "SELECT * FROM posts WHERE status='published' ORDER BY published_at DESC"
  ).all();

  const items = (results || []).map((p) => `
    <a class="post${p.cover_url ? "" : " no-cover"}" href="/blog/${escapeHtml(p.slug)}">
      ${p.cover_url ? `<div class="cover"><img src="${escapeHtml(p.cover_url)}" alt="${escapeHtml(p.title)}" loading="lazy" /></div>` : ""}
      <div class="meta">
        <span class="date">${fmtDate(p.published_at)}</span>
        <h2>${escapeHtml(p.title)}</h2>
        ${p.excerpt ? `<p>${escapeHtml(p.excerpt)}</p>` : ""}
        <span class="more">Read article &rarr;</span>
      </div>
    </a>`).join("");

  const body = `
  <header class="page-head">
    <span class="label">Blogs</span>
    <h1>Insight &amp;<br /><em>wellbeing.</em></h1>
    <p>Thoughts on therapy, mental health and living well from the Well Connections team.</p>
  </header>
  <main class="wrap">
    ${results && results.length ? `<div class="list">${items}</div>` : `<p style="text-align:center;color:var(--text-muted)">New articles are on the way.</p>`}
  </main>
  <style>
    .list{display:grid;gap:2.5rem;max-width:820px;margin:0 auto}
    .post{display:grid;grid-template-columns:220px 1fr;gap:1.6rem;text-decoration:none;color:inherit;border:1px solid var(--stone);border-radius:6px;overflow:hidden;transition:box-shadow .25s,transform .25s;background:#fff}
    .post:hover{box-shadow:0 12px 40px rgba(30,48,40,.1);transform:translateY(-3px)}
    .post.no-cover{grid-template-columns:1fr;border-left:3px solid var(--sage)}
    .cover{background:var(--sage-pale)}
    .cover img{width:100%;height:100%;object-fit:cover;min-height:160px}
    .meta{padding:1.4rem 1.6rem}
    .post.no-cover .meta{padding:1.6rem 1.8rem}
    .date{font-size:.72rem;letter-spacing:.08em;text-transform:uppercase;color:var(--teal)}
    .meta h2{font-family:'League Spartan',sans-serif;font-weight:500;font-size:1.55rem;margin:.3rem 0 .5rem;line-height:1.2}
    .post.no-cover .meta h2{font-size:1.7rem}
    .meta p{font-size:.92rem;color:var(--text-muted);line-height:1.65}
    .post.no-cover .meta p{max-width:60ch}
    .more{display:inline-block;margin-top:.9rem;font-size:.8rem;letter-spacing:.05em;color:var(--sage-dark);font-weight:500}
    @media(max-width:640px){.post{grid-template-columns:1fr}.cover img{min-height:200px}}
  </style>`;

  return new Response(layout({
    title: "Blogs: Mental Health & Wellbeing | Well Connections",
    description: "Mental health and wellbeing articles from the Well Connections team on therapy, coaching and living well.",
    body,
    canonical: "/blog",
    jsonLd: {
      "@context": "https://schema.org",
      "@type": "Blog",
      "@id": "https://wellconnections.co.uk/blog#blog",
      "name": "Well Connections Blogs",
      "url": "https://wellconnections.co.uk/blog",
      "description": "Mental health and wellbeing articles from the Well Connections team.",
      "publisher": { "@type": "Organization", "name": "Well Connections", "url": "https://wellconnections.co.uk/" },
    },
  }), { headers: { "Content-Type": "text/html; charset=utf-8" } });
}
