import { layout } from "../../shared/layout.js";
import { escapeHtml, slugify } from "../../shared/markdown.js";

// /team/<slug>  -> a specialism team page (hero + live filter + therapist cards)
export async function onRequestGet(context) {
  const { env, params } = context;
  const team = await env.DB.prepare(
    "SELECT * FROM teams WHERE slug=? AND status='published'"
  ).bind(params.slug).first();

  if (!team) {
    return new Response(layout({
      title: "Team not found | Well Connections",
      description: "The team you were looking for could not be found.",
      noindex: true,
      body: `<main class="wrap" style="text-align:center"><h1 style="font-family:'League Spartan',sans-serif;font-weight:600">Team not found</h1><p style="margin-top:1rem"><a href="/team">Back to all teams</a></p></main>`,
    }), { status: 404, headers: { "Content-Type": "text/html; charset=utf-8" } });
  }

  const people = (await env.DB.prepare(
    "SELECT * FROM therapists WHERE status='published' AND teams LIKE ? ORDER BY sort_order ASC, name ASC"
  ).bind("%|" + team.slug + "|%").all()).results || [];

  const cards = people.map((t) => {
    const search = escapeHtml(`${t.name} ${t.role} ${t.credentials}`.toLowerCase());
    const img = t.photo_url
      ? `<img class="t-img" src="${escapeHtml(t.photo_url)}" alt="${escapeHtml(t.name)}" loading="lazy" />`
      : `<div class="t-ph">${escapeHtml((t.name || "?").charAt(0))}</div>`;
    const link = `<div class="t-foot"><a class="t-link" href="/therapist/${slugify(t.name)}">Read profile <span aria-hidden="true">&rarr;</span></a></div>`;
    return `<article class="t-card" data-search="${search}">
      ${img}
      <div class="t-body">
        <h3 class="t-name">${escapeHtml(t.name)}</h3>
        ${t.role ? `<p class="t-role">${escapeHtml(t.role)}</p>` : ""}
        ${t.credentials ? `<div class="t-creds"><strong>Qualifications &amp; Accreditations</strong>${escapeHtml(t.credentials)}</div>` : ""}
      </div>
      ${link}
    </article>`;
  }).join("");

  const body = `
  <header class="page-head">
    <nav class="crumb"><a href="/">Home</a> <span>&rsaquo;</span> <a href="/team">Teams</a> <span>&rsaquo;</span> <span>${escapeHtml(team.name)}</span></nav>
    <h1>${escapeHtml(team.name)}</h1>
    ${team.tagline ? `<p>${escapeHtml(team.tagline)}</p>` : ""}
  </header>

  <div class="filter">
    <span class="f-label">Filter</span>
    <input type="search" id="tsearch" placeholder="Search by name, role or qualification" autocomplete="off" />
    <span class="f-count" id="tcount">Showing <strong>${people.length}</strong> therapist${people.length === 1 ? "" : "s"}</span>
  </div>

  <main class="wrap">
    ${people.length ? `<div class="t-grid" id="tgrid">${cards}</div>` : `<p style="text-align:center;color:var(--text-muted)">Therapists for this team are being added.</p>`}
  </main>

  <style>
    .page-head .crumb{font-size:.8rem;margin-bottom:1rem;color:rgba(255,255,255,.6)}
    .page-head .crumb a{color:var(--sage-light);text-decoration:none}
    .filter{position:sticky;top:76px;z-index:20;background:var(--cream);border-bottom:1px solid var(--stone);display:flex;align-items:center;gap:1rem;padding:1rem 5%;flex-wrap:wrap}
    @media(max-width:768px){.filter{top:74px}}
    .f-label{font-size:.72rem;letter-spacing:.1em;text-transform:uppercase;color:var(--text-muted)}
    .filter input{flex:1;min-width:200px;max-width:420px;padding:.6rem .9rem;border:1px solid var(--stone);border-radius:4px;font-family:inherit;font-size:.9rem}
    .filter input:focus{outline:none;border-color:var(--sage)}
    .f-count{font-size:.82rem;color:var(--text-muted)}
    .t-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:1.8rem}
    .t-card{display:flex;flex-direction:column;background:#fff;border:1px solid var(--stone);border-radius:8px;overflow:hidden;transition:box-shadow .25s,transform .25s}
    .t-card:hover{box-shadow:0 12px 40px rgba(30,48,40,.1);transform:translateY(-3px)}
    .t-img{width:100%;aspect-ratio:1/1;object-fit:cover;object-position:top;background:var(--sage-pale)}
    .t-ph{width:100%;aspect-ratio:1/1;display:flex;align-items:center;justify-content:center;background:var(--sage-pale);color:var(--sage);font-family:'League Spartan',sans-serif;font-size:3rem}
    .t-body{padding:1.3rem 1.4rem;flex:1}
    .t-name{font-family:'League Spartan',sans-serif;font-weight:500;font-size:1.35rem;color:var(--text)}
    .t-role{color:var(--teal);font-size:.82rem;margin-top:.2rem}
    .t-creds{margin-top:.9rem;font-size:.78rem;color:var(--text-muted);line-height:1.6}
    .t-creds strong{display:block;text-transform:uppercase;letter-spacing:.06em;font-size:.68rem;color:var(--sage-dark);font-weight:500;margin-bottom:.3rem}
    .t-bio{margin-top:.8rem;font-size:.88rem;color:var(--text-muted);line-height:1.6}
    .t-foot{padding:0 1.4rem 1.3rem}
    .t-link{font-size:.8rem;letter-spacing:.04em;color:var(--sage-dark);text-decoration:none;font-weight:500;display:inline-flex;gap:.35rem;transition:gap .2s}
    .t-link:hover{gap:.65rem}
    .no-match{grid-column:1/-1;text-align:center;color:var(--text-muted);padding:2rem}
  </style>
  <script>
    (function(){
      var input=document.getElementById('tsearch');
      var grid=document.getElementById('tgrid');
      var count=document.getElementById('tcount');
      if(!input||!grid)return;
      var cards=[].slice.call(grid.querySelectorAll('.t-card'));
      input.addEventListener('input',function(){
        var q=this.value.trim().toLowerCase();
        var shown=0;
        cards.forEach(function(c){
          var hit=!q||c.getAttribute('data-search').indexOf(q)>-1;
          c.style.display=hit?'':'none';
          if(hit)shown++;
        });
        count.innerHTML='Showing <strong>'+shown+'</strong> therapist'+(shown===1?'':'s');
      });
    })();
  </script>`;

  return new Response(layout({
    title: `${team.name} | Well Connections`,
    description: team.tagline || `Meet the ${team.name} team at Well Connections.`,
    body,
    canonical: `/team/${team.slug}`,
  }), { headers: { "Content-Type": "text/html; charset=utf-8" } });
}
