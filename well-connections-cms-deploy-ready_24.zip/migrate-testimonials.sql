-- Adds the testimonials table to an existing database.
-- Run once:  npx wrangler d1 execute wellconnections-cms --remote --file=./migrate-testimonials.sql
CREATE TABLE IF NOT EXISTS testimonials (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  quote       TEXT    NOT NULL,
  author      TEXT    DEFAULT '',
  detail      TEXT    DEFAULT '',       -- e.g. "Parent, Harrogate"
  status      TEXT    DEFAULT 'published',
  sort_order  INTEGER DEFAULT 0,
  created_at  TEXT    DEFAULT (datetime('now')),
  updated_at  TEXT    DEFAULT (datetime('now'))
);
