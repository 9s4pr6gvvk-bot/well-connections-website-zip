-- Adds the logos table (dashboard > Logos tab) and seeds the client-group
-- labels for the homepage carousel, in Sam's order (Oct 2026).
-- Run once:
--   npx wrangler d1 execute wellconnections-cms --remote --file=./migrate-logos.sql
--
-- kind  = 'logo'  : an organisation logo (needs an uploaded image)
--         'label' : a word in the homepage carousel, e.g. "Families"
-- pages = comma-separated: home, schools, businesses, charities
CREATE TABLE IF NOT EXISTS logos (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  kind        TEXT    NOT NULL DEFAULT 'logo',
  name        TEXT    NOT NULL,
  image_url   TEXT    DEFAULT '',
  pages       TEXT    DEFAULT '',
  status      TEXT    DEFAULT 'published',
  sort_order  INTEGER DEFAULT 0,
  created_at  TEXT    DEFAULT (datetime('now')),
  updated_at  TEXT    DEFAULT (datetime('now'))
);

-- Gaps in the numbering leave room for logos between the labels:
-- Arthritis UK 10, Families 20, HS4L 30, Schools 40, Harrogate Chocolate
-- Factory 50, King James's School 60, Organisations 70, NEOSS 80,
-- Individuals 90, Krysallis 100, Duchy College 110.
INSERT INTO logos (kind, name, pages, status, sort_order)
SELECT 'label', 'Families', 'home', 'published', 20
WHERE NOT EXISTS (SELECT 1 FROM logos WHERE kind='label' AND name='Families');
INSERT INTO logos (kind, name, pages, status, sort_order)
SELECT 'label', 'Schools', 'home', 'published', 40
WHERE NOT EXISTS (SELECT 1 FROM logos WHERE kind='label' AND name='Schools');
INSERT INTO logos (kind, name, pages, status, sort_order)
SELECT 'label', 'Organisations', 'home', 'published', 70
WHERE NOT EXISTS (SELECT 1 FROM logos WHERE kind='label' AND name='Organisations');
INSERT INTO logos (kind, name, pages, status, sort_order)
SELECT 'label', 'Individuals', 'home', 'published', 90
WHERE NOT EXISTS (SELECT 1 FROM logos WHERE kind='label' AND name='Individuals');

SELECT id, kind, name, pages, sort_order FROM logos ORDER BY sort_order;
