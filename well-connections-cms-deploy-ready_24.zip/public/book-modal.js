// Shared "Book a Discovery Call" lightbox. Self-contained: injects its own
// markup + styles, wires every booking trigger on the page, and opens in place
// instead of navigating to the homepage. Loaded on every page.
(function () {
  if (window.__bookModalLoaded) return;
  window.__bookModalLoaded = true;

  var MARKUP = `
<div id="bookOverlay" style="display:none;position:fixed;inset:0;z-index:1000;background:rgba(15,25,20,0.52);backdrop-filter:blur(3px);-webkit-backdrop-filter:blur(3px);padding:1rem;overflow-y:auto;">
  <div id="bookModal" role="dialog" aria-modal="true" aria-labelledby="bookTitle" style="max-width:480px;margin:3vh auto;background:#fff;border-radius:10px;padding:1.5rem 1.5rem 1.75rem;box-shadow:0 20px 60px rgba(0,0,0,0.28);">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:0.2rem;">
      <div style="display:flex;align-items:center;gap:0.6rem;">
        <button type="button" id="bk-back" aria-label="Back" style="display:none;background:none;border:none;color:var(--text-muted);cursor:pointer;font-size:1.1rem;padding:0;line-height:1;">&#8592;</button>
        <div>
          <span style="display:block;font-size:0.65rem;letter-spacing:0.18em;text-transform:uppercase;color:var(--teal);margin-bottom:0.15rem;">Free Discovery Call</span>
          <h3 id="bookTitle" style="font-family:'League Spartan',sans-serif;font-size:1.2rem;font-weight:600;color:var(--bark-dark);line-height:1.2;margin:0;">Choose a date</h3>
        </div>
      </div>
      <button type="button" id="bookClose" aria-label="Close" style="background:none;border:none;font-size:1.4rem;line-height:1;color:var(--text-muted);cursor:pointer;padding:0.1rem;">&times;</button>
    </div>
    <p id="bookLead" style="font-size:0.82rem;color:var(--text-muted);margin:0.4rem 0 1rem;line-height:1.5;">Pick a date then choose a time. We'll confirm by email.</p>

    <div id="bookStep1a">
      <div id="bk-cal-loading" style="text-align:center;padding:1.5rem 0;color:var(--text-muted);font-size:0.88rem;">Loading available times…</div>
      <div id="bk-cal" style="display:none;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:0.6rem;">
          <button type="button" id="bk-prev" style="background:none;border:1px solid var(--stone);border-radius:6px;padding:0.25rem 0.6rem;cursor:pointer;font-size:0.95rem;color:var(--text-muted);">&#8249;</button>
          <span id="bk-month-label" style="font-family:'League Spartan',sans-serif;font-size:0.88rem;font-weight:600;color:var(--bark-dark);"></span>
          <button type="button" id="bk-next" style="background:none;border:1px solid var(--stone);border-radius:6px;padding:0.25rem 0.6rem;cursor:pointer;font-size:0.95rem;color:var(--text-muted);">&#8250;</button>
        </div>
        <div style="display:grid;grid-template-columns:repeat(7,1fr);gap:2px;margin-bottom:3px;text-align:center;">
          <span style="font-size:0.65rem;color:var(--text-muted);padding:0.2rem 0;">M</span>
          <span style="font-size:0.65rem;color:var(--text-muted);padding:0.2rem 0;">T</span>
          <span style="font-size:0.65rem;color:var(--text-muted);padding:0.2rem 0;">W</span>
          <span style="font-size:0.65rem;color:var(--text-muted);padding:0.2rem 0;">T</span>
          <span style="font-size:0.65rem;color:var(--text-muted);padding:0.2rem 0;">F</span>
          <span style="font-size:0.65rem;color:var(--text-muted);padding:0.2rem 0;">S</span>
          <span style="font-size:0.65rem;color:var(--text-muted);padding:0.2rem 0;">S</span>
        </div>
        <div id="bk-days" style="display:grid;grid-template-columns:repeat(7,1fr);gap:3px;"></div>
      </div>
      <div id="bk-cal-empty" style="display:none;text-align:center;padding:1.25rem 0;color:var(--text-muted);font-size:0.88rem;">
        No times available right now. <a href="/contact" id="bk-empty-contact" style="color:var(--teal);">Send an enquiry</a> and we'll be in touch.
      </div>
    </div>

    <div id="bookStep1b" style="display:none;">
      <p id="bk-slots-label" style="font-size:0.78rem;letter-spacing:0.06em;text-transform:uppercase;color:var(--text-muted);margin-bottom:0.65rem;"></p>
      <div id="bk-slots" style="display:flex;flex-wrap:wrap;gap:0.4rem;"></div>
    </div>

    <div id="bookStep2" style="display:none;">
      <div style="background:var(--sage-pale);border-radius:6px;padding:0.65rem 0.85rem;margin-bottom:1rem;display:flex;align-items:center;justify-content:space-between;gap:0.75rem;">
        <strong id="bk-chosen" style="font-size:0.88rem;color:var(--bark-dark);font-weight:500;"></strong>
        <button type="button" id="bk-change" style="background:none;border:none;color:var(--teal);font-size:0.78rem;cursor:pointer;text-decoration:underline;white-space:nowrap;">Change</button>
      </div>
      <div style="margin-bottom:0.75rem;">
        <label for="bk-name" style="display:block;font-size:0.75rem;color:var(--bark-dark);margin-bottom:0.28rem;">Your name *</label>
        <input id="bk-name" type="text" autocomplete="name" style="width:100%;padding:0.6rem 0.75rem;border:1px solid var(--stone);border-radius:4px;font-family:inherit;font-size:16px;" />
      </div>
      <div style="display:flex;gap:0.6rem;flex-wrap:wrap;margin-bottom:0.75rem;">
        <div style="flex:1;min-width:160px;">
          <label for="bk-email" style="display:block;font-size:0.75rem;color:var(--bark-dark);margin-bottom:0.28rem;">Email *</label>
          <input id="bk-email" type="email" autocomplete="email" style="width:100%;padding:0.6rem 0.75rem;border:1px solid var(--stone);border-radius:4px;font-family:inherit;font-size:16px;" />
        </div>
        <div style="flex:1;min-width:120px;">
          <label for="bk-phone" style="display:block;font-size:0.75rem;color:var(--bark-dark);margin-bottom:0.28rem;">Phone</label>
          <input id="bk-phone" type="tel" autocomplete="tel" style="width:100%;padding:0.6rem 0.75rem;border:1px solid var(--stone);border-radius:4px;font-family:inherit;font-size:16px;" />
        </div>
      </div>
      <div style="margin-bottom:0.75rem;">
        <label for="bk-service" style="display:block;font-size:0.75rem;color:var(--bark-dark);margin-bottom:0.28rem;">What's it about?</label>
        <select id="bk-service" style="width:100%;padding:0.6rem 0.75rem;border:1px solid var(--stone);border-radius:4px;font-family:inherit;font-size:16px;background:#fff;">
          <option value="" selected>Select…</option>
          <option>Workplace wellbeing / organisation</option>
          <option>Mental health training</option>
          <option>Coaching</option>
          <option>Schools &amp; young people</option>
          <option>Individual therapy</option>
          <option>Not sure yet</option>
        </select>
      </div>
      <div style="margin-bottom:1rem;">
        <label for="bk-note" style="display:block;font-size:0.75rem;color:var(--bark-dark);margin-bottom:0.28rem;">Anything else? (optional)</label>
        <textarea id="bk-note" rows="2" style="width:100%;padding:0.6rem 0.75rem;border:1px solid var(--stone);border-radius:4px;font-family:inherit;font-size:16px;resize:vertical;"></textarea>
      </div>
      <div class="wc-turnstile" style="margin:0 0 0.85rem;"></div>
      <div id="bk-err" style="color:#c0392b;font-size:0.82rem;min-height:1rem;margin-bottom:0.4rem;"></div>
      <button type="button" id="bk-submit" class="btn-primary" style="width:100%;text-align:center;border:none;cursor:pointer;padding:0.8rem;">Request This Time</button>
      <p style="font-size:0.7rem;color:var(--text-muted);text-align:center;margin-top:0.7rem;">Your details are handled in line with our <a href="/privacy" style="color:var(--teal);text-decoration:underline;">Privacy Notice</a>.</p>
    </div>

    <div id="bookSuccess" style="display:none;text-align:center;padding:0.75rem 0 0.25rem;">
      <div style="width:48px;height:48px;border-radius:50%;background:var(--sage-pale);display:flex;align-items:center;justify-content:center;margin:0 auto 0.75rem;">
        <svg width="22" height="22" fill="none" stroke="var(--sage-dark)" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M4.5 12.75l6 6 9-13.5"/></svg>
      </div>
      <h3 style="font-family:'League Spartan',sans-serif;font-size:1.2rem;font-weight:600;color:var(--bark-dark);margin-bottom:0.4rem;">Request sent</h3>
      <p id="bk-success-msg" style="font-size:0.88rem;color:var(--text-muted);line-height:1.6;max-width:340px;margin:0 auto 1.25rem;">Thank you. We'll confirm your consultation by email shortly.</p>
      <button type="button" class="btn-secondary bk-dismiss" style="border-color:var(--stone);color:var(--bark-dark);cursor:pointer;">Close</button>
    </div>
  </div>
</div>`;

  var STYLE = `
#bookOverlay .btn-primary{background:var(--sage);color:#fff;text-transform:uppercase;letter-spacing:.05em;font-size:.8rem;font-weight:600;border-radius:2px;transition:background .2s;}
#bookOverlay .btn-primary:hover:not(:disabled){background:var(--sage-dark);}
#bookOverlay .btn-primary:disabled{opacity:.7;cursor:default;}
#bookOverlay .btn-secondary{background:#fff;border:1px solid var(--stone);color:var(--bark-dark);text-transform:uppercase;letter-spacing:.05em;font-size:.8rem;font-weight:500;border-radius:2px;padding:.7rem 1.4rem;transition:background .2s;}
#bookOverlay .btn-secondary:hover{background:var(--cream);}`;

  function init() {
    // Don't double-inject if a page already has the modal inline.
    if (!document.getElementById('bookOverlay')) {
      var st = document.createElement('style');
      st.textContent = STYLE;
      document.head.appendChild(st);
      var host = document.createElement('div');
      host.innerHTML = MARKUP;
      document.body.appendChild(host.firstElementChild);
      if (window.wcRenderTurnstile) window.wcRenderTurnstile();
    }

    var overlay=document.getElementById('bookOverlay');
    var step1a=document.getElementById('bookStep1a');
    var step1b=document.getElementById('bookStep1b');
    var step2=document.getElementById('bookStep2');
    var success=document.getElementById('bookSuccess');
    var err=document.getElementById('bk-err');
    var calBox=document.getElementById('bk-cal');
    var loading=document.getElementById('bk-cal-loading');
    var emptyBox=document.getElementById('bk-cal-empty');
    var daysEl=document.getElementById('bk-days');
    var slotsEl=document.getElementById('bk-slots');
    var slotsLabel=document.getElementById('bk-slots-label');
    var monthLabel=document.getElementById('bk-month-label');
    var chosenEl=document.getElementById('bk-chosen');
    var titleEl=document.getElementById('bookTitle');
    var backBtn=document.getElementById('bk-back');
    var availability=null,activeDay=-1,chosenSlot=null,loaded=false,viewMonth=null;

    function buildDayMap(){var m={};if(!availability)return m;availability.days.forEach(function(d,i){m[d.date]=i;});return m;}
    function todayStr(){var n=new Date();return n.getFullYear()+'-'+('0'+(n.getMonth()+1)).slice(-2)+'-'+('0'+n.getDate()).slice(-2);}

    function showStep(which){
      step1a.style.display=which==='1a'?'':'none';
      step1b.style.display=which==='1b'?'':'none';
      step2.style.display=which==='2'?'':'none';
      success.style.display=which==='ok'?'':'none';
      backBtn.style.display=(which==='1b'||which==='2')?'':'none';
      titleEl.textContent=which==='1b'?'Choose a time':which==='2'?'Your details':'Choose a date';
      // The verification widget lives in step 2, which starts hidden. Turnstile
      // can only render into a visible box, so render it the moment step 2 shows.
      if(which==='2'&&window.wcRenderTurnstile) window.wcRenderTurnstile();
    }

    function renderCalendar(){
      if(!availability||!availability.days.length)return;
      var dayMap=buildDayMap();
      if(!viewMonth){var first=availability.days[0].date.split('-');viewMonth={y:+first[0],m:+first[1]};}
      var y=viewMonth.y,mo=viewMonth.m;
      monthLabel.textContent=new Date(y,mo-1,1).toLocaleString('en-GB',{month:'long',year:'numeric'});
      var firstDow=(new Date(y,mo-1,1).getDay()+6)%7;
      var daysInMonth=new Date(y,mo,0).getDate();
      var cells='';
      for(var e=0;e<firstDow;e++)cells+='<div></div>';
      for(var d=1;d<=daysInMonth;d++){
        var dateStr=y+'-'+(mo<10?'0'+mo:mo)+'-'+(d<10?'0'+d:d);
        var idx=dayMap.hasOwnProperty(dateStr)?dayMap[dateStr]:-1;
        var isActive=idx>=0&&idx===activeDay;
        var isToday=dateStr===todayStr();
        if(idx>=0){
          cells+='<button type="button" data-dayidx="'+idx+'" style="'
            +'aspect-ratio:1;display:flex;align-items:center;justify-content:center;'
            +'border-radius:8px;border:2px solid '+(isActive?'var(--sage)':'transparent')+';'
            +'background:'+(isActive?'var(--sage)':'var(--sage-pale)')+';'
            +'color:'+(isActive?'#fff':'var(--sage-dark)')+';'
            +'cursor:pointer;font-family:inherit;font-size:0.85rem;font-weight:600;transition:all .15s;">'+d+'</button>';
        } else {
          cells+='<div style="aspect-ratio:1;display:flex;align-items:center;justify-content:center;'
            +'font-size:0.85rem;color:'+(isToday?'var(--bark-dark)':'rgba(90,107,99,0.28)')+';'
            +(isToday?'font-weight:600;':'')+'">'+d+'</div>';
        }
      }
      daysEl.innerHTML=cells;
      Array.prototype.forEach.call(daysEl.querySelectorAll('button[data-dayidx]'),function(btn){
        btn.onmouseenter=function(){if(+btn.getAttribute('data-dayidx')!==activeDay){btn.style.background='#d1e8da';btn.style.color='var(--sage-dark)';}};
        btn.onmouseleave=function(){if(+btn.getAttribute('data-dayidx')!==activeDay){btn.style.background='var(--sage-pale)';btn.style.color='var(--sage-dark)';}};
        btn.onclick=function(){activeDay=+btn.getAttribute('data-dayidx');renderCalendar();showSlots();};
      });
      document.getElementById('bk-prev').onclick=function(){var prev=new Date(y,mo-2,1);viewMonth={y:prev.getFullYear(),m:prev.getMonth()+1};renderCalendar();};
      document.getElementById('bk-next').onclick=function(){var next=new Date(y,mo,1);viewMonth={y:next.getFullYear(),m:next.getMonth()+1};renderCalendar();};
    }

    function showSlots(){
      if(activeDay<0||!availability)return;
      var day=availability.days[activeDay];
      slotsLabel.textContent=day.label;
      slotsEl.innerHTML=day.slots.map(function(s){
        return '<button type="button" data-slot="'+s.start+'" style="'
          +'padding:0.55rem 1.1rem;border:1px solid var(--stone);border-radius:20px;'
          +'background:#fff;color:var(--bark-dark);cursor:pointer;'
          +'font-family:inherit;font-size:0.88rem;font-weight:400;transition:all .15s;">'+s.label+'</button>';
      }).join('');
      Array.prototype.forEach.call(slotsEl.querySelectorAll('button'),function(btn){
        btn.onmouseenter=function(){btn.style.borderColor='var(--sage)';btn.style.background='var(--sage-pale)';btn.style.color='var(--sage-dark)';};
        btn.onmouseleave=function(){btn.style.borderColor='var(--stone)';btn.style.background='#fff';btn.style.color='var(--bark-dark)';};
        btn.onclick=function(){
          chosenSlot=btn.getAttribute('data-slot');
          chosenEl.textContent=day.label+', '+btn.textContent;
          err.textContent='';showStep('2');
          setTimeout(function(){document.getElementById('bk-name').focus();},50);
        };
      });
      showStep('1b');
    }

    function open(prefill){
      err.textContent='';chosenSlot=null;activeDay=-1;showStep('1a');
      overlay.style.display='block';document.body.style.overflow='hidden';
      if(prefill){var s=document.getElementById('bk-service');for(var i=0;i<s.options.length;i++){if(s.options[i].value.toLowerCase().indexOf(prefill.toLowerCase())>-1){s.selectedIndex=i;break;}}}
      if(!loaded)loadAvailability();
    }
    function close(){overlay.style.display='none';document.body.style.overflow='';}
    window.openBooking=open;

    backBtn.onclick=function(){
      if(step2.style.display===''){err.textContent='';showStep('1b');return;}
      activeDay=-1;renderCalendar();showStep('1a');
    };

    document.getElementById('bookClose').onclick=close;
    overlay.addEventListener('click',function(e){if(e.target===overlay)close();});
    document.addEventListener('keydown',function(e){if(e.key==='Escape'&&overlay.style.display==='block')close();});
    Array.prototype.forEach.call(document.querySelectorAll('.bk-dismiss'),function(b){b.onclick=close;});
    document.getElementById('bk-empty-contact').onclick=function(){close();};
    document.getElementById('bk-change').onclick=function(){err.textContent='';showStep('1b');};

    // Wire every booking trigger: data-book, and links to #book / /#book.
    var triggers=[].slice.call(document.querySelectorAll('[data-book], a[href="#book"], a[href="/#book"], a[href$="/#book"]'));
    triggers.forEach(function(el){
      el.addEventListener('click',function(e){e.preventDefault();open(el.getAttribute('data-book')||'');});
    });

    function loadAvailability(){
      loading.style.display='';calBox.style.display='none';emptyBox.style.display='none';
      fetch('/api/availability').then(function(r){return r.json();}).then(function(d){
        loaded=true;availability=d;loading.style.display='none';
        if(!d.days||!d.days.length){emptyBox.style.display='';return;}
        calBox.style.display='';renderCalendar();
      }).catch(function(){loading.style.display='none';emptyBox.style.display='';});
    }

    document.getElementById('bk-submit').onclick=function(){
      err.textContent='';
      if(!chosenSlot){err.textContent='Please choose a time first.';showStep('1a');return;}
      var payload={
        name:document.getElementById('bk-name').value.trim(),
        email:document.getElementById('bk-email').value.trim(),
        phone:document.getElementById('bk-phone').value.trim(),
        service:document.getElementById('bk-service').value,
        slot_start:chosenSlot,
        note:document.getElementById('bk-note').value.trim(),
        turnstile_token:(window.wcTurnstileToken?window.wcTurnstileToken(overlay):'')
      };
      if(!payload.name){err.textContent='Please enter your name.';return;}
      if(!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(payload.email)){err.textContent='Please enter a valid email address.';return;}
      if(window.WC_TURNSTILE_SITEKEY&&!payload.turnstile_token){err.textContent='Please complete the verification below.';return;}
      var btn=document.getElementById('bk-submit');btn.disabled=true;btn.textContent='Sending…';
      fetch('/api/bookings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)})
        .then(function(r){return r.json().then(function(d){return{ok:r.ok,status:r.status,d:d};});})
        .then(function(res){
          btn.disabled=false;btn.textContent='Request This Time';
          if(res.status===409){
            err.textContent=(res.d&&res.d.error)||'That time was just taken. Please choose another.';
            loaded=false;showStep('1a');loadAvailability();return;
          }
          if(!res.ok){err.textContent=(res.d&&res.d.error)||'Something went wrong. Please try again.';return;}
          var msg=document.getElementById('bk-success-msg');
          if(res.d&&res.d.when)msg.textContent='Thank you. We’ll confirm your consultation for '+res.d.when+' by email shortly.';
          showStep('ok');
        })
        .catch(function(){btn.disabled=false;btn.textContent='Request This Time';err.textContent='Network error. Please try again.';});
    };

    if(location.hash==='#book'){open('');}
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
