// Cloudflare Turnstile front-end helper.
// Paste your Turnstile SITE key below (public — safe to expose). Until it is
// set, no widget renders and the forms work exactly as before (honeypot only).
(function () {
  var SITEKEY = "0x4AAAAAAFBixSGwsnOBTVZV"; // Well Connections Turnstile site key
  window.WC_TURNSTILE_SITEKEY = SITEKEY;
  if (!SITEKEY) return;

  function hiddenFor(el) {
    var form = el.closest("form");
    if (!form) return null;
    var h = form.querySelector('input[name="turnstile_token"]');
    if (!h) { h = document.createElement("input"); h.type = "hidden"; h.name = "turnstile_token"; form.appendChild(h); }
    return h;
  }

  function renderAll() {
    if (!window.turnstile) return;
    document.querySelectorAll(".wc-turnstile").forEach(function (el) {
      if (el.dataset.rendered) return;
      // Skip containers that are not visible yet (inside a closed modal or a
      // collapsed step). Turnstile cannot render into a display:none box and
      // would never issue a token, so leave it for the next wcRenderTurnstile()
      // call once the modal/step is actually shown.
      if (el.getClientRects().length === 0) return;
      el.dataset.rendered = "1";
      var hidden = hiddenFor(el);
      try {
        window.turnstile.render(el, {
          sitekey: SITEKEY,
          callback: function (t) { el._token = t; if (hidden) hidden.value = t; },
          "error-callback": function () { el._token = ""; if (hidden) hidden.value = ""; },
          "expired-callback": function () { el._token = ""; if (hidden) hidden.value = ""; },
        });
      } catch (e) { /* api not ready yet; polled below */ }
    });
  }

  // Read the token for a given container (used by the booking modal, which is
  // not a <form>).
  window.wcTurnstileToken = function (container) {
    var el = container ? container.querySelector(".wc-turnstile") : document.querySelector(".wc-turnstile");
    return (el && el._token) || "";
  };
  window.wcRenderTurnstile = renderAll;

  document.addEventListener("DOMContentLoaded", renderAll);
  // api.js loads async; poll briefly until it's ready, then render.
  var tries = 0;
  var iv = setInterval(function () {
    if (window.turnstile) { renderAll(); clearInterval(iv); }
    if (++tries > 100) clearInterval(iv);
  }, 100);
})();
