// Shared "Send an Enquiry" lightbox. Self-contained: injects its own markup +
// styles, wires every enquiry trigger on the page ([data-enquiry] and links to
// #contact / /#contact) and opens in place instead of scrolling/navigating.
// Loaded on every page. Posts to /api/enquiries (same as the inline forms).
(function () {
  if (window.__enquiryModalLoaded) return;
  window.__enquiryModalLoaded = true;

  var MARKUP = `
<div id="enqOverlay" style="display:none;position:fixed;inset:0;z-index:1000;background:rgba(15,25,20,0.52);backdrop-filter:blur(3px);-webkit-backdrop-filter:blur(3px);padding:1rem;overflow-y:auto;">
  <div id="enqModal" role="dialog" aria-modal="true" aria-labelledby="enqTitle" style="max-width:480px;margin:3vh auto;background:#fff;border-radius:10px;padding:1.5rem 1.5rem 1.75rem;box-shadow:0 20px 60px rgba(0,0,0,0.28);">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:0.2rem;">
      <div>
        <span style="display:block;font-size:0.65rem;letter-spacing:0.18em;text-transform:uppercase;color:var(--teal);margin-bottom:0.15rem;">Get in Touch</span>
        <h3 id="enqTitle" style="font-family:'League Spartan',sans-serif;font-size:1.2rem;font-weight:600;color:var(--bark-dark);line-height:1.2;margin:0;">Send an Enquiry</h3>
      </div>
      <button type="button" id="enqClose" aria-label="Close" style="background:none;border:none;font-size:1.4rem;line-height:1;color:var(--text-muted);cursor:pointer;padding:0.1rem;">&times;</button>
    </div>
    <p id="enqLead" style="font-size:0.82rem;color:var(--text-muted);margin:0.4rem 0 1rem;line-height:1.5;">Tell us a little about what you need and we'll reply within one working day.</p>
    <div id="enqFor" style="display:none;background:var(--sage-pale);border-radius:6px;padding:0.6rem 0.75rem;margin:0 0 1rem;font-size:0.8rem;color:var(--bark-dark);line-height:1.45;"></div>

    <form id="enqForm" novalidate>
      <div style="margin-bottom:0.7rem;">
        <label for="enq-name" style="display:block;font-size:0.75rem;color:var(--bark-dark);margin-bottom:0.28rem;">Your name *</label>
        <input id="enq-name" name="name" type="text" autocomplete="name" style="width:100%;padding:0.6rem 0.75rem;border:1px solid var(--stone);border-radius:4px;font-family:inherit;font-size:16px;" />
      </div>
      <div style="margin-bottom:0.7rem;">
        <label for="enq-org" style="display:block;font-size:0.75rem;color:var(--bark-dark);margin-bottom:0.28rem;">Organisation name</label>
        <input id="enq-org" name="organisation" type="text" autocomplete="organization" style="width:100%;padding:0.6rem 0.75rem;border:1px solid var(--stone);border-radius:4px;font-family:inherit;font-size:16px;" />
      </div>
      <div style="display:flex;gap:0.6rem;flex-wrap:wrap;margin-bottom:0.7rem;">
        <div style="flex:1;min-width:160px;">
          <label for="enq-email" style="display:block;font-size:0.75rem;color:var(--bark-dark);margin-bottom:0.28rem;">Email *</label>
          <input id="enq-email" name="email" type="email" autocomplete="email" style="width:100%;padding:0.6rem 0.75rem;border:1px solid var(--stone);border-radius:4px;font-family:inherit;font-size:16px;" />
        </div>
        <div style="flex:1;min-width:120px;">
          <label for="enq-phone" style="display:block;font-size:0.75rem;color:var(--bark-dark);margin-bottom:0.28rem;">Phone</label>
          <input id="enq-phone" name="phone" type="tel" autocomplete="tel" style="width:100%;padding:0.6rem 0.75rem;border:1px solid var(--stone);border-radius:4px;font-family:inherit;font-size:16px;" />
        </div>
      </div>
      <div style="margin-bottom:0.7rem;">
        <label for="enq-service" style="display:block;font-size:0.75rem;color:var(--bark-dark);margin-bottom:0.28rem;">What are you looking for?</label>
        <select id="enq-service" name="service" style="width:100%;padding:0.6rem 0.75rem;border:1px solid var(--stone);border-radius:4px;font-family:inherit;font-size:16px;background:#fff;">
          <option value="" selected>Select an option…</option>
          <optgroup label="For Organisations">
            <option value="Counselling &amp; Psychological Support">Counselling &amp; Psychological Support</option>
            <option value="Mental Health First Aid Training">Mental Health First Aid Training</option>
            <option value="Coaching for Growth &amp; Resilience">Coaching for Growth &amp; Resilience</option>
            <option value="Wellbeing Workshops, Talks &amp; Events">Wellbeing Workshops, Talks &amp; Events</option>
            <option value="Schools &amp; Young People">Schools &amp; Young People</option>
            <option value="Critical Incident &amp; Crisis Support">Critical Incident &amp; Crisis Support</option>
            <option value="Workplace Wellbeing Programme">Bespoke Wellbeing Programme</option>
          </optgroup>
          <optgroup label="For Individuals">
            <option value="Adult Therapy">Adult Therapy</option>
            <option value="Wellbeing">Wellbeing</option>
            <option value="Child &amp; Teen Therapy">Children &amp; Young People's Therapy</option>
            <option value="Couples Counselling">Couples Counselling</option>
            <option value="Parenting Support">Parenting Support</option>
            <option value="Individual Coaching">Individual Coaching</option>
          </optgroup>
          <option value="Not sure">Not Sure Yet</option>
        </select>
      </div>
      <div style="margin-bottom:0.7rem;">
        <label for="enq-message" style="display:block;font-size:0.75rem;color:var(--bark-dark);margin-bottom:0.28rem;">Tell us a little more (optional)</label>
        <textarea id="enq-message" name="message" rows="3" style="width:100%;padding:0.6rem 0.75rem;border:1px solid var(--stone);border-radius:4px;font-family:inherit;font-size:16px;resize:vertical;"></textarea>
      </div>
      <div class="wc-turnstile" style="margin:0 0 0.75rem;"></div>
      <div id="enq-err" style="color:#c0392b;font-size:0.85rem;min-height:1rem;margin-bottom:0.4rem;"></div>
      <button type="submit" id="enq-submit" class="enq-btn-primary" style="width:100%;padding:0.85rem 1rem;border:none;cursor:pointer;">Send Enquiry</button>
      <p style="font-size:0.72rem;color:var(--text-muted);margin:0.85rem 0 0;line-height:1.5;">Your details are handled in line with our <a href="/privacy" style="color:var(--teal);">Privacy Notice</a>. This form is not monitored for emergencies; we reply within one working day. In a crisis, call 999 or contact NHS 111.</p>
    </form>

    <div id="enqSuccess" style="display:none;text-align:center;padding:1.5rem 0.5rem 1rem;">
      <div style="width:52px;height:52px;border-radius:50%;background:var(--sage-pale);display:flex;align-items:center;justify-content:center;margin:0 auto 1rem;">
        <svg width="26" height="26" fill="none" stroke="var(--sage-dark)" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>
      </div>
      <h3 style="font-family:'League Spartan',sans-serif;font-size:1.2rem;font-weight:600;color:var(--bark-dark);margin:0 0 0.4rem;">Thank you</h3>
      <p style="font-size:0.9rem;color:var(--text-muted);line-height:1.6;margin:0 0 1.25rem;">We've received your enquiry and will be in touch very soon.</p>
      <button type="button" class="enq-dismiss enq-btn-secondary" style="padding:0.7rem 1.4rem;cursor:pointer;">Close</button>
    </div>
  </div>
</div>`;

  var STYLE = `
#enqOverlay .enq-btn-primary{background:var(--sage);color:#fff;text-transform:uppercase;letter-spacing:.05em;font-size:.8rem;font-weight:600;border-radius:2px;transition:background .2s;}
#enqOverlay .enq-btn-primary:hover:not(:disabled){background:var(--sage-dark);}
#enqOverlay .enq-btn-primary:disabled{opacity:.7;cursor:default;}
#enqOverlay .enq-btn-secondary{background:#fff;border:1px solid var(--stone);color:var(--bark-dark);text-transform:uppercase;letter-spacing:.05em;font-size:.8rem;font-weight:500;border-radius:2px;transition:background .2s;}
#enqOverlay .enq-btn-secondary:hover{background:var(--cream);}
#enq-name:focus,#enq-org:focus,#enq-email:focus,#enq-phone:focus,#enq-service:focus,#enq-message:focus{outline:none;border-color:var(--sage);}`;

  function init() {
    if (!document.getElementById('enqOverlay')) {
      var st = document.createElement('style');
      st.textContent = STYLE;
      document.head.appendChild(st);
      var host = document.createElement('div');
      host.innerHTML = MARKUP;
      document.body.appendChild(host.firstElementChild);
      if (window.wcRenderTurnstile) window.wcRenderTurnstile();
    }

    var overlay = document.getElementById('enqOverlay');
    var form = document.getElementById('enqForm');
    var success = document.getElementById('enqSuccess');
    var err = document.getElementById('enq-err');
    var forBox = document.getElementById('enqFor');
    var lead = document.getElementById('enqLead');
    var title = document.getElementById('enqTitle');

    var LEAD_DEFAULT = lead.textContent;
    // Practitioner the enquiry is for, when opened from a profile page. Slug is
    // what the API resolves against; the name is only for what the visitor sees.
    var forSlug = '';

    function escText(s) { return String(s == null ? '' : s); }

    function setPractitioner(slug, name) {
      forSlug = slug || '';
      if (forSlug) {
        var who = escText(name) || 'this practitioner';
        title.textContent = 'Enquire about ' + who;
        lead.textContent = 'Your enquiry goes to the Well Connections team, who will pass it to ' + who + ' and reply within one working day.';
        forBox.textContent = 'This enquiry is for ' + who + '.';
        forBox.style.display = 'block';
      } else {
        title.textContent = 'Send an Enquiry';
        lead.textContent = LEAD_DEFAULT;
        forBox.textContent = '';
        forBox.style.display = 'none';
      }
    }

    function open(prefill) {
      err.textContent = '';
      form.style.display = '';
      success.style.display = 'none';
      if (prefill) {
        var sel = document.getElementById('enq-service');
        for (var i = 0; i < sel.options.length; i++) {
          if (sel.options[i].value === prefill) { sel.selectedIndex = i; break; }
        }
      }
      overlay.style.display = 'block';
      document.body.style.overflow = 'hidden';
      if (window.wcRenderTurnstile) window.wcRenderTurnstile();
      setTimeout(function () { var n = document.getElementById('enq-name'); if (n) n.focus(); }, 60);
    }
    function close() {
      overlay.style.display = 'none';
      document.body.style.overflow = '';
    }

    document.getElementById('enqClose').onclick = close;
    overlay.addEventListener('click', function (e) { if (e.target === overlay) close(); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && overlay.style.display === 'block') close(); });
    Array.prototype.forEach.call(document.querySelectorAll('.enq-dismiss'), function (b) { b.onclick = close; });

    // Wire every enquiry trigger: data-enquiry, and links to #contact / /#contact.
    var triggers = [].slice.call(document.querySelectorAll(
      '[data-enquiry], a[href="#contact"], a[href="/#contact"], a[href$="/#contact"]'
    ));
    triggers.forEach(function (el) {
      el.addEventListener('click', function (e) {
        e.preventDefault();
        setPractitioner(
          el.getAttribute('data-enquiry-therapist') || '',
          el.getAttribute('data-enquiry-therapist-name') || ''
        );
        open(el.getAttribute('data-enquiry') || '');
      });
    });

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      err.textContent = '';
      var payload = {
        name: document.getElementById('enq-name').value.trim(),
        organisation: document.getElementById('enq-org').value.trim(),
        email: document.getElementById('enq-email').value.trim(),
        phone: document.getElementById('enq-phone').value.trim(),
        service: document.getElementById('enq-service').value,
        message: document.getElementById('enq-message').value.trim(),
        therapist_slug: forSlug,
        turnstile_token: (window.wcTurnstileToken ? window.wcTurnstileToken(overlay) : '')
      };
      if (!payload.name) { err.textContent = 'Please enter your name.'; return; }
      if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(payload.email)) { err.textContent = 'Please enter a valid email address.'; return; }
      if (window.WC_TURNSTILE_SITEKEY && !payload.turnstile_token) { err.textContent = 'Please complete the verification below.'; return; }
      var btn = document.getElementById('enq-submit');
      btn.disabled = true; btn.textContent = 'Sending…';
      fetch('/api/enquiries', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })
        .then(function (r) { return r.json().catch(function () { return {}; }).then(function (d) { return { ok: r.ok, d: d }; }); })
        .then(function (res) {
          btn.disabled = false; btn.textContent = 'Send Enquiry';
          if (!res.ok) { err.textContent = (res.d && res.d.error) || 'Something went wrong. Please try again.'; return; }
          form.style.display = 'none';
          success.style.display = 'block';
        })
        .catch(function () { btn.disabled = false; btn.textContent = 'Send Enquiry'; err.textContent = 'Network error. Please try again.'; });
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
