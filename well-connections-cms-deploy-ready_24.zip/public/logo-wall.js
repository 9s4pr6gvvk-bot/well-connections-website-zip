/* Organisation logos: page grids and the homepage "Proud to work with" carousel.
 *
 * Content comes from the dashboard (Logos tab) via /api/logos.
 * A section stays hidden until it has at least one published logo, and the
 * homepage strip until at least 3 logos are ticked for it.
 * Add ?logos=preview to the homepage URL to show the strip with fewer than 3.
 *
 * Page keys: "home", "schools", "businesses", "charities".
 */
(function () {
  "use strict";

  var CAROUSEL_MIN_LOGOS = 3;
  var preview = /[?&]logos=preview\b/.test(location.search);

  function esc(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function onPage(l, page) { return ("," + (l.pages || "") + ",").indexOf("," + page + ",") > -1; }

  function logoHtml(l, cls) {
    return '<span class="' + cls + '"><img src="' + esc(l.image_url) +
      '" alt="' + esc(l.name) + '" loading="lazy" decoding="async" /></span>';
  }

  var css =
    ".lw-section{background:var(--cream);padding:4rem 5%;}" +
    ".lw-section[hidden]{display:none!important;}" +
    ".lw-head{text-align:center;max-width:640px;margin:0 auto 2.25rem;}" +
    ".lw-head .section-title{font-size:clamp(1.5rem,2.6vw,2rem);}" +
    ".lw-grid{list-style:none;margin:0 auto;padding:0;max-width:1000px;display:flex;flex-wrap:wrap;justify-content:center;gap:1rem;}" +
    ".lw-grid li{flex:0 1 180px;}" +
    ".lw-tile{display:flex;align-items:center;justify-content:center;height:96px;padding:1rem 1.25rem;background:#fff;border:1px solid var(--stone);border-radius:8px;}" +
    ".lw-tile img{max-width:100%;max-height:56px;width:auto;height:auto;object-fit:contain;filter:grayscale(1);opacity:.8;transition:filter .25s,opacity .25s;}" +
    ".lw-tile:hover img{filter:none;opacity:1;}" +
    "@media(max-width:600px){.lw-section{padding:3rem 5%;}.lw-grid{gap:.75rem;}.lw-grid li{flex:0 1 calc(50% - .375rem);}.lw-tile{height:84px;padding:.85rem;}.lw-tile img{max-height:46px;}}" +
    /* carousel */
    ".lw-carousel-wrap{margin-top:3rem;}" +
    ".lw-carousel-label{display:block;text-align:center;font-size:.72rem;letter-spacing:.16em;text-transform:uppercase;color:var(--text-muted);margin-bottom:1.25rem;}" +
    ".lw-carousel{overflow:hidden;-webkit-mask-image:linear-gradient(to right,transparent 0,#000 6%,#000 94%,transparent 100%);mask-image:linear-gradient(to right,transparent 0,#000 6%,#000 94%,transparent 100%);}" +
    ".lw-track{display:flex;align-items:center;width:max-content;animation:lwscroll 50s linear infinite;}" +
    ".lw-carousel:hover .lw-track{animation-play-state:paused;}" +
    "@keyframes lwscroll{from{transform:translateX(0);}to{transform:translateX(-50%);}}" +
    ".lw-item{flex:0 0 auto;display:flex;align-items:center;justify-content:center;height:64px;margin:0 1.75rem;}" +
    ".lw-item img{max-height:48px;max-width:150px;width:auto;height:auto;object-fit:contain;filter:grayscale(1);opacity:.75;}" +
    ".lw-group{font-family:'League Spartan',sans-serif;font-size:1.15rem;font-weight:500;color:var(--teal);white-space:nowrap;}" +
    ".lw-group::before{content:'';display:inline-block;width:6px;height:6px;border-radius:50%;background:var(--sage-light);margin-right:.7rem;vertical-align:middle;}" +
    "@media(max-width:600px){.lw-item{margin:0 1.1rem;height:52px;}.lw-item img{max-height:38px;max-width:120px;}.lw-group{font-size:1rem;}.lw-track{animation-duration:38s;}}" +
    "@media(prefers-reduced-motion:reduce){.lw-carousel{-webkit-mask-image:none;mask-image:none;}.lw-track{animation:none;width:auto;flex-wrap:wrap;justify-content:center;row-gap:1rem;}.lw-track [aria-hidden=true]{display:none;}}";

  function injectCss() {
    var st = document.createElement("style");
    st.textContent = css;
    document.head.appendChild(st);
  }

  function renderGrids(all) {
    var grids = document.querySelectorAll("[data-logo-wall]");
    Array.prototype.forEach.call(grids, function (el) {
      var page = el.getAttribute("data-logo-wall");
      var items = all.filter(function (l) { return l.kind !== "label" && l.image_url && onPage(l, page); });
      if (!items.length) return;
      el.innerHTML = items.map(function (l) { return "<li>" + logoHtml(l, "lw-tile") + "</li>"; }).join("");
      var section = el.closest("[data-logo-section]");
      if (section) section.hidden = false;
    });
  }

  function renderCarousel(all) {
    var el = document.querySelector("[data-logo-carousel]");
    if (!el) return;
    var seq = all.filter(function (l) {
      return l.kind === "label" || (l.image_url && onPage(l, "home"));
    });
    var logoCount = seq.filter(function (l) { return l.kind !== "label"; }).length;
    if (!logoCount || (!preview && logoCount < CAROUSEL_MIN_LOGOS)) return;
    var html = seq.map(function (l) {
      return l.kind === "label"
        ? '<span class="lw-item lw-group">' + esc(l.name) + "</span>"
        : logoHtml(l, "lw-item");
    }).join("");
    // Second copy makes the loop seamless; hidden from screen readers.
    var dup = html.replace(/<span class="lw-item/g, '<span aria-hidden="true" class="lw-item')
                  .replace(/alt="[^"]*"/g, 'alt=""');
    el.innerHTML = '<div class="lw-track">' + html + dup + "</div>";
    var wrap = el.closest("[data-logo-section]");
    if (wrap) wrap.hidden = false;
  }

  function init() {
    if (!document.querySelector("[data-logo-wall],[data-logo-carousel]")) return;
    fetch("/api/logos", { credentials: "omit" })
      .then(function (r) { return r.ok ? r.json() : []; })
      .then(function (all) {
        if (!Array.isArray(all) || !all.length) return;
        injectCss(); renderGrids(all); renderCarousel(all);
      })
      .catch(function () {});
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
