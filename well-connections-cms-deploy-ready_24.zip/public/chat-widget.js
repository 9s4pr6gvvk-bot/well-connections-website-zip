(function () {
  "use strict";
  // Live chat is controlled by an admin switch plus optional opening hours.
  // Check both first and only build the widget when it has something to do:
  //   switch off                  -> nothing at all
  //   outside hours, mode "hide"  -> nothing at all
  //   outside hours, mode "away"  -> bubble opens to an away message
  // If the check fails, stay hidden.
  fetch("/api/chat/config")
    .then(function (r) { return r.json(); })
    .then(function (c) {
      if (!c || !c.enabled) return;
      var closed = c.open === false;
      if (closed && c.mode === "hide") return;
      init(c.copy || {}, closed, c.hours || "");
    })
    .catch(function () {});

  function init(copy, closed, hours) {
  // Admin-editable copy with built-in fallbacks.
  function T(key, dflt) { return (copy && copy[key] != null && copy[key] !== "") ? copy[key] : dflt; }
  // Fill {hours} in the away copy from the hours the API reported.
  function H(key, dflt) { return T(key, dflt).replace(/\{hours\}/g, hours || "our usual hours"); }
  var KEY = "wc_chat_token";
  var token = null;
  try { token = localStorage.getItem(KEY); } catch (e) {}
  var open = false, poll = null, closedPoll = null, lastCount = 0, atFooter = false;
  function applyBtnVisibility(){ root.classList.toggle("wcc-hide-btn", atFooter && !open); }

  function esc(s) { return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }

  var css = ""
    + ".wcc-btn{position:fixed;bottom:24px;right:24px;height:50px;padding:0 20px 0 16px;border-radius:25px;background:#5a8a6a;color:#fff;border:none;cursor:pointer;box-shadow:0 6px 28px rgba(30,48,40,.22);display:flex;align-items:center;gap:10px;z-index:9998;transition:background .2s,transform .2s,box-shadow .2s;white-space:nowrap;font-family:'Quicksand',system-ui,sans-serif;font-size:.92rem;font-weight:500;letter-spacing:.01em}"
    + ".wcc-btn:hover{background:#3d6b52;transform:translateY(-2px);box-shadow:0 10px 36px rgba(30,48,40,.3)}"
    + ".wcc-btn svg{width:22px;height:22px;flex-shrink:0}"
    + ".wcc-dot{position:absolute;top:-5px;right:-5px;width:14px;height:14px;border-radius:50%;background:#c0463a;border:2px solid #5a8a6a;display:none}"
    + ".wcc-panel{position:fixed;bottom:86px;right:24px;width:350px;max-width:calc(100vw - 44px);height:460px;max-height:calc(100vh - 120px);background:#fff;border-radius:14px;box-shadow:0 16px 50px rgba(30,48,40,.3);display:none;flex-direction:column;overflow:hidden;z-index:9999;font-family:'Quicksand',system-ui,sans-serif}"
    + ".wcc-open .wcc-panel{display:flex}"
    + ".wcc-head{background:#1e3028;color:#fff;padding:1rem 1.1rem;display:flex;align-items:center;justify-content:space-between}"
    + ".wcc-head h4{margin:0;font-size:1rem;font-weight:500}"
    + ".wcc-head p{margin:.15rem 0 0;font-size:.75rem;color:rgba(255,255,255,.6)}"
    + ".wcc-x{background:none;border:none;color:rgba(255,255,255,.8);font-size:1.4rem;line-height:1;cursor:pointer;padding:0 .2rem}"
    + ".wcc-body{flex:1;overflow-y:auto;padding:1rem;background:#f4f7f5;display:flex;flex-direction:column;gap:.6rem}"
    + ".wcc-msg{max-width:82%;padding:.6rem .8rem;border-radius:12px;font-size:.9rem;line-height:1.45;white-space:pre-wrap;word-wrap:break-word}"
    + ".wcc-msg.visitor{align-self:flex-end;background:#5a8a6a;color:#fff;border-bottom-right-radius:3px}"
    + ".wcc-msg.admin{align-self:flex-start;background:#fff;color:#1a2820;border:1px solid #e4eae7;border-bottom-left-radius:3px}"
    + ".wcc-intro{font-size:.85rem;color:#5a6b63;line-height:1.55;margin-bottom:.2rem}"
    + ".wcc-foot{border-top:1px solid #e4eae7;padding:.7rem;background:#fff}"
    + ".wcc-fields{display:flex;gap:.5rem;margin-bottom:.5rem}"
    + ".wcc-fields input{flex:1;min-width:0}"
    + ".wcc-foot input,.wcc-foot textarea{width:100%;padding:.55rem .65rem;border:1px solid #e4eae7;border-radius:6px;font-family:inherit;font-size:16px;resize:none}"
    + ".wcc-foot input:focus,.wcc-foot textarea:focus{outline:none;border-color:#5a8a6a}"
    + ".wcc-row{display:flex;gap:.5rem;align-items:flex-end}"
    + ".wcc-row textarea{flex:1}"
    + ".wcc-send{background:#5a8a6a;color:#fff;border:none;border-radius:6px;padding:.6rem .9rem;cursor:pointer;font-family:inherit;font-size:.85rem;flex-shrink:0}"
    + ".wcc-send:hover{background:#3d6b52}"
    + ".wcc-note{font-size:.72rem;color:#8a978f;text-align:center;margin-top:.4rem}"
    + ".wcc-away{background:#fff;border:1px solid #e4eae7;border-radius:12px;padding:.9rem 1rem;font-size:.88rem;line-height:1.55;color:#1a2820}"
    + ".wcc-away strong{display:block;font-size:.95rem;margin-bottom:.3rem}"
    + ".wcc-away-cta{display:inline-block;margin-top:.8rem;background:#5a8a6a;color:#fff;text-decoration:none;padding:.55rem .9rem;border-radius:6px;font-size:.82rem}"
    + ".wcc-away-cta:hover{background:#3d6b52}"
    // Smoothly tuck the launcher away when the footer is in view.
    + ".wcc .wcc-btn{transition:background .2s,transform .2s,box-shadow .2s,opacity .25s ease,visibility .25s ease}"
    + ".wcc-hide-btn .wcc-btn{opacity:0;visibility:hidden;transform:translateY(20px);pointer-events:none}";

  var st = document.createElement("style"); st.textContent = css; document.head.appendChild(st);

  var root = document.createElement("div"); root.className = "wcc";
  root.innerHTML =
    '<button class="wcc-btn">'
    + '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M21 11.5a8.38 8.38 0 0 1-8.5 8.5 8.5 8.5 0 0 1-3.9-.9L3 21l1.9-5.6A8.38 8.38 0 0 1 4 11.5 8.5 8.5 0 0 1 12.5 3 8.38 8.38 0 0 1 21 11.5z"/></svg>'
    + '<span class="wcc-dot"></span>'
    + esc(T("chat_launcher", "Message us"))
    + '</button>'
    + '<div class="wcc-panel" role="dialog" aria-label="Chat">'
    + '<div class="wcc-head"><div><h4>' + esc(T("chat_title", "Message us")) + '</h4><p>' + esc(T("chat_subtitle", "Not monitored continuously. Not for emergencies.")) + '</p></div><button class="wcc-x" aria-label="Close">&times;</button></div>'
    + '<div class="wcc-body" id="wcc-body"></div>'
    + '<div class="wcc-foot" id="wcc-foot"></div>'
    + '</div>';
  document.body.appendChild(root);

  var btn = root.querySelector(".wcc-btn");
  var dot = root.querySelector(".wcc-dot");
  var body = root.querySelector("#wcc-body");
  var foot = root.querySelector("#wcc-foot");

  function renderMessages(msgs) {
    if (!msgs.length) {
      body.innerHTML = '<div class="wcc-intro">' + esc(T("chat_intro", "Leave us a message and we will get back to you within one working day.")) + '</div>';
      return;
    }
    body.innerHTML = msgs.map(function (m) {
      return '<div class="wcc-msg ' + (m.sender === "admin" ? "admin" : "visitor") + '">' + esc(m.body) + '</div>';
    }).join("");
    body.scrollTop = body.scrollHeight;
    lastCount = msgs.length;
  }

  // Outside opening hours: no composer, just the away message and a route to
  // the enquiry form. The send endpoint refuses messages at the same time, so
  // a page left open past closing cannot post into an empty inbox.
  function renderAway() {
    body.innerHTML = '<div class="wcc-away">'
      + '<strong>' + esc(H("chat_closed_title", "Chat is closed")) + '</strong>'
      + esc(H("chat_closed_body", "Chat is open {hours}. Send us an enquiry instead and we will reply within one working day. If you need urgent help please contact your GP or call 999, or call NHS 111."))
      + '<br><a class="wcc-away-cta" href="/#contact" data-enquiry>' + esc(H("chat_closed_cta", "Send an enquiry")) + '</a>'
      + '</div>';
    foot.innerHTML = '<div class="wcc-note">' + esc(H("chat_closed_title", "Chat is closed")) + '</div>';
    var cta = body.querySelector(".wcc-away-cta");
    if (cta) cta.onclick = function (e) {
      // The shared enquiry lightbox is on every page; open it in place.
      var trigger = document.querySelector("[data-enquiry], a[href=\"/#contact\"], a[href=\"#contact\"]");
      if (trigger && trigger !== cta) { e.preventDefault(); closePanel(); trigger.click(); }
    };
  }

  function footForm() {
    if (closed) { renderAway(); return; }
    if (token) {
      foot.innerHTML =
        '<div class="wcc-row"><textarea id="wcc-input" rows="1" autocomplete="off" placeholder="' + esc(T("chat_reply_ph", "Type a message...")) + '"></textarea>'
        + '<button class="wcc-send" id="wcc-send">Send</button></div>';
    } else {
      foot.innerHTML =
        '<div class="wcc-fields"><input id="wcc-name" name="name" type="text" autocomplete="name" placeholder="' + esc(T("chat_name_ph", "Your name")) + '"><input id="wcc-email" name="email" type="email" autocomplete="email" inputmode="email" placeholder="' + esc(T("chat_email_ph", "Email (optional)")) + '"></div>'
        + '<div class="wc-turnstile" style="margin:0 0 .5rem;"></div>'
        + '<div class="wcc-row"><textarea id="wcc-input" rows="1" autocomplete="off" placeholder="' + esc(T("chat_first_ph", "How can we help?")) + '"></textarea>'
        + '<button class="wcc-send" id="wcc-send">Send</button></div>'
        + '<div class="wcc-note">' + esc(T("chat_note", "We aim to reply within one working day. Not an emergency service.")) + ' <a href="/privacy" style="color:#8a978f;text-decoration:underline;">Privacy Notice</a>.</div>';
      // Render the Turnstile challenge for the first (thread-creating) message.
      if (window.wcRenderTurnstile) window.wcRenderTurnstile();
    }
    var sendBtn = foot.querySelector("#wcc-send");
    var input = foot.querySelector("#wcc-input");
    sendBtn.onclick = send;
    input.addEventListener("keydown", function (e) {
      if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); }
    });
  }

  function send() {
    var input = foot.querySelector("#wcc-input");
    var text = (input.value || "").trim();
    if (!text) return;
    var payload = { token: token, body: text };
    if (!token) {
      var n = foot.querySelector("#wcc-name"), em = foot.querySelector("#wcc-email");
      if (n) payload.name = n.value;
      if (em) payload.email = em.value;
      // First message creates a thread, so it must carry a Turnstile token.
      payload.turnstile_token = (window.wcTurnstileToken ? window.wcTurnstileToken(foot) : "");
      if (window.WC_TURNSTILE_SITEKEY && !payload.turnstile_token) return;
    }
    input.value = "";
    fetch("/api/chat/message", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        if (d && d.closed) {
          // Hours ended while this page was sitting open.
          closed = true;
          if (d.hours) hours = d.hours;
          renderAway();
          return;
        }
        if (d.token) { token = d.token; try { localStorage.setItem(KEY, token); } catch (e) {} }
        var wasForm = !foot.querySelector("#wcc-input") || foot.querySelector("#wcc-name");
        if (wasForm) footForm();
        renderMessages(d.messages || []);
      })
      .catch(function () {});
  }

  function refresh() {
    if (!token) return;
    fetch("/api/chat/messages?token=" + encodeURIComponent(token))
      .then(function (r) { return r.json(); })
      .then(function (d) { if (d.messages) { renderMessages(d.messages); dot.style.display = "none"; } })
      .catch(function () {});
  }

  function checkClosed() {
    if (!token || open) return;
    fetch("/api/chat/messages?token=" + encodeURIComponent(token))
      .then(function (r) { return r.json(); })
      .then(function (d) {
        var msgs = d.messages || [];
        var lastAdmin = msgs.length && msgs[msgs.length - 1].sender === "admin";
        if (lastAdmin && msgs.length > lastCount) dot.style.display = "block";
      })
      .catch(function () {});
  }

  function openPanel() {
    open = true; root.classList.add("wcc-open"); dot.style.display = "none";
    if (closed) {
      renderAway();
      applyBtnVisibility();
      return;
    }
    footForm();
    if (token) refresh(); else renderMessages([]);
    clearInterval(poll); poll = setInterval(refresh, 5000);
    applyBtnVisibility();
  }
  function closePanel() {
    open = false; root.classList.remove("wcc-open");
    clearInterval(poll); poll = null;
    applyBtnVisibility();
  }

  btn.onclick = function () { open ? closePanel() : openPanel(); };
  root.querySelector(".wcc-x").onclick = closePanel;

  if (!closed) {
    closedPoll = setInterval(checkClosed, 30000);
    setTimeout(checkClosed, 3000);
  }

  // Hide the launcher while the footer is on screen so it never covers it,
  // and bring it back as soon as the footer scrolls out of view. If the chat
  // panel is open we leave it be — only the bubble is affected.
  var footer = document.querySelector("footer");
  if (footer && "IntersectionObserver" in window) {
    var io = new IntersectionObserver(function (entries) {
      atFooter = !!(entries[0] && entries[0].isIntersecting);
      applyBtnVisibility();
    }, { threshold: 0 });
    io.observe(footer);
  }
  } // init
})();
