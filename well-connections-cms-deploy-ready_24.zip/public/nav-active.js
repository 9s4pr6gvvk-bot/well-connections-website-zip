// Highlights the current page in the nav (agency-style active state).
(function () {
  var path = (location.pathname || "/").replace(/\/+$/, "") || "/";
  var links = document.querySelectorAll("#navbar .nav-links a, #mobileMenu a");
  links.forEach(function (a) {
    var href = (a.getAttribute("href") || "").split("#")[0].replace(/\/+$/, "");
    if (!href) return;
    if (href === path || (href !== "/" && path.indexOf(href) === 0)) a.classList.add("active");
  });
  // If a dropdown child is active, mark the dropdown trigger active too.
  document.querySelectorAll("#navbar .nav-dropdown").forEach(function (d) {
    if (d.querySelector(".active")) {
      var t = d.querySelector("a");
      if (t) t.classList.add("active");
    }
  });
})();
