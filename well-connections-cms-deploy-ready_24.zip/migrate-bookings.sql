-- Booking system (slot-based) + settings + enquiries.
-- Safe to run on a fresh DB or one that had the earlier free-text bookings table.
-- Run once:
--   npx wrangler d1 execute wellconnections-cms --remote --file=./migrate-bookings.sql
--
-- NOTE: this drops the old bookings table. The earlier version stored free-text
-- preferred times and was not yet in production use. If you have real bookings
-- you want to keep, export them first.
DROP TABLE IF EXISTS bookings;

CREATE TABLE bookings (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  token           TEXT    NOT NULL UNIQUE,
  name            TEXT    NOT NULL,
  email           TEXT    NOT NULL,
  phone           TEXT    DEFAULT '',
  service         TEXT    DEFAULT '',
  slot_start      TEXT    NOT NULL,
  duration_min    INTEGER DEFAULT 30,
  note            TEXT    DEFAULT '',
  status          TEXT    DEFAULT 'pending',
  admin_note      TEXT    DEFAULT '',
  seen_by_admin   INTEGER DEFAULT 0,
  created_at      TEXT    DEFAULT (datetime('now')),
  updated_at      TEXT    DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_bookings_status ON bookings(status);
CREATE INDEX IF NOT EXISTS idx_bookings_token  ON bookings(token);
CREATE INDEX IF NOT EXISTS idx_bookings_slot   ON bookings(slot_start);

CREATE TABLE IF NOT EXISTS app_settings (
  key        TEXT PRIMARY KEY,
  value      TEXT DEFAULT '',
  updated_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS enquiries (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  name          TEXT    NOT NULL,
  email         TEXT    NOT NULL,
  phone         TEXT    DEFAULT '',
  organisation  TEXT    DEFAULT '',
  service       TEXT    DEFAULT '',
  message       TEXT    DEFAULT '',
  status        TEXT    DEFAULT 'new',
  created_at    TEXT    DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_enquiries_status ON enquiries(status);

-- Default availability settings (admin can change these in the dashboard).
INSERT OR IGNORE INTO app_settings (key, value) VALUES
  ('booking_days',       '1,2,3,4,5'),  -- weekdays open: 0=Sun ... 6=Sat
  ('booking_start',      '09:00'),      -- first slot start (local time)
  ('booking_end',        '17:00'),      -- last slot must finish by this
  ('booking_duration',   '30'),         -- consult length in minutes
  ('booking_buffer',     '0'),          -- gap between slots in minutes
  ('booking_lead_hours', '24'),         -- min notice before a slot can be booked
  ('booking_horizon',    '21'),         -- how many days ahead to open
  ('booking_timezone',   'Europe/London');
