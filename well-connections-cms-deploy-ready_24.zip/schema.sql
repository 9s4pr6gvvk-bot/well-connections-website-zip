-- Well Connections CMS schema (Cloudflare D1 / SQLite)
-- Apply with:  npx wrangler d1 execute wellconnections-cms --remote --file=./schema.sql

-- Specialism teams. Each team is its own public page at /team/<slug>.
CREATE TABLE IF NOT EXISTS teams (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  name        TEXT    NOT NULL,
  slug        TEXT    NOT NULL UNIQUE,
  tagline     TEXT    DEFAULT '',
  sort_order  INTEGER DEFAULT 0,
  status      TEXT    DEFAULT 'published',
  created_at  TEXT    DEFAULT (datetime('now')),
  updated_at  TEXT    DEFAULT (datetime('now'))
);

-- Therapists. A therapist can appear on several team pages; membership is stored
-- as pipe-delimited team slugs, e.g. '|child-teens|couples|'.
CREATE TABLE IF NOT EXISTS therapists (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  name         TEXT    NOT NULL,
  role         TEXT    DEFAULT '',
  credentials  TEXT    DEFAULT '',
  photo_url    TEXT    DEFAULT '',
  profile_url  TEXT    DEFAULT '',
  teams        TEXT    DEFAULT '',
  bio          TEXT    DEFAULT '',
  enquiry_email TEXT   DEFAULT '',
  accepting    INTEGER DEFAULT 1,
  status       TEXT    DEFAULT 'published',
  sort_order   INTEGER DEFAULT 0,
  created_at   TEXT    DEFAULT (datetime('now')),
  updated_at   TEXT    DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS posts (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  title        TEXT    NOT NULL,
  slug         TEXT    NOT NULL UNIQUE,
  excerpt      TEXT    DEFAULT '',
  body         TEXT    DEFAULT '',
  cover_url    TEXT    DEFAULT '',
  author       TEXT    DEFAULT '',
  status       TEXT    DEFAULT 'draft',
  published_at TEXT    DEFAULT NULL,
  created_at   TEXT    DEFAULT (datetime('now')),
  updated_at   TEXT    DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_teams_status      ON teams(status);
CREATE INDEX IF NOT EXISTS idx_therapists_status ON therapists(status);
CREATE INDEX IF NOT EXISTS idx_posts_status      ON posts(status);
CREATE INDEX IF NOT EXISTS idx_posts_slug        ON posts(slug);

-- Organisation logos and homepage carousel labels (dashboard > Logos tab).
CREATE TABLE IF NOT EXISTS logos (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  kind        TEXT    NOT NULL DEFAULT 'logo',  -- 'logo' | 'label'
  name        TEXT    NOT NULL,
  image_url   TEXT    DEFAULT '',
  pages       TEXT    DEFAULT '',               -- home,schools,businesses,charities
  status      TEXT    DEFAULT 'published',
  sort_order  INTEGER DEFAULT 0,
  created_at  TEXT    DEFAULT (datetime('now')),
  updated_at  TEXT    DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS testimonials (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  quote       TEXT    NOT NULL,
  author      TEXT    DEFAULT '',
  detail      TEXT    DEFAULT '',
  status      TEXT    DEFAULT 'published',
  sort_order  INTEGER DEFAULT 0,
  created_at  TEXT    DEFAULT (datetime('now')),
  updated_at  TEXT    DEFAULT (datetime('now'))
);
-- Async chat: visitor threads + messages.
CREATE TABLE IF NOT EXISTS chat_threads (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  token           TEXT    NOT NULL UNIQUE,
  name            TEXT    DEFAULT '',
  email           TEXT    DEFAULT '',
  created_at      TEXT    DEFAULT (datetime('now')),
  last_message_at TEXT    DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS chat_messages (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  thread_id       INTEGER NOT NULL,
  sender          TEXT    NOT NULL,          -- 'visitor' | 'admin'
  body            TEXT    NOT NULL,
  created_at      TEXT    DEFAULT (datetime('now')),
  seen_by_admin   INTEGER DEFAULT 0,
  seen_by_visitor INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_chat_msg_thread ON chat_messages(thread_id);
CREATE INDEX IF NOT EXISTS idx_chat_thread_tok ON chat_threads(token);

-- Booking requests: visitor picks an available slot; admin accepts / declines.
-- slot_start is a UTC ISO datetime (e.g. 2026-08-26T13:00). Availability is
-- generated from app_settings; a slot is taken once a booking holds it as
-- pending or accepted.
CREATE TABLE IF NOT EXISTS bookings (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  token           TEXT    NOT NULL UNIQUE,
  name            TEXT    NOT NULL,
  email           TEXT    NOT NULL,
  phone           TEXT    DEFAULT '',
  service         TEXT    DEFAULT '',
  slot_start      TEXT    NOT NULL,            -- UTC ISO datetime of the chosen slot
  duration_min    INTEGER DEFAULT 30,
  note            TEXT    DEFAULT '',
  status          TEXT    DEFAULT 'pending',   -- pending | accepted | declined | cancelled
  admin_note      TEXT    DEFAULT '',
  seen_by_admin   INTEGER DEFAULT 0,
  created_at      TEXT    DEFAULT (datetime('now')),
  updated_at      TEXT    DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_bookings_status ON bookings(status);
CREATE INDEX IF NOT EXISTS idx_bookings_token  ON bookings(token);
CREATE INDEX IF NOT EXISTS idx_bookings_slot   ON bookings(slot_start);

-- Simple key/value store for admin-configurable settings (booking availability etc).
CREATE TABLE IF NOT EXISTS app_settings (
  key        TEXT PRIMARY KEY,
  value      TEXT DEFAULT '',
  updated_at TEXT DEFAULT (datetime('now'))
);

-- General contact-form enquiries from the website.
CREATE TABLE IF NOT EXISTS enquiries (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  name          TEXT    NOT NULL,
  email         TEXT    NOT NULL,
  phone         TEXT    DEFAULT '',
  organisation  TEXT    DEFAULT '',
  service       TEXT    DEFAULT '',
  message       TEXT    DEFAULT '',
  therapist     TEXT    DEFAULT '',           -- practitioner the enquiry was sent from, if any
  status        TEXT    DEFAULT 'new',        -- new | read | archived
  created_at    TEXT    DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_enquiries_status ON enquiries(status);

-- FAQs: CMS-editable accordion entries for the /faqs page.
CREATE TABLE IF NOT EXISTS faqs (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  question    TEXT    NOT NULL,
  answer      TEXT    NOT NULL,
  status      TEXT    DEFAULT 'published',
  sort_order  INTEGER DEFAULT 0,
  created_at  TEXT    DEFAULT (datetime('now')),
  updated_at  TEXT    DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_faqs_status ON faqs(status);
