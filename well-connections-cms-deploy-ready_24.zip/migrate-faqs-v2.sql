-- Replace the FAQ set with Sam's fully approved FAQ copy
-- (01-FAQ-COPY-FOR-WEBSITE.txt, consolidated amendments email, Sept 2026).
-- Run once:
--   npx wrangler d1 execute wellconnections-cms --remote --file=./migrate-faqs-v2.sql
--
-- This clears everything currently in the faqs table (the older, shorter set
-- from migrate-faqs.sql) and replaces it with Sam's approved questions and
-- answers in full, grouped and ordered by audience as in her document.

DELETE FROM faqs;

INSERT INTO faqs (question, answer, sort_order) VALUES
-- Working with Well Connections
('Who does Well Connections support?',
 'Well Connections supports businesses and employers, schools and colleges, charities and community organisations, as well as individuals and families. We coordinate counselling, psychological support, coaching, training and wider mental health and wellbeing programmes around the needs of each client.', 10),

('What mental health and wellbeing services do you provide?',
 'Our support includes counselling and psychological support, managed referrals, coaching, Mental Health First Aid and workplace wellbeing training, workshops, school-based provision, critical-incident support and bespoke wellbeing programmes. Support can be arranged as a one-off project, an ongoing partnership or a flexible service based on use.', 20),

('Where is support available?',
 'We provide in-person support across Yorkshire and work online with people and organisations throughout the UK. Depending on the service, support may be delivered on site, online or by telephone.', 30),

('How quickly can support begin?',
 'We aim to respond to initial enquiries within 24 hours and can usually arrange a first session within one week. For organisational programmes, timescales depend on the size and scope of the work, but we can move quickly when urgent or rapid-response support is needed.', 40),

('How do you decide what support an organisation needs?',
 'We start with a conversation about your organisation, the people you need to support, your current arrangements and what you would like to achieve. We then recommend a suitable service, delivery format and team rather than offering a standard package that may not fit.', 50),

('Can Well Connections manage referrals for us?',
 'Yes. We can provide a managed referral, allocation and booking service for employers, schools, charities and community partners. We take time to understand each referral and place the person with an appropriate psychologist, therapist, counsellor, coach or wellbeing specialist.', 60),

('How are your practitioners selected and quality-assured?',
 'We work with experienced professionals whose qualifications, professional standing and relevant experience are checked. We also consider the setting, presenting need, age group and safeguarding requirements before placing someone with a practitioner. DBS checks are required where the role or setting calls for them.', 70),

('How do confidentiality and organisational reporting work?',
 'Therapy and counselling are confidential within clear professional, safeguarding and legal boundaries. Organisations can receive agreed anonymised information about use, themes and outcomes, but personal session details are not shared as routine. We explain the boundaries to the organisation and the person receiving support at the outset.', 80),

-- Businesses and Employers
('Do you provide employee counselling and psychological support?',
 'Yes. We arrange confidential counselling and psychological support for employees, delivered on site, online or by telephone. Provision can include regular sessions, pre-booked appointments, drop-ins, short-term help, longer-term work or a fully managed referral service.', 90),

('Do you offer Mental Health First Aid and workplace wellbeing training?',
 'Yes. We provide practical Mental Health First Aid and workplace wellbeing training tailored to your organisation. Sessions can help staff recognise early warning signs, hold supportive conversations, understand boundaries and signposting, reduce stigma and develop practical approaches to individual and team wellbeing.', 100),

('Can workplace mental health training be tailored to our organisation?',
 'Yes. We take time to understand your people, culture, existing wellbeing arrangements and priorities before agreeing the format and content. Training is delivered by an experienced coach and workplace facilitator who has led hundreds of sessions, so examples and practical tools can be made relevant to day-to-day working life.', 110),

('Can you support managers, leaders and Wellbeing Champions?',
 'Yes. We offer coaching, workshops and practical guidance for managers, leaders, Mental Health Support Partners and Wellbeing Champions. This can cover confident conversations, appropriate boundaries, signposting, resilience, leadership, team dynamics and creating a healthier workplace culture.', 120),

('What workplace wellbeing workshops are available?',
 'Topics can include stress, anxiety, resilience, emotional regulation, neurodiversity, menopause, grief and loss, change, men''s mental health and general mental wellbeing. We can recommend a programme or design sessions around needs identified by your organisation.', 130),

('Can you help after a critical incident, bereavement or traumatic event?',
 'Yes. We can coordinate responsive specialist support following a critical incident, bereavement or traumatic event. We will discuss what has happened, who needs support and the safest and most appropriate form of response.', 140),

-- Schools and Colleges
('What mental health support do you provide for schools and colleges?',
 'We provide school-based counselling, psychological and emotional wellbeing support, early intervention, workshops, staff support and training. Provision can support pupils and students, parents and carers, pastoral teams and other members of staff.', 150),

('Can you support anxiety, attendance difficulties and EBSA?',
 'Yes. Our practitioners can support children and young people experiencing anxiety, emotional distress, attendance difficulties and emotionally based school avoidance (EBSA). The approach is shaped around the young person and can involve appropriate liaison with school and family.', 160),

('How do school referrals and practitioner allocation work?',
 'We agree a clear referral pathway with the school or college, review the information provided and allocate an appropriate practitioner. Arrangements can include regular on-site provision, pre-booked sessions, targeted programmes or support for a particular cohort.', 170),

('How do safeguarding, DSL liaison and CPOMS work?',
 'Safeguarding responsibilities and information-sharing arrangements are agreed at the start of the service. Practitioners work within the school''s safeguarding procedures, liaise with the Designated Safeguarding Lead when needed and use CPOMS in line with the agreed school process.', 180),

('Will parents or carers be told what is discussed in counselling?',
 'Counselling gives children and young people a confidential space, within safeguarding and legal boundaries. Consent, confidentiality and communication with parents or carers are explained clearly at the outset and handled in a way that reflects the young person''s age, needs and circumstances.', 190),

('Can you support school staff and parents as well as pupils?',
 'Yes. We can provide counselling, coaching, consultation, workshops and wellbeing training for staff, pastoral teams, parents and carers as part of a wider school or college programme.', 200),

('How do you measure and report outcomes in schools?',
 'We agree suitable outcome measures and review arrangements with the school or college. Reporting can include anonymised information about engagement, progress and service themes while protecting the confidentiality of individual pupils and students.', 210),

-- Charities and Community Organisations
('Can you support staff, volunteers and beneficiaries?',
 'Yes. We can design services for employees, volunteers, beneficiaries or a combination of these groups. Support may include counselling, coaching, group work, training, workshops and help following difficult or critical events.', 220),

('Can programmes be adapted around funding or commissioned projects?',
 'Yes. We can shape the scale, duration and delivery model around available funding, commissioning requirements and the needs of the community. We can also agree proportionate anonymised reporting for trustees, commissioners and funders.', 230),

-- Personal Support
('What personal support is available?',
 'We help adults, children and young people, couples and families access therapy, counselling, psychological support, wellbeing support, parenting support and coaching. We begin by understanding what is happening and what you would like help with, then place you with an appropriate member of the team.', 240),

('How will you help me find the right therapist or practitioner?',
 'During a free initial conversation, we ask about your needs, preferences, availability, location and any practical considerations. Because we know the professionals we work with and understand their areas of experience, we can recommend the person we believe is best placed to help.', 250),

('What is the difference between a counsellor, psychotherapist, psychologist and coach?',
 'These professionals have different training and areas of practice. Counsellors and psychotherapists provide talking therapy, psychologists may offer specialist psychological assessment or therapy, and coaches focus on goals, development and change rather than treating mental ill health. You do not need to decide alone; we will help you understand the most suitable route.', 260),

('Do you offer a free initial consultation?',
 'Yes. We offer a free 20-minute initial consultation so you can explain what support you are looking for, ask questions and understand the next steps without committing to a course of sessions.', 270),

('How much does therapy, counselling or coaching cost?',
 'Fees vary depending on the practitioner and type of support. We will explain the available options and the fee before any appointment is booked, so you can make an informed decision.', 280),

('Can you support children and young people?',
 'Yes. Our Children and Young People''s Therapy Team supports a range of emotional, behavioural and mental health needs. We consider the child or young person''s age, circumstances, preferences and safeguarding needs, and explain how parents or carers will be involved.', 290),

('Do you offer couples counselling and family or parenting support?',
 'Yes. We can arrange couples counselling as well as support for parents, carers and families. We will talk with you about the difficulty you are facing and recommend the most appropriate type of support.', 300),

('Can I have sessions online or in person?',
 'Yes. Sessions may be available in person across Yorkshire, online throughout the UK or by telephone, depending on the practitioner and type of support. We will discuss the format that works best for you.', 310),

('What should I do if I need urgent help or I am in crisis?',
 'Well Connections is not an emergency or crisis service, and website messages are not monitored continuously. If you or someone else is in immediate danger, call 999 or go to A&E. For urgent mental health help in England, contact NHS 111 and select the mental health option; Samaritans can be reached free at any time on 116 123.', 320);

SELECT id, sort_order, question FROM faqs ORDER BY sort_order;
