-- Async chat: visitor threads + messages.
-- Run once:  npx wrangler d1 execute wellconnections-cms --remote --file=./migrate-chat.sql
CREATE TABLE IF NOT EXISTS chat_threads (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  token           TEXT    NOT NULL UNIQUE,
  name            TEXT    DEFAULT '',
  email           TEXT    DEFAULT '',
  created_at      TEXT    DEFAULT (datetime('now')),
  last_message_at TEXT    DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS chat_messages (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  thread_id       INTEGER NOT NULL,
  sender          TEXT    NOT NULL,          -- 'visitor' | 'admin'
  body            TEXT    NOT NULL,
  created_at      TEXT    DEFAULT (datetime('now')),
  seen_by_admin   INTEGER DEFAULT 0,
  seen_by_visitor INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_chat_msg_thread ON chat_messages(thread_id);
CREATE INDEX IF NOT EXISTS idx_chat_thread_tok ON chat_threads(token);
