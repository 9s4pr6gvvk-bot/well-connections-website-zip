-- Booking durations: general enquiries / discovery calls are 15 minutes;
-- organisation partner clients (Arthritis UK etc.) are 30 minutes.
--
-- Fixes rows that were already seeded on the live database (the seed file's
-- INSERTs use WHERE NOT EXISTS, so they never touch existing rows).
--
-- Run once (safe to re-run):
--   npx wrangler d1 execute wellconnections-cms --remote --file=./migrate-booking-durations.sql

-- Global flow (the homepage "Book a Free Discovery Call" modal): 15 minutes.
INSERT INTO app_settings (key, value) VALUES ('booking_duration', '15')
  ON CONFLICT(key) DO UPDATE SET value = '15', updated_at = datetime('now');

-- Every general-facing booking page: 15 minutes.
UPDATE booking_pages SET duration_min = 15, updated_at = datetime('now')
  WHERE kind = 'general' AND slug <> 'intro-call';

-- Organisation partner pages: 30 minutes, except Harrogate Skills 4 Living
-- staff consultations, which are 20 (Oct 2026, see migrate-booking-pages-oct.sql).
UPDATE booking_pages SET duration_min = 30, updated_at = datetime('now')
  WHERE kind = 'organisation' AND slug <> 'harrogate-skills-for-living';
UPDATE booking_pages SET duration_min = 20, updated_at = datetime('now')
  WHERE slug = 'harrogate-skills-for-living';
