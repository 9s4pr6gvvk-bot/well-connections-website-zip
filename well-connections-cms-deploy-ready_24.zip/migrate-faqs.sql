-- FAQs: CMS-editable accordion entries for the /faqs page.
-- Run once (safe to re-run):
--   npx wrangler d1 execute wellconnections-cms --remote --file=./migrate-faqs.sql

CREATE TABLE IF NOT EXISTS faqs (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  question    TEXT    NOT NULL,
  answer      TEXT    NOT NULL,
  status      TEXT    DEFAULT 'published',
  sort_order  INTEGER DEFAULT 0,
  created_at  TEXT    DEFAULT (datetime('now')),
  updated_at  TEXT    DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_faqs_status ON faqs(status);

-- Seed the approved FAQ content. Each INSERT is guarded so re-running does not
-- duplicate rows and does not touch questions you have since edited.
INSERT INTO faqs (question, answer, sort_order)
SELECT 'Who does Well Connections work with?',
       'We support businesses, schools, colleges, charities and community organisations, as well as individuals, families and couples.', 1
WHERE NOT EXISTS (SELECT 1 FROM faqs WHERE question='Who does Well Connections work with?');

INSERT INTO faqs (question, answer, sort_order)
SELECT 'What support can you provide?',
       'Counselling, psychotherapy, psychology, coaching, training, workshops, managed referrals and wider wellbeing programmes.', 2
WHERE NOT EXISTS (SELECT 1 FROM faqs WHERE question='What support can you provide?');

INSERT INTO faqs (question, answer, sort_order)
SELECT 'How quickly can support begin?',
       'We offer a free initial call within 24 hours of an enquiry wherever possible. Where the client''s availability allows, the first therapy or coaching session can take place within one week or less.', 3
WHERE NOT EXISTS (SELECT 1 FROM faqs WHERE question='How quickly can support begin?');

INSERT INTO faqs (question, answer, sort_order)
SELECT 'How does an organisational partnership begin?',
       'We start with a discovery call to understand the organisation, existing provision, needs, timescale and budget before recommending an appropriate delivery model.', 4
WHERE NOT EXISTS (SELECT 1 FROM faqs WHERE question='How does an organisational partnership begin?');

INSERT INTO faqs (question, answer, sort_order)
SELECT 'Can support be tailored to our organisation?',
       'Yes. Provision can range from individual sessions or workshops to embedded services, funded programmes and ongoing partnerships.', 5
WHERE NOT EXISTS (SELECT 1 FROM faqs WHERE question='Can support be tailored to our organisation?');

INSERT INTO faqs (question, answer, sort_order)
SELECT 'Do you offer face-to-face and remote support?',
       'Yes. Depending on the service and practitioner, support can be provided on-site, online or by telephone.', 6
WHERE NOT EXISTS (SELECT 1 FROM faqs WHERE question='Do you offer face-to-face and remote support?');

INSERT INTO faqs (question, answer, sort_order)
SELECT 'How do you select practitioners?',
       'We consider the required experience, professional background, approach, availability and practical needs before introducing an appropriate practitioner.', 7
WHERE NOT EXISTS (SELECT 1 FROM faqs WHERE question='How do you select practitioners?');

INSERT INTO faqs (question, answer, sort_order)
SELECT 'Are practitioners checked?',
       'Each practitioner holds relevant qualifications, professional registration and insurance, with DBS checks where applicable. Well Connections'' responsibilities and those of independent practitioners are set out clearly.', 8
WHERE NOT EXISTS (SELECT 1 FROM faqs WHERE question='Are practitioners checked?');

INSERT INTO faqs (question, answer, sort_order)
SELECT 'How is confidentiality handled?',
       'Confidentiality and information-sharing arrangements are agreed at the start. Organisations receive appropriate anonymised information rather than private clinical details.', 9
WHERE NOT EXISTS (SELECT 1 FROM faqs WHERE question='How is confidentiality handled?');

INSERT INTO faqs (question, answer, sort_order)
SELECT 'How do safeguarding concerns work?',
       'Safeguarding and escalation arrangements are agreed with the organisation, including links with the relevant Designated Safeguarding Lead or responsible lead.', 10
WHERE NOT EXISTS (SELECT 1 FROM faqs WHERE question='How do safeguarding concerns work?');

INSERT INTO faqs (question, answer, sort_order)
SELECT 'Can you provide outcome and utilisation reports?',
       'Yes. Depending on the service, reporting can include attendance, engagement, anonymised themes and appropriate outcome measures.', 11
WHERE NOT EXISTS (SELECT 1 FROM faqs WHERE question='Can you provide outcome and utilisation reports?');

INSERT INTO faqs (question, answer, sort_order)
SELECT 'Can you work alongside our EAP, pastoral team or existing wellbeing provision?',
       'Yes. Our support can complement an existing service and address gaps requiring more personal or specialist support.', 12
WHERE NOT EXISTS (SELECT 1 FROM faqs WHERE question='Can you work alongside our EAP, pastoral team or existing wellbeing provision?');

INSERT INTO faqs (question, answer, sort_order)
SELECT 'What contracting options are available?',
       'We can offer retained services, usage-based arrangements, individual projects, workshops and funded or time-limited programmes.', 13
WHERE NOT EXISTS (SELECT 1 FROM faqs WHERE question='What contracting options are available?');

INSERT INTO faqs (question, answer, sort_order)
SELECT 'How much does the service cost?',
       'Organisational costs depend on the type, frequency and location of support. We provide a clear proposal following the initial conversation.', 14
WHERE NOT EXISTS (SELECT 1 FROM faqs WHERE question='How much does the service cost?');

INSERT INTO faqs (question, answer, sort_order)
SELECT 'Can individuals and families contact Well Connections directly?',
       'Yes. The personal-support route explains the initial call, finding the right support and what happens next.', 15
WHERE NOT EXISTS (SELECT 1 FROM faqs WHERE question='Can individuals and families contact Well Connections directly?');

INSERT INTO faqs (question, answer, sort_order)
SELECT 'Is Well Connections an emergency service?',
       'No. If you need urgent or emergency help, please contact your GP, call NHS 111, or call 999 in an emergency.', 16
WHERE NOT EXISTS (SELECT 1 FROM faqs WHERE question='Is Well Connections an emergency service?');

SELECT id, sort_order, question FROM faqs ORDER BY sort_order;
