-- Rate limiting for the public form endpoints (booking, enquiry, chat).
-- Backed by the existing D1 database. Safe to run more than once.
--
--   npx wrangler d1 execute wellconnections-cms --remote --file=./migrate-rate-limits.sql
--
-- Until this runs, shared/ratelimit.js fails open (forms keep working, no cap).

CREATE TABLE IF NOT EXISTS rate_limits (
  bucket      TEXT PRIMARY KEY,   -- "<route>:<ip>:<window-start-epoch>"
  count       INTEGER NOT NULL DEFAULT 0,
  expires_at  INTEGER NOT NULL    -- epoch seconds; rows past this are swept
);

CREATE INDEX IF NOT EXISTS idx_rate_limits_expires ON rate_limits (expires_at);
