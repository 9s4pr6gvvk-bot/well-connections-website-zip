-- Practitioner-specific enquiries.
--
-- Until now the "Send an enquiry" button on a practitioner's profile opened the
-- same generic enquiry form as every other page, so the enquiry arrived with no
-- record of who it was meant for. These two columns carry that through:
--
--   enquiries.therapist      the practitioner the enquiry was sent from
--   therapists.enquiry_email optional inbox to copy that practitioner in on
--
-- Run once against the live database:
--   npx wrangler d1 execute wellconnections-cms --remote --file=./migrate-enquiry-therapist.sql
--
-- Safe to re-run: if a column already exists D1 reports "duplicate column name"
-- and nothing is changed.

ALTER TABLE enquiries  ADD COLUMN therapist     TEXT DEFAULT '';
ALTER TABLE therapists ADD COLUMN enquiry_email TEXT DEFAULT '';
