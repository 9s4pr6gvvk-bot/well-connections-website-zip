-- Booking page form options (Oct 2026). Run BEFORE migrate-booking-pages-oct.sql.
--   phone_required  1 = phone number must be filled in (all the old Calendly forms required it)
--   note_label      custom wording for the standard "Anything else we should know?" box
--   note_hidden     1 = hide that box (used where the questions already cover it)
--
--   npx wrangler d1 execute wellconnections-cms --remote --file=./migrate-booking-form-options.sql
--
-- SQLite has no "ADD COLUMN IF NOT EXISTS": a second run reports "duplicate
-- column name" and stops. That is harmless; the columns are already there.
ALTER TABLE booking_pages ADD COLUMN phone_required INTEGER DEFAULT 0;
ALTER TABLE booking_pages ADD COLUMN note_label TEXT DEFAULT '';
ALTER TABLE booking_pages ADD COLUMN note_hidden INTEGER DEFAULT 0;
