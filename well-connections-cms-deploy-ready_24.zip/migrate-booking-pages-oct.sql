-- Booking pages, October 2026 (Sam's emails of 19 Oct).
-- Run AFTER migrate-booking-form-options.sql. Safe to re-run.
--   npx wrangler d1 execute wellconnections-cms --remote --file=./migrate-booking-pages-oct.sql
--
-- Names, descriptions and questions are copied from the old Calendly forms, in
-- the same order, with typos and dashes tidied. Every form asks first name, last
-- name, email and phone (required), as Calendly did. The standard "Anything
-- else" box is hidden because each form's own questions already cover it.
--
--   Arthritis UK Wellbeing Coaching       30 min  /book/arthritis-uk
--   HS4L Staff Consultation Call          20 min  /book/harrogate-skills-for-living
--   Intro Call: Workplaces & Schools      20 min  /book/intro-call   (unlisted, optional)
--   HLC staff                             retired (set to draft)

UPDATE booking_pages SET
  name = 'Wellbeing Coaching Initial Consultation',
  organisation = 'Arthritis UK',
  intro = 'This is a confidential 30 minute introductory call with the Well Connections team about Wellbeing Coaching sessions.

It is an opportunity to talk through what support would be most helpful for you and whether wellbeing coaching feels like the right fit.

If appropriate, we can then arrange your first session with a Wellbeing Coach. Arthritis UK employees can access up to six sessions funded by their employer.

This is a supportive, informal conversation with no pressure to continue.

Wellbeing Coaching is forward focused and designed to help you think clearly, manage challenges and move forward. It is not a crisis or emergency service.',
  duration_min = 30,
  questions = '[{"label": "Please share anything that will help prepare for our meeting.", "type": "textarea", "required": 0, "options": []}, {"label": "What would you like support with through wellbeing coaching? You might be navigating change at work, feeling overwhelmed, wanting to build confidence, improve balance, or think through a specific challenge.", "type": "textarea", "required": 1, "options": []}, {"label": "Which of the following best describes what''s going on for you at the moment?", "type": "radio", "required": 1, "options": ["Navigating change or uncertainty at work", "Stress or feeling overwhelmed", "Confidence or self-doubt", "Work relationships or communication", "Work-life balance", "Career direction or next steps", "General wellbeing", "Not sure yet"]}, {"label": "How are things feeling for you overall right now? If the scale was 1 - I am really struggling and 10 - I am feeling really well", "type": "select", "required": 1, "options": ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"]}, {"label": "Have you had coaching or therapy before?", "type": "radio", "required": 1, "options": ["Yes - Coaching", "Yes - Counselling/ Therapy", "Yes - Both", "No"]}, {"label": "What are you hoping for from coaching? This might be: space to think things through, practical tools and strategies, support during change, or you might not be too sure", "type": "textarea", "required": 1, "options": []}, {"label": "When we book your Wellbeing Coach for sessions, when would you be available? Please bear in mind sessions will take place on the same day and at the same time each week", "type": "checkbox", "required": 1, "options": ["Weekday mornings", "Weekday afternoons", "Weekday evenings"]}, {"label": "I understand this is a Wellbeing Coaching service which is paid for by my employer and not a crisis or emergency service. If I need urgent support, I will contact my GP, NHS 111, or emergency services.", "type": "checkbox", "required": 1, "options": ["I understand and accept"]}, {"label": "Please confirm you are a current employee of Arthritis UK", "type": "radio", "required": 1, "options": ["Yes I am", "No I am not"]}, {"label": "Please state your phone number below which we will use to call you on for your initial Consultation for Wellbeing Coaching", "type": "tel", "required": 1, "options": []}]',
  phone_required = 1, note_hidden = 1, note_label = '',
  status = 'published',
  notes = 'Replaces calendly.com/wellconnections/wellbeingcoaching. Fields copied from the Calendly form, Oct 2026.',
  updated_at = datetime('now')
WHERE slug = 'arthritis-uk';

UPDATE booking_pages SET
  name = 'HS4L Staff Consultation Call',
  organisation = 'Harrogate Skills 4 Living',
  intro = 'At Well Connections, we are pleased to offer a free 20-minute phone consultation to staff from HS4L, to help you connect with the right Counsellor or Therapist.

If none of the available times work for you, please don''t hesitate to email us at info@wellconnections.co.uk, and we will arrange a time that suits your schedule. Kindly contact us using your HS4L email, so we can confirm you as a staff member.

During your consultation, we''ll take some time to understand your situation and needs, ensuring that we match you with the right professional who aligns with your personal preferences and goals. We take care to consider the rapport and connection needed for a positive therapeutic relationship.

We have a range of highly qualified Counsellors, ready to support you, and your employer has agreed to fund up to six sessions to assist with any challenges you may be facing.

We''ve carefully vetted each professional we work with, reviewing their qualifications, references, and experience to ensure you receive the highest standard of care. Our aim is to make this process as easy and stress-free as possible for you.

We''re here to support you every step of the way.',
  duration_min = 20,
  questions = '[{"label": "What has prompted you to reach out for a consultation? Any background or initial details you can provide will help us better prepare for the call and ensure we offer the right support", "type": "textarea", "required": 1, "options": []}, {"label": "Who are the sessions for? Please let us know if you''re seeking support for an adult, child/young person, couples, your family or if there''s another focus", "type": "radio", "required": 1, "options": ["Adult", "Child or Young Person", "Couples", "Family", "Business or Organisation"]}]',
  phone_required = 1, note_hidden = 1, note_label = '',
  status = 'published',
  notes = 'Replaces calendly.com/wellconnections/hs4l. Fields copied from the Calendly form, Oct 2026. 20 minutes per Sam (Calendly event was set to 30).',
  updated_at = datetime('now')
WHERE slug = 'harrogate-skills-for-living';

INSERT INTO booking_pages (name, slug, kind, organisation, intro, duration_min, listed, sort_order, status, notes, questions, phone_required, note_hidden)
SELECT 'Intro Call: Wellbeing Support for Workplaces & Schools', 'intro-call', 'general', '',
       'This short introductory call is designed for schools and organisations exploring wellbeing, counselling or mental-health support through Well Connections. Our aim is to make mental health support simple, professional and impactful, helping your people feel valued, supported and ready to thrive.

We can:
• Discuss the challenges your staff, pupils or teams may be facing.
• Outline how our counselling, coaching and training services can help, from one-to-one support to workshops and wellbeing programmes.
• Learn a little about your organisation or school and the wellbeing priorities you''re focusing on.
• Agree next steps if you''d like a tailored proposal or quote.', 20, 0, 3, 'published',
       'Replaces calendly.com/wellconnections/intro-call-wellbeing-support-for-workplaces-schools. Unlisted: the Discovery Call covers this on the site. 20 minutes per Sam (Calendly was 15).',
       '[{"label": "What''s your Organisation/School name?", "type": "text", "required": 1, "options": []}, {"label": "Your role/ position?", "type": "text", "required": 1, "options": []}, {"label": "What type of support are you exploring?", "type": "checkbox", "required": 1, "options": ["Staff wellbeing/ Counselling", "Employee Crisis Support", "Student or Pupil support", "Leadership or HR Strategies", "Mental Health First Aid training or awareness", "Something else"]}, {"label": "Anything else you would like us to know before the call?", "type": "textarea", "required": 0, "options": []}]', 1, 1
WHERE NOT EXISTS (SELECT 1 FROM booking_pages WHERE slug = 'intro-call');

UPDATE booking_pages SET
  intro = 'This short introductory call is designed for schools and organisations exploring wellbeing, counselling or mental-health support through Well Connections. Our aim is to make mental health support simple, professional and impactful, helping your people feel valued, supported and ready to thrive.

We can:
• Discuss the challenges your staff, pupils or teams may be facing.
• Outline how our counselling, coaching and training services can help, from one-to-one support to workshops and wellbeing programmes.
• Learn a little about your organisation or school and the wellbeing priorities you''re focusing on.
• Agree next steps if you''d like a tailored proposal or quote.', questions = '[{"label": "What''s your Organisation/School name?", "type": "text", "required": 1, "options": []}, {"label": "Your role/ position?", "type": "text", "required": 1, "options": []}, {"label": "What type of support are you exploring?", "type": "checkbox", "required": 1, "options": ["Staff wellbeing/ Counselling", "Employee Crisis Support", "Student or Pupil support", "Leadership or HR Strategies", "Mental Health First Aid training or awareness", "Something else"]}, {"label": "Anything else you would like us to know before the call?", "type": "textarea", "required": 0, "options": []}]', duration_min = 20, phone_required = 1, note_hidden = 1,
  updated_at = datetime('now')
WHERE slug = 'intro-call';

-- HLC staff service has ended. Draft hides the page (the link shows "this page
-- isn't available") without deleting it or its past bookings.
UPDATE booking_pages
   SET status = 'draft',
       listed = 0,
       notes = 'Retired Oct 2026: HLC staff service no longer offered. HLC work is student counselling only, handled in school.',
       updated_at = datetime('now')
 WHERE slug LIKE '%hlc%' OR organisation LIKE '%HLC%' OR name LIKE '%HLC%';
