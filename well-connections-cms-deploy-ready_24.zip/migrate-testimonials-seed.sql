-- Add approved organisational testimonials.
-- Run once:
--   npx wrangler d1 execute wellconnections-cms --remote --file=./migrate-testimonials-seed.sql
--
-- Joanna Fox is already on the schools page as a case-study quote.
-- Emma Richards and Cathryn Sutherland go into the rotating testimonials section.

INSERT INTO testimonials (quote, author, detail, status, sort_order)
SELECT
  'Well Connections have provided Duchy College with a wellbeing service that feels genuinely cared for, not just delivered. The service is consistently present, well managed and thoughtfully aligned with what our school community actually needs. The clarity of reporting and the quality of the figures shared have been invaluable in helping us evidence our provision to governors and key stakeholders, and in reinforcing to parents that wellbeing sits at the heart of what we do.',
  'Emma Richards',
  'Finance & HR, Duchy College',
  'published',
  10
WHERE NOT EXISTS (SELECT 1 FROM testimonials WHERE author='Emma Richards');

INSERT INTO testimonials (quote, author, detail, status, sort_order)
SELECT
  'Well Connections gives us access to a trusted and experienced team of practitioners, enabling us to bring in specialist support that responds to the needs of our pupils, families and staff. Jo''s workshop on supporting anxious children and emotionally based school attendance difficulties was a great example. It was extremely well received and gave parents practical, accessible strategies they could use with their children.',
  'Cathryn Sutherland',
  'Attendance Champion, King James''s School',
  'published',
  20
WHERE NOT EXISTS (SELECT 1 FROM testimonials WHERE author='Cathryn Sutherland');

SELECT id, author, detail FROM testimonials ORDER BY sort_order;
