# Well Connections CMS

A custom CMS bolted onto the static Well Connections site, built entirely on
Cloudflare (Pages + Pages Functions + D1 + optional R2). No build step, no npm
dependencies, no WordPress. The owner logs in at `/admin` and manages **teams**
(specialism pages), **therapists**, and **blog posts**. The public pages render
straight from the database.

## The model

- **Teams** are specialisms (Child & Teens, Couples, Coaching...). Each team is
  its own public page at `/team/<slug>` with a hero, a live search filter, and a
  grid of therapist cards. The owner creates teams from `/admin` with no code.
- **Therapists** are assigned to one or more teams (tick boxes in the editor).
  Each has a name, role, qualifications line, photo, optional profile link, and
  draft/published status.
- **Blog posts** are markdown with a live preview, cover image, and draft/publish.
- `/team` is a hub listing every team.

## What's in the box

```
public/
  index.html            The existing home page (unchanged)
  admin/index.html      The CMS (login + Teams / Therapists / Blog editors)
functions/
  _middleware.js        Blocks API writes without a valid session
  team.js               /team hub (lists all teams)
  team/[slug].js        /team/<slug> specialism page (hero + filter + cards)
  blog.js               /blog list
  blog/[slug].js        /blog/<slug> article
  media/[[path]].js     Serves uploaded images from R2
  api/
    login.js logout.js me.js  upload.js
    teams.js       teams/[id].js
    therapists.js  therapists/[id].js
    posts.js       posts/[id].js
shared/
  auth.js               Signed-cookie sessions (HMAC-SHA256, Web Crypto)
  markdown.js           Markdown -> HTML for blog bodies
  layout.js             Shared page shell (matches the site design)
schema.sql              Database tables
seed.sql                Demo data: 6 teams, 27 real Child & Teens therapists, 1 post
wrangler.toml           Cloudflare config
.dev.vars.example       Local secrets template
_reference/             Your original static pages, kept for reference
```

## Deploy the demo (about 10 minutes)

You need Node and the Cloudflare CLI. Everything runs from this folder. You'll
need a (free) Cloudflare account; `npx wrangler login` once if you haven't.

**1. Create the database**

```bash
npx wrangler d1 create wellconnections-cms
```

Paste the printed `database_id` into `wrangler.toml` (the `REPLACE_WITH...` line).

**2. Create the tables and load the demo data**

```bash
npx wrangler d1 execute wellconnections-cms --remote --file=./schema.sql
npx wrangler d1 execute wellconnections-cms --remote --file=./seed.sql
```

(Skip `seed.sql` for a blank production build. It only adds demo content.)

**3. (Optional) Image uploads**

```bash
npx wrangler r2 bucket create wellconnections-media
```

If you skip this, delete the `[[r2_buckets]]` block in `wrangler.toml`. Uploads
are then disabled and you paste image URLs in the admin instead (still works;
the seeded therapists already use hosted image URLs).

**4. Deploy**

```bash
npx wrangler pages deploy
```

First run, it creates the Pages project and gives you a `*.pages.dev` URL. That
URL is what you send the client.

**5. Protect the admin with Cloudflare Access, then set two env vars**

Admin sign-in is handled by Cloudflare Zero Trust (Access), not a password in
this app. In the Cloudflare dashboard:

1. Create a self-hosted Access application whose path is **`/admin`** only, with
   a policy allowing only the owner's email(s). Do **not** put `/api` behind
   Access: the public booking, enquiry and chat forms must stay open to
   anonymous visitors. When the owner signs in at `/admin`, Cloudflare sets the
   `CF_Authorization` cookie for the whole hostname, and that cookie rides along
   to `/api` on its own.
2. The origin verifies that cookie in code (`shared/access.js` via
   `functions/_middleware.js`): a valid Access JWT means admin, its absence means
   anonymous, and only three public POST endpoints are allowed anonymously. So
   `/api` is open at the edge and gated in the app, not by Access.
3. From the Access application, copy its **Team domain** and **Application
   Audience (AUD) tag**, then set them so the origin can verify the JWT:

```bash
npx wrangler pages secret put CF_ACCESS_TEAM_DOMAIN   # e.g. yourteam.cloudflareaccess.com
npx wrangler pages secret put CF_ACCESS_AUD           # the Access application AUD tag
```

Until both are set, every admin write and read fails closed (blocked), so the
site is secure by default. There is no password anywhere.

## Bookings, availability & enquiries

The old Calendly link is gone. Three connected features now live in the dashboard:

**Bookings (calendar-style).** Visitors pick a real time slot on the website —
they choose a day, then an available time. Each request lands in the **Bookings**
tab, where you **Accept** or **Decline** (each emails the visitor). A badge shows
how many are pending. Slots a visitor holds (pending or accepted) disappear from
the site automatically, so nobody double-books.

**Availability.** The **Availability** tab is where you set what visitors can
book: which days you take consultations, first/last slot times, **consultation
length (default 30 minutes, editable)**, gap between slots, minimum notice,
how many days ahead to open, and timezone. Set it once like your working hours —
slots generate from it automatically. No need to update it often.

**Enquiries.** The website contact form now saves to the **Enquiries** tab
(it no longer uses Formspree). Open one to read the message and reply by email;
archive or delete when done. A badge shows unread enquiries.

**1. Run the migration once:**

```bash
npx wrangler d1 execute wellconnections-cms --remote --file=./migrate-bookings.sql
```

> ⚠️ This migration **drops and recreates the `bookings` table** because the
> booking system changed from free-text times to real calendar slots. The
> booking feature was not yet in live use, so there's nothing to lose — but if
> you've been testing and want to keep any rows, export them first. It also
> creates the `app_settings` and `enquiries` tables and seeds default
> availability (weekdays, 9–5, 30-minute consults).

**2. Set up email (Resend).** Everything works without this — bookings and
enquiries still save to the dashboard — but no emails send until these are set:

```bash
npx wrangler pages secret put RESEND_API_KEY    # from resend.com
```

Then add these to the `[vars]` block in `wrangler.toml` (or set as secrets):

- `BOOKING_FROM` — verified sender, e.g. `Well Connections <bookings@wellconnections.co.uk>`
- `BOOKING_TO` — where new-request and enquiry notifications go, e.g. `info@wellconnections.co.uk`

Until a domain is verified in Resend, you can test with `onboarding@resend.dev`
as the sender. Verify the `wellconnections.co.uk` domain in Resend before going live.

Emails sent: visitor gets an acknowledgement when they request a slot, and a
confirmation/decline when you act; you get a notification for every new booking
and every new enquiry. Enquiry replies are handled by you clicking **Reply by
email** (opens your mail client) rather than sent through the system.

## Showing the client

- Public demo: `https://<your-project>.pages.dev/`
  - `/team` – the specialism hub
  - `/team/child-teens` – a fully populated team page (their real 27 therapists),
    with the live search filter working
  - `/blog` – the sample article
- Admin: `https://<your-project>.pages.dev/admin` – sign in through Cloudflare
  Access (the owner's email, verified by Cloudflare; no password stored in the app).
  Show them adding a therapist, ticking a team, and publishing a post; the public
  page updates immediately on refresh.

## Local preview (optional)

```bash
cp .dev.vars.example .dev.vars      # then edit the two values
npx wrangler pages dev --d1 DB=wellconnections-cms --r2 MEDIA=wellconnections-media
```

## Wiring into the existing home page

The new pages live at `/team`, `/team/<slug>`, and `/blog`. The current
`index.html` links to `team-child-teens.html` in the nav, service cards, and
footer. Repoint those to `/team` (hub) or `/team/child-teens` when you switch
over. The nav on the CMS-rendered pages already links to `/team` and `/blog`.

## Security notes

- Admin access is controlled by Cloudflare Access (Zero Trust). Cloudflare
  verifies the owner's identity and issues a signed Access JWT; the origin
  re-verifies that JWT (`shared/access.js`) using `CF_ACCESS_TEAM_DOMAIN` and
  `CF_ACCESS_AUD`. No password or session secret is stored by the app.
- Every create/update/delete is rejected without a valid Access identity, and
  state-changing requests must be same-origin (`functions/_middleware.js`).
  Public reads only return published content.
- All database queries are parameterised.
- All user-supplied content is HTML-escaped (including quotes) before display,
  and markdown links are restricted to safe URL schemes.
- Security headers, including a Content-Security-Policy, are set in
  `public/_headers`.
- To revoke access, change the Access policy in Cloudflare (add/remove emails).
  There is no password to rotate.

## New migrations (run once each, in any order)

These add the latest content and features. Run against the live database:

```bash
npx wrangler d1 execute wellconnections-cms --remote --file=./migrate-faqs.sql
npx wrangler d1 execute wellconnections-cms --remote --file=./migrate-name-corrections.sql
npx wrangler d1 execute wellconnections-cms --remote --file=./migrate-unpublish-placeholder-post.sql
```

- **migrate-faqs.sql** — creates the `faqs` table and seeds the approved FAQ
  content. Manage entries in the admin under the **FAQs** tab; they render on
  `/faqs` as accordions.
- **migrate-name-corrections.sql** — renames the Child & Teens team to
  "Children and Young People's Therapy Team" and corrects two therapist names
  (Clare Sullivan, Leah Pryce).
- **migrate-unpublish-placeholder-post.sql** — sets the demo blog article to
  draft so it no longer shows publicly, pending replacement content.

## New pages (no migration needed)

- `/businesses`, `/schools`, `/charities` — the three "Who We Support" audience
  pages. Content lives in `shared/audience-page.js` + the matching route files
  in `functions/`. Edit copy there and redeploy.
- `/faqs` — renders from the `faqs` table (see migration above).

---

## Booking pages (native scheduling)

Self-hosted replacement for the per-organisation Calendly links. Each bookable
call type is a row in `booking_pages` and gets its own public page at
`/book/<address>`, with its own hours, session length and questions.

### One-off setup

```
npx wrangler d1 execute wellconnections-cms --remote --file=./migrate-booking-pages.sql
```

Run this **once**. The last two lines use `ALTER TABLE ADD COLUMN`, which SQLite
cannot guard with `IF NOT EXISTS`. A second run stops with "duplicate column
name" — harmless, but everything above it has already been applied.

Seeds four pages: `/book/personal-support`, `/book/discovery`,
`/book/arthritis-uk`, `/book/harrogate-skills-for-living`.

### How it works

- **Admin → Booking Pages** to add, edit or remove a page.
- Any scheduling field left **blank inherits** from the Availability tab, so a
  single organisation can be tuned without disturbing the others.
- **Booking questions** are built in the admin. Short text, long text, dropdown,
  email and phone, each optionally required. Answers are stored against the
  booking and included in the notification email.
- **Listed** controls whether a page appears in the public `/book` directory.
  Leave it off for partner pages shared privately — the link still works for
  anyone who has it.
- Bookings land in **Admin → Bookings** as normal, tagged with the page they
  came through.

### Double-booking

Slots are held globally. Once a time is taken on any page it disappears from
every page, so the same practitioner cannot be booked twice.

## Legal pages

`/privacy` and `/terms` read their body text from `app_settings` (keys
`privacy_notice` and `terms`). Until content is added they show a short holding
message. Markdown is supported.
